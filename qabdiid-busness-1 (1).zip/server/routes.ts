import express, { Request, Response, NextFunction } from 'express';
import crypto from 'node:crypto';
import {
  db,
  hashPassword,
  verifyPassword,
  addisDate,
  addisDateTime,
  ROLES,
  ROLE_DEFAULT_PERMISSIONS,
  ALL_PERMISSIONS,
} from './db.ts';
import {
  postJournalEntry,
  paymentAccountCode,
  createNotification,
  checkLowStockNotification,
  logAudit,
  getNextSequence,
  formatCode,
} from './accounting.ts';

interface AuthUser {
  id: number;
  first_name: string;
  last_name: string;
  username: string;
  email: string;
  phone: string;
  role: string;
  permissions: string[];
  is_active: number;
  two_factor_enabled: number;
  photo_url?: string;
  gender?: string;
  date_of_birth?: string;
  country?: string;
  address?: string;
}

interface AuthRequest extends Request {
  user?: AuthUser;
  authToken?: string;
}

function getDateRangeBounds(range: string, customStart?: string, customEnd?: string): { start: string; end: string } {
  const today = addisDate(0);
  const [y, m] = today.split('-').map(Number);

  switch (range) {
    case 'today':
      return { start: today, end: today };
    case 'yesterday': {
      const yd = addisDate(-1);
      return { start: yd, end: yd };
    }
    case '7d':
      return { start: addisDate(-6), end: today };
    case '30d':
      return { start: addisDate(-29), end: today };
    case 'this_month': {
      const start = `${y}-${String(m).padStart(2, '0')}-01`;
      return { start, end: today };
    }
    case 'last_month': {
      const prevMonth = m === 1 ? 12 : m - 1;
      const prevYear = m === 1 ? y - 1 : y;
      const lastDay = new Date(prevYear, prevMonth, 0).getDate();
      return {
        start: `${prevYear}-${String(prevMonth).padStart(2, '0')}-01`,
        end: `${prevYear}-${String(prevMonth).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`,
      };
    }
    case 'this_year':
      return { start: `${y}-01-01`, end: `${y}-12-31` };
    case 'custom':
      return {
        start: customStart || today,
        end: customEnd || today,
      };
    default:
      return { start: `${y}-${String(m).padStart(2, '0')}-01`, end: today };
  }
}

function requireAuth(req: AuthRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
  if (!token) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }
  const now = addisDateTime();
  const row = db
    .prepare(
      `SELECT u.id, u.first_name, u.last_name, u.username, u.email, u.phone, u.role, u.permissions_json, u.is_active, u.two_factor_enabled,
              u.photo_url, u.gender, u.date_of_birth, u.country, u.address, s.expires_at
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token = ? AND s.is_active = 1`
    )
    .get(token) as
    | (Omit<AuthUser, 'permissions'> & { permissions_json: string; expires_at: string })
    | undefined;

  if (!row || !row.is_active || row.expires_at < now) {
    res.status(401).json({ error: 'Session expired or invalid' });
    return;
  }

  let permissions: string[] = [];
  try {
    permissions = JSON.parse(row.permissions_json || '[]');
  } catch {
    permissions = [];
  }

  req.user = {
    id: row.id,
    first_name: row.first_name,
    last_name: row.last_name,
    username: row.username,
    email: row.email,
    phone: row.phone,
    role: row.role,
    permissions,
    is_active: row.is_active,
    two_factor_enabled: row.two_factor_enabled,
    photo_url: row.photo_url || '',
    gender: row.gender || '',
    date_of_birth: row.date_of_birth || '',
    country: row.country || '',
    address: row.address || '',
  };
  req.authToken = token;
  next();
}

function requirePermission(permission: string) {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    const user = req.user;
    if (!user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }
    if (
      user.role === 'Super Administrator' ||
      user.role === 'Administrator' ||
      user.permissions.includes(permission)
    ) {
      next();
      return;
    }
    res.status(403).json({ error: `Permission denied: ${permission}` });
  };
}

export function createApiRouter() {
  const router = express.Router();

  // ==================== PUBLIC / AUTH ====================
  router.get('/public/bootstrap', (_req: Request, res: Response) => {
    const settings = db.prepare('SELECT business_name, system_name, logo_url, favicon_url, default_currency, default_language FROM settings WHERE id = 1').get();
    res.json({ settings });
  });

  router.post('/auth/login', (req: Request, res: Response) => {
    const { username, password } = req.body || {};
    if (!username || !password) {
      res.status(400).json({ error: 'Username and password are required' });
      return;
    }

    const user = db
      .prepare('SELECT * FROM users WHERE username = ?')
      .get(String(username).trim()) as
      | (AuthUser & { password_hash: string; permissions_json: string })
      | undefined;

    if (!user || !verifyPassword(String(password), user.password_hash)) {
      res.status(401).json({ error: 'Invalid username or password' });
      return;
    }

    if (!user.is_active) {
      res.status(403).json({ error: 'Account is deactivated. Contact administrator.' });
      return;
    }

    const token = crypto.randomBytes(32).toString('hex');
    const now = addisDateTime();
    const expDate = new Date(Date.now() + 7 * 86400000);
    const expParts = new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'Africa/Addis_Ababa',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).formatToParts(expDate);
    const map: Record<string, string> = {};
    for (const p of expParts) {
      if (p.type !== 'literal') map[p.type] = p.value;
    }
    const expiresAt = `${map.year}-${map.month}-${map.day} ${map.hour}:${map.minute}:${map.second}`;

    db.prepare(
      'INSERT INTO sessions (token, user_id, ip_info, user_agent, created_at, expires_at, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)'
    ).run(token, user.id, req.ip || '', String(req.headers['user-agent'] || '').slice(0, 180), now, expiresAt);

    db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(now, user.id);

    logAudit({
      userId: user.id,
      username: user.username,
      action: 'LOGIN',
      module: 'Auth',
      recordId: String(user.id),
      details: 'User logged in',
    });

    let permissions: string[] = [];
    try {
      permissions = JSON.parse(user.permissions_json || '[]');
    } catch {
      permissions = [];
    }

    res.json({
      token,
      user: {
        id: user.id,
        first_name: user.first_name,
        last_name: user.last_name,
        username: user.username,
        email: user.email,
        phone: user.phone,
        role: user.role,
        permissions,
        is_active: user.is_active,
        two_factor_enabled: user.two_factor_enabled,
        photo_url: user.photo_url || '',
        gender: user.gender || '',
        date_of_birth: user.date_of_birth || '',
        country: user.country || '',
        address: user.address || '',
      },
    });
  });

  router.post('/auth/logout', requireAuth, (req: AuthRequest, res: Response) => {
    if (req.authToken) {
      db.prepare('UPDATE sessions SET is_active = 0 WHERE token = ?').run(req.authToken);
    }
    if (req.user) {
      logAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'LOGOUT',
        module: 'Auth',
        recordId: String(req.user.id),
        details: 'User signed out',
      });
    }
    res.json({ ok: true });
  });

  router.get('/auth/me', requireAuth, (req: AuthRequest, res: Response) => {
    res.json({ user: req.user });
  });

  // ==================== PROFILE & SESSIONS ====================
  router.put('/profile', requireAuth, (req: AuthRequest, res: Response) => {
    const user = req.user!;
    const {
      first_name,
      last_name,
      email,
      phone,
      username,
      photo_url,
      gender,
      date_of_birth,
      country,
      address,
    } = req.body || {};
    const finalUsername = String(username || user.username).trim();
    if (!first_name || !last_name || !finalUsername) {
      res.status(400).json({ error: 'First name, last name, and username are required' });
      return;
    }
    try {
      db.prepare(
        `UPDATE users
         SET first_name = ?, last_name = ?, email = ?, phone = ?, username = ?,
             photo_url = ?, gender = ?, date_of_birth = ?, country = ?, address = ?
         WHERE id = ?`
      ).run(
        String(first_name).trim(),
        String(last_name).trim(),
        String(email || '').trim(),
        String(phone || '').trim(),
        finalUsername,
        photo_url !== undefined ? String(photo_url || '') : String(user.photo_url || ''),
        gender !== undefined ? String(gender || '').trim() : String(user.gender || ''),
        date_of_birth !== undefined ? String(date_of_birth || '').trim() : String(user.date_of_birth || ''),
        country !== undefined ? String(country || '').trim() : String(user.country || ''),
        address !== undefined ? String(address || '').trim() : String(user.address || ''),
        user.id
      );

      logAudit({
        userId: user.id,
        username: finalUsername,
        action: 'UPDATE',
        module: 'Profile',
        recordId: String(user.id),
        details: 'Updated personal profile details',
      });

      const updated = db
        .prepare(
          `SELECT id, first_name, last_name, username, email, phone, role, permissions_json,
                  is_active, two_factor_enabled, photo_url, gender, date_of_birth, country, address
           FROM users WHERE id = ?`
        )
        .get(user.id) as AuthUser & { permissions_json: string };
      res.json({
        user: {
          ...updated,
          permissions: JSON.parse(updated.permissions_json || '[]'),
        },
      });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to update profile' });
    }
  });

  router.put('/profile/password', requireAuth, (req: AuthRequest, res: Response) => {
    const user = req.user!;
    const { currentPassword, newPassword } = req.body || {};
    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current and new passwords are required' });
      return;
    }
    const settings = db.prepare('SELECT min_password_length FROM settings WHERE id = 1').get() as { min_password_length: number };
    if (String(newPassword).length < (settings?.min_password_length || 6)) {
      res.status(400).json({ error: `Password must be at least ${settings?.min_password_length || 6} characters` });
      return;
    }
    const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(user.id) as { password_hash: string };
    if (!verifyPassword(String(currentPassword), row.password_hash)) {
      res.status(400).json({ error: 'Current password is incorrect' });
      return;
    }
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(String(newPassword)), user.id);
    logAudit({
      userId: user.id,
      username: user.username,
      action: 'PASSWORD_CHANGE',
      module: 'Profile',
      recordId: String(user.id),
      details: 'Changed personal password',
    });
    res.json({ ok: true });
  });

  router.get('/profile/2fa', requireAuth, (req: AuthRequest, res: Response) => {
    const row = db
      .prepare('SELECT two_factor_enabled, two_factor_secret FROM users WHERE id = ?')
      .get(req.user!.id) as { two_factor_enabled: number; two_factor_secret: string } | undefined;
    res.json({
      two_factor_enabled: row?.two_factor_enabled || 0,
      secret: row?.two_factor_enabled ? row.two_factor_secret || '' : '',
    });
  });

  router.put('/profile/2fa', requireAuth, (req: AuthRequest, res: Response) => {
    const user = req.user!;
    const { enabled } = req.body || {};
    const secret = enabled ? crypto.randomBytes(10).toString('hex').toUpperCase() : '';
    db.prepare('UPDATE users SET two_factor_enabled = ?, two_factor_secret = ? WHERE id = ?').run(
      enabled ? 1 : 0,
      secret,
      user.id
    );
    logAudit({
      userId: user.id,
      username: user.username,
      action: enabled ? 'ENABLE_2FA' : 'DISABLE_2FA',
      module: 'Profile',
      recordId: String(user.id),
      details: enabled ? 'Enabled Two-Factor Authentication' : 'Disabled Two-Factor Authentication',
    });
    res.json({ two_factor_enabled: enabled ? 1 : 0, secret });
  });

  router.get('/sessions', requireAuth, (req: AuthRequest, res: Response) => {
    const rows = db
      .prepare('SELECT token, ip_info, user_agent, created_at, expires_at, is_active FROM sessions WHERE user_id = ? AND is_active = 1 ORDER BY created_at DESC')
      .all(req.user!.id) as Array<{
      token: string;
      ip_info: string;
      user_agent: string;
      created_at: string;
      expires_at: string;
      is_active: number;
    }>;
    res.json({
      sessions: rows.map((r) => ({
        id: r.token.slice(0, 12),
        tokenPrefix: r.token.slice(0, 12),
        isCurrent: r.token === req.authToken,
        ip_info: r.ip_info,
        user_agent: r.user_agent,
        created_at: r.created_at,
        expires_at: r.expires_at,
      })),
    });
  });

  router.delete('/sessions/:prefix', requireAuth, (req: AuthRequest, res: Response) => {
    const prefix = String(req.params.prefix || '');
    if (prefix === 'others') {
      db.prepare('UPDATE sessions SET is_active = 0 WHERE user_id = ? AND token != ?').run(req.user!.id, req.authToken || '');
    } else {
      db.prepare('UPDATE sessions SET is_active = 0 WHERE user_id = ? AND token LIKE ?').run(req.user!.id, `${prefix}%`);
    }
    res.json({ ok: true });
  });

  // ==================== DASHBOARD ====================
  router.get('/dashboard', requireAuth, (req: AuthRequest, res: Response) => {
    const range = String(req.query.range || 'this_month');
    const customStart = req.query.start ? String(req.query.start) : undefined;
    const customEnd = req.query.end ? String(req.query.end) : undefined;
    const { start, end } = getDateRangeBounds(range, customStart, customEnd);

    const salesStats = db
      .prepare(
        `SELECT
          COALESCE(SUM(grand_total * exchange_rate), 0) as total_sales_gross,
          COALESCE(SUM((subtotal - discount_amount) * exchange_rate), 0) as net_sales_before_vat,
          COALESCE(SUM(vat_amount * exchange_rate), 0) as sales_vat,
          COUNT(*) as sales_count
         FROM sales
         WHERE status NOT IN ('Held', 'Cancelled') AND sale_date BETWEEN ? AND ?`
      )
      .get(start, end) as { total_sales_gross: number; net_sales_before_vat: number; sales_vat: number; sales_count: number };

    const returnsStats = db
      .prepare(
        `SELECT COALESCE(SUM(sr.total_refund * s.exchange_rate), 0) as total_returns
         FROM sale_returns sr
         JOIN sales s ON s.id = sr.sale_id
         WHERE sr.return_date BETWEEN ? AND ?`
      )
      .get(start, end) as { total_returns: number };

    const cogsStats = db
      .prepare(
        `SELECT COALESCE(SUM((si.quantity - si.returned_qty) * si.cost_price), 0) as cogs
         FROM sale_items si
         JOIN sales s ON s.id = si.sale_id
         WHERE s.status NOT IN ('Held', 'Cancelled') AND s.sale_date BETWEEN ? AND ?`
      )
      .get(start, end) as { cogs: number };

    const purchaseStats = db
      .prepare(
        `SELECT COALESCE(SUM(grand_total * exchange_rate), 0) as total_purchases, COUNT(*) as purchase_count
         FROM purchases
         WHERE purchase_date BETWEEN ? AND ?`
      )
      .get(start, end) as { total_purchases: number; purchase_count: number };

    const expenseStats = db
      .prepare(
        `SELECT COALESCE(SUM(amount_etb), 0) as total_expenses, COUNT(*) as expense_count
         FROM expenses
         WHERE expense_date BETWEEN ? AND ?`
      )
      .get(start, end) as { total_expenses: number; expense_count: number };

    // Other Income / Other Expenses from journal lines in date range (accounts 4200 / non-6000)
    const otherIncomeRow = db
      .prepare(
        `SELECT COALESCE(SUM(jl.credit - jl.debit), 0) as amt
         FROM journal_lines jl
         JOIN journal_entries je ON je.id = jl.journal_entry_id
         JOIN accounts a ON a.id = jl.account_id
         WHERE a.code = '4200' AND je.entry_date BETWEEN ? AND ?`
      )
      .get(start, end) as { amt: number };

    const debtRow = db
      .prepare(
        `SELECT
          (SELECT COALESCE(SUM(outstanding_balance), 0) FROM customers) as customer_debt,
          (SELECT COALESCE(SUM(outstanding_balance), 0) FROM suppliers) as supplier_debt,
          (SELECT COALESCE(SUM(current_stock * purchase_price), 0) FROM products WHERE is_active = 1) as inventory_value`
      )
      .get() as { customer_debt: number; supplier_debt: number; inventory_value: number };

    const totalSales = Math.max(0, salesStats.total_sales_gross - returnsStats.total_returns);
    const salesRevenueExVat = Math.max(0, salesStats.net_sales_before_vat - returnsStats.total_returns / 1.15);
    const cogs = cogsStats.cogs;
    const grossProfit = salesRevenueExVat - cogs;
    const operatingExpenses = expenseStats.total_expenses;
    const otherIncome = otherIncomeRow.amt || 0;
    const otherExpenses = 0;
    const netProfit = grossProfit + otherIncome - operatingExpenses - otherExpenses;
    const netProfitMargin = salesRevenueExVat > 0 ? (netProfit / salesRevenueExVat) * 100 : 0;

    // Daily/Period chart data
    const salesByDate = db
      .prepare(
        `SELECT sale_date as date, COALESCE(SUM(grand_total * exchange_rate), 0) as total
         FROM sales
         WHERE status NOT IN ('Held', 'Cancelled') AND sale_date BETWEEN ? AND ?
         GROUP BY sale_date ORDER BY sale_date ASC`
      )
      .all(start, end) as Array<{ date: string; total: number }>;

    const purchasesByDate = db
      .prepare(
        `SELECT purchase_date as date, COALESCE(SUM(grand_total * exchange_rate), 0) as total
         FROM purchases
         WHERE purchase_date BETWEEN ? AND ?
         GROUP BY purchase_date ORDER BY purchase_date ASC`
      )
      .all(start, end) as Array<{ date: string; total: number }>;

    // Monthly profit chart (last 6 months / year)
    const currentYear = addisDate().slice(0, 4);
    const monthlySales = db
      .prepare(
        `SELECT substr(s.sale_date, 1, 7) as month,
                COALESCE(SUM((si.quantity - si.returned_qty) * si.unit_price * s.exchange_rate), 0) as revenue,
                COALESCE(SUM((si.quantity - si.returned_qty) * si.cost_price), 0) as cogs
         FROM sale_items si
         JOIN sales s ON s.id = si.sale_id
         WHERE s.status NOT IN ('Held', 'Cancelled') AND substr(s.sale_date, 1, 4) = ?
         GROUP BY month ORDER BY month ASC`
      )
      .all(currentYear) as Array<{ month: string; revenue: number; cogs: number }>;

    const monthlyExpenses = db
      .prepare(
        `SELECT substr(expense_date, 1, 7) as month, COALESCE(SUM(amount_etb), 0) as expenses
         FROM expenses WHERE substr(expense_date, 1, 4) = ?
         GROUP BY month ORDER BY month ASC`
      )
      .all(currentYear) as Array<{ month: string; expenses: number }>;

    const monthlyMap = new Map<string, { month: string; revenue: number; profit: number }>();
    for (let i = 1; i <= 12; i++) {
      const mKey = `${currentYear}-${String(i).padStart(2, '0')}`;
      monthlyMap.set(mKey, { month: mKey, revenue: 0, profit: 0 });
    }
    for (const ms of monthlySales) {
      const entry = monthlyMap.get(ms.month);
      if (entry) {
        entry.revenue = ms.revenue;
        entry.profit += ms.revenue - ms.cogs;
      }
    }
    for (const me of monthlyExpenses) {
      const entry = monthlyMap.get(me.month);
      if (entry) {
        entry.profit -= me.expenses;
      }
    }

    // Top 10 Selling Products
    const topProducts = db
      .prepare(
        `SELECT p.id, p.name, p.sku, p.unit,
                COALESCE(SUM(si.quantity - si.returned_qty), 0) as qty_sold,
                COALESCE(SUM(si.subtotal * s.exchange_rate), 0) as total_revenue
         FROM sale_items si
         JOIN sales s ON s.id = si.sale_id
         JOIN products p ON p.id = si.product_id
         WHERE s.status NOT IN ('Held', 'Cancelled') AND s.sale_date BETWEEN ? AND ?
         GROUP BY p.id
         ORDER BY qty_sold DESC
         LIMIT 10`
      )
      .all(start, end);

    // Low Stock Alerts
    const lowStockProducts = db
      .prepare(
        `SELECT p.id, p.name, p.sku, p.current_stock, p.min_stock, p.unit, c.name as category_name
         FROM products p
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.is_active = 1 AND p.current_stock <= p.min_stock
         ORDER BY p.current_stock ASC
         LIMIT 15`
      )
      .all();

    // Sales Distribution by Category
    const categorySales = db
      .prepare(
        `SELECT COALESCE(c.name, 'Uncategorized') as category,
                COALESCE(SUM(si.subtotal * s.exchange_rate), 0) as total
         FROM sale_items si
         JOIN sales s ON s.id = si.sale_id
         JOIN products p ON p.id = si.product_id
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE s.status NOT IN ('Held', 'Cancelled') AND s.sale_date BETWEEN ? AND ?
         GROUP BY category
         ORDER BY total DESC`
      )
      .all(start, end);

    // Recent Transactions
    const recentTransactions = db
      .prepare(
        `SELECT 'Sale' as type, invoice_number as ref, sale_date as date, grand_total, currency, status, created_at
         FROM sales WHERE status NOT IN ('Held')
         UNION ALL
         SELECT 'Purchase' as type, purchase_number as ref, purchase_date as date, grand_total, currency, status, created_at
         FROM purchases
         UNION ALL
         SELECT 'Expense' as type, expense_code as ref, expense_date as date, amount as grand_total, currency, category as status, created_at
         FROM expenses
         ORDER BY created_at DESC LIMIT 10`
      )
      .all();

    const recentActivities = db
      .prepare('SELECT id, username, action, module, record_id, details, created_at FROM audit_logs ORDER BY id DESC LIMIT 12')
      .all();

    res.json({
      range: { start, end },
      cards: {
        totalSales,
        totalPurchases: purchaseStats.total_purchases,
        totalExpenses: operatingExpenses,
        grossProfit,
        netProfit,
        customerDebt: debtRow.customer_debt,
        supplierDebt: debtRow.supplier_debt,
        inventoryValue: debtRow.inventory_value,
      },
      financials: {
        salesRevenue: salesRevenueExVat,
        cogs,
        grossProfit,
        operatingExpenses,
        otherIncome,
        otherExpenses,
        netProfit,
        netProfitMargin,
      },
      charts: {
        salesByDate,
        purchasesByDate,
        monthlyProfit: Array.from(monthlyMap.values()),
        categorySales,
      },
      topProducts,
      lowStockProducts,
      recentTransactions,
      recentActivities,
    });
  });

  // ==================== CATALOG: CATEGORIES & PRODUCTS ====================
  router.get('/categories', requireAuth, (_req: Request, res: Response) => {
    const categories = db.prepare('SELECT * FROM categories ORDER BY name ASC').all();
    res.json({ categories });
  });

  router.post('/categories', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const { name, description } = req.body || {};
    if (!name || !String(name).trim()) {
      res.status(400).json({ error: 'Category name is required' });
      return;
    }
    try {
      const info = db
        .prepare('INSERT INTO categories (name, description, created_at) VALUES (?, ?, ?)')
        .run(String(name).trim(), String(description || '').trim(), addisDateTime());
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Category', recordId: String(info.lastInsertRowid), details: name });
      res.status(201).json({ id: info.lastInsertRowid });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Duplicate category' });
    }
  });

  router.put('/categories/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const { name, description } = req.body || {};
    if (!name) {
      res.status(400).json({ error: 'Category name is required' });
      return;
    }
    db.prepare('UPDATE categories SET name = ?, description = ? WHERE id = ?').run(String(name).trim(), String(description || '').trim(), req.params.id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Category', recordId: String(req.params.id), details: name });
    res.json({ ok: true });
  });

  router.delete('/categories/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    db.prepare('DELETE FROM categories WHERE id = ?').run(req.params.id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Category', recordId: String(req.params.id), details: 'Deleted category' });
    res.json({ ok: true });
  });

  // ==================== CATALOG: UNITS & VAT RATES ====================
  router.get('/units', requireAuth, (_req: Request, res: Response) => {
    const units = db.prepare('SELECT * FROM units ORDER BY id ASC').all();
    res.json({ units });
  });

  router.post('/units', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const { unit_name, short_name, description } = req.body || {};
    if (!unit_name || !short_name) {
      res.status(400).json({ error: 'Unit name and short name are required' });
      return;
    }
    try {
      const info = db
        .prepare('INSERT INTO units (unit_name, short_name, description, created_at) VALUES (?, ?, ?, ?)')
        .run(String(unit_name).trim(), String(short_name).trim(), String(description || '').trim(), addisDateTime());
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Unit', recordId: String(info.lastInsertRowid), details: `${unit_name} (${short_name})` });
      res.status(201).json({ id: info.lastInsertRowid });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unit already exists' });
    }
  });

  router.put('/units/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const { unit_name, short_name, description } = req.body || {};
    if (!unit_name || !short_name) {
      res.status(400).json({ error: 'Unit name and short name are required' });
      return;
    }
    try {
      db.prepare('UPDATE units SET unit_name = ?, short_name = ?, description = ? WHERE id = ?').run(
        String(unit_name).trim(),
        String(short_name).trim(),
        String(description || '').trim(),
        req.params.id
      );
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Unit', recordId: String(req.params.id), details: unit_name });
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to update unit' });
    }
  });

  router.delete('/units/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    db.prepare('DELETE FROM units WHERE id = ?').run(req.params.id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Unit', recordId: String(req.params.id), details: 'Deleted unit' });
    res.json({ ok: true });
  });

  router.get('/vat-rates', requireAuth, (_req: Request, res: Response) => {
    const vatRates = db.prepare('SELECT * FROM vat_rates ORDER BY is_default DESC, percentage DESC, id ASC').all();
    res.json({ vatRates });
  });

  router.post('/vat-rates', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const { name, percentage, vat_type, is_default } = req.body || {};
    const pct = Number(percentage ?? 0);
    if (!name || Number.isNaN(pct) || pct < 0 || pct > 100) {
      res.status(400).json({ error: 'VAT name and valid percentage (0-100) are required' });
      return;
    }
    try {
      const tx = db.transaction(() => {
        if (is_default) db.prepare('UPDATE vat_rates SET is_default = 0').run();
        const info = db
          .prepare('INSERT INTO vat_rates (name, percentage, vat_type, is_default, created_at) VALUES (?, ?, ?, ?, ?)')
          .run(String(name).trim(), pct, String(vat_type || 'Standard').trim(), is_default ? 1 : 0, addisDateTime());
        if (is_default) db.prepare('UPDATE settings SET vat_rate = ? WHERE id = 1').run(pct);
        logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'VAT', recordId: String(info.lastInsertRowid), details: `${name} (${pct}%)` });
        return info.lastInsertRowid;
      });
      res.status(201).json({ id: tx() });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'VAT rate already exists' });
    }
  });

  router.put('/vat-rates/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const { name, percentage, vat_type, is_default } = req.body || {};
    const pct = Number(percentage ?? 0);
    if (!name || Number.isNaN(pct) || pct < 0 || pct > 100) {
      res.status(400).json({ error: 'VAT name and valid percentage (0-100) are required' });
      return;
    }
    try {
      const tx = db.transaction(() => {
        if (is_default) db.prepare('UPDATE vat_rates SET is_default = 0').run();
        db.prepare('UPDATE vat_rates SET name = ?, percentage = ?, vat_type = ?, is_default = ? WHERE id = ?').run(
          String(name).trim(),
          pct,
          String(vat_type || 'Standard').trim(),
          is_default ? 1 : 0,
          req.params.id
        );
        if (is_default) db.prepare('UPDATE settings SET vat_rate = ? WHERE id = 1').run(pct);
        logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'VAT', recordId: String(req.params.id), details: `${name} (${pct}%)` });
      });
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to update VAT rate' });
    }
  });

  router.delete('/vat-rates/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    db.prepare('DELETE FROM vat_rates WHERE id = ?').run(req.params.id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'VAT', recordId: String(req.params.id), details: 'Deleted VAT rate' });
    res.json({ ok: true });
  });

  router.get('/products', requireAuth, (req: Request, res: Response) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    const categoryId = req.query.category_id ? Number(req.query.category_id) : null;
    const activeOnly = req.query.active === '1';

    let sql = `
      SELECT p.*, c.name as category_name, w.name as warehouse_name
      FROM products p
      LEFT JOIN categories c ON c.id = p.category_id
      LEFT JOIN warehouses w ON w.id = p.warehouse_id
      WHERE 1=1
    `;
    const params: unknown[] = [];
    if (q) {
      sql += ` AND (LOWER(p.name) LIKE ? OR LOWER(p.sku) LIKE ? OR LOWER(p.barcode) LIKE ? OR LOWER(COALESCE(p.product_code, '')) LIKE ?)`;
      params.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`);
    }
    if (categoryId) {
      sql += ` AND p.category_id = ?`;
      params.push(categoryId);
    }
    if (activeOnly) {
      sql += ` AND p.is_active = 1`;
    }
    sql += ` ORDER BY p.id DESC`;

    const products = db.prepare(sql).all(...params);
    res.json({ products });
  });

  router.get('/products/barcode/:code', requireAuth, (req: Request, res: Response) => {
    const code = String(req.params.code || '').trim();
    const product = db
      .prepare(
        `SELECT p.*, c.name as category_name
         FROM products p LEFT JOIN categories c ON c.id = p.category_id
         WHERE (p.barcode = ? OR p.sku = ? OR p.product_code = ?) AND p.is_active = 1`
      )
      .get(code, code, code);
    if (!product) {
      res.status(404).json({ error: 'Product not found for barcode/SKU' });
      return;
    }
    res.json({ product });
  });

  router.post('/products', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const b = req.body || {};
    if (!b.name || !b.sku) {
      res.status(400).json({ error: 'Product name and SKU are required' });
      return;
    }
    const now = addisDateTime();
    const barcode = (b.barcode && String(b.barcode).trim()) || String(b.sku).trim();
    const productCode = (b.product_code && String(b.product_code).trim()) || String(b.sku).trim();
    const stock = Number(b.current_stock || 0);
    const purchasePrice = Number(b.purchase_price || 0);

    try {
      const tx = db.transaction(() => {
        const info = db
          .prepare(
            `INSERT INTO products (name, product_code, sku, barcode, category_id, unit, purchase_price, selling_price, wholesale_price, vat_rate, current_stock, min_stock, warehouse_id, expiry_date, image_url, description, is_active, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
          .run(
            String(b.name).trim(),
            productCode,
            String(b.sku).trim(),
            barcode,
            b.category_id ? Number(b.category_id) : null,
            b.unit || 'PC',
            purchasePrice,
            Number(b.selling_price || 0),
            Number(b.wholesale_price || b.selling_price || 0),
            b.vat_rate !== undefined ? Number(b.vat_rate) : 15,
            stock,
            Number(b.min_stock ?? 5),
            Number(b.warehouse_id || 1),
            b.expiry_date || '',
            b.image_url || '',
            b.description || '',
            b.is_active === 0 || b.is_active === false ? 0 : 1,
            now,
            now
          );
        const productId = Number(info.lastInsertRowid);
        if (stock > 0) {
          db.prepare(
            `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
             VALUES (?, ?, 'OPENING', ?, ?, 'product', ?, 'Opening stock on product creation', ?, ?)`
          ).run(productId, Number(b.warehouse_id || 1), stock, purchasePrice, String(productId), req.user!.username, now);
        }
        checkLowStockNotification(productId);
        logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Product', recordId: String(productId), details: `Created ${b.name} (${b.sku})` });
        return productId;
      });
      const id = tx();
      res.status(201).json({ id });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to save product (check duplicate SKU/barcode)' });
    }
  });

  router.put('/products/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Product not found' });
      return;
    }
    const b = req.body || {};
    const now = addisDateTime();
    try {
      db.prepare(
        `UPDATE products
         SET name = ?, product_code = ?, sku = ?, barcode = ?, category_id = ?, unit = ?, purchase_price = ?, selling_price = ?, wholesale_price = ?, vat_rate = ?, min_stock = ?, warehouse_id = ?, expiry_date = ?, image_url = ?, description = ?, is_active = ?, updated_at = ?
         WHERE id = ?`
      ).run(
        b.name ?? existing.name,
        b.product_code !== undefined ? b.product_code : (existing.product_code || existing.sku),
        b.sku ?? existing.sku,
        b.barcode ?? existing.barcode,
        b.category_id !== undefined ? (b.category_id ? Number(b.category_id) : null) : existing.category_id,
        b.unit ?? existing.unit,
        b.purchase_price !== undefined ? Number(b.purchase_price) : existing.purchase_price,
        b.selling_price !== undefined ? Number(b.selling_price) : existing.selling_price,
        b.wholesale_price !== undefined ? Number(b.wholesale_price) : existing.wholesale_price,
        b.vat_rate !== undefined ? Number(b.vat_rate) : existing.vat_rate,
        b.min_stock !== undefined ? Number(b.min_stock) : existing.min_stock,
        b.warehouse_id !== undefined ? Number(b.warehouse_id) : existing.warehouse_id,
        b.expiry_date !== undefined ? b.expiry_date : existing.expiry_date,
        b.image_url !== undefined ? b.image_url : existing.image_url,
        b.description !== undefined ? b.description : existing.description,
        b.is_active !== undefined ? (b.is_active ? 1 : 0) : existing.is_active,
        now,
        id
      );
      checkLowStockNotification(id);
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Product', recordId: String(id), details: `Updated product ${b.name ?? existing.name}` });
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to update product' });
    }
  });

  router.delete('/products/:id', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const usedInSales = db.prepare('SELECT COUNT(*) as c FROM sale_items WHERE product_id = ?').get(id) as { c: number };
    const usedInPurchases = db.prepare('SELECT COUNT(*) as c FROM purchase_items WHERE product_id = ?').get(id) as { c: number };
    if (usedInSales.c > 0 || usedInPurchases.c > 0) {
      // Soft-deactivate instead of breaking historical invoices
      db.prepare('UPDATE products SET is_active = 0, updated_at = ? WHERE id = ?').run(addisDateTime(), id);
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DEACTIVATE', module: 'Product', recordId: String(id), details: 'Deactivated product with transaction history' });
      res.json({ ok: true, deactivated: true });
      return;
    }
    db.prepare('DELETE FROM products WHERE id = ?').run(id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Product', recordId: String(id), details: 'Deleted unused product' });
    res.json({ ok: true });
  });

  router.post('/products/import', requireAuth, requirePermission('catalog.manage'), (req: AuthRequest, res: Response) => {
    const { rows } = req.body || {};
    if (!Array.isArray(rows) || rows.length === 0) {
      res.status(400).json({ error: 'No product rows provided' });
      return;
    }
    const now = addisDateTime();
    let imported = 0;
    const tx = db.transaction(() => {
      for (const r of rows) {
        if (!r.name || !r.sku) continue;
        let catId: number | null = null;
        if (r.category) {
          const cat = db.prepare('SELECT id FROM categories WHERE LOWER(name) = LOWER(?)').get(String(r.category).trim()) as { id: number } | undefined;
          if (cat) catId = cat.id;
          else {
            const ci = db.prepare('INSERT INTO categories (name, created_at) VALUES (?, ?)').run(String(r.category).trim(), now);
            catId = Number(ci.lastInsertRowid);
          }
        }
        const existing = db.prepare('SELECT id FROM products WHERE sku = ?').get(String(r.sku).trim()) as { id: number } | undefined;
        if (existing) {
          db.prepare(
            `UPDATE products SET name = ?, barcode = ?, category_id = COALESCE(?, category_id), unit = ?, purchase_price = ?, selling_price = ?, wholesale_price = ?, vat_rate = ?, min_stock = ?, updated_at = ? WHERE id = ?`
          ).run(
            String(r.name).trim(),
            String(r.barcode || r.sku).trim(),
            catId,
            r.unit || 'PC',
            Number(r.purchase_price || 0),
            Number(r.selling_price || 0),
            Number(r.wholesale_price || r.selling_price || 0),
            Number(r.vat_rate ?? 15),
            Number(r.min_stock ?? 5),
            now,
            existing.id
          );
        } else {
          db.prepare(
            `INSERT INTO products (name, sku, barcode, category_id, unit, purchase_price, selling_price, wholesale_price, vat_rate, current_stock, min_stock, warehouse_id, is_active, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?, ?)`
          ).run(
            String(r.name).trim(),
            String(r.sku).trim(),
            String(r.barcode || r.sku).trim(),
            catId,
            r.unit || 'PC',
            Number(r.purchase_price || 0),
            Number(r.selling_price || 0),
            Number(r.wholesale_price || r.selling_price || 0),
            Number(r.vat_rate ?? 15),
            Number(r.current_stock || 0),
            Number(r.min_stock ?? 5),
            now,
            now
          );
        }
        imported++;
      }
    });
    tx();
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'IMPORT', module: 'Product', details: `Imported ${imported} products` });
    res.json({ imported });
  });

  // ==================== INVENTORY & WAREHOUSES ====================
  router.get('/warehouses', requireAuth, (_req: Request, res: Response) => {
    const warehouses = db.prepare('SELECT * FROM warehouses ORDER BY is_default DESC, name ASC').all();
    res.json({ warehouses });
  });

  router.post('/warehouses', requireAuth, requirePermission('inventory.manage'), (req: AuthRequest, res: Response) => {
    const { name, location } = req.body || {};
    if (!name) {
      res.status(400).json({ error: 'Warehouse name is required' });
      return;
    }
    try {
      const info = db
        .prepare('INSERT INTO warehouses (name, location, is_default, created_at) VALUES (?, ?, 0, ?)')
        .run(String(name).trim(), String(location || '').trim(), addisDateTime());
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Warehouse', recordId: String(info.lastInsertRowid), details: name });
      res.status(201).json({ id: info.lastInsertRowid });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Warehouse already exists' });
    }
  });

  router.get('/inventory/valuation', requireAuth, (_req: Request, res: Response) => {
    const summary = db
      .prepare(
        `SELECT
          COUNT(*) as total_products,
          COALESCE(SUM(current_stock), 0) as total_units,
          COALESCE(SUM(current_stock * purchase_price), 0) as total_cost_value,
          COALESCE(SUM(current_stock * selling_price), 0) as total_retail_value,
          COALESCE(SUM(CASE WHEN current_stock <= min_stock THEN 1 ELSE 0 END), 0) as low_stock_count,
          COALESCE(SUM(CASE WHEN current_stock <= 0 THEN 1 ELSE 0 END), 0) as out_of_stock_count
         FROM products WHERE is_active = 1`
      )
      .get();

    const today = addisDate();
    const soon = addisDate(60);
    const expiring = db
      .prepare(
        `SELECT id, name, sku, current_stock, unit, expiry_date
         FROM products
         WHERE is_active = 1 AND expiry_date != '' AND expiry_date <= ?
         ORDER BY expiry_date ASC`
      )
      .all(soon);

    res.json({ summary, expiring, today });
  });

  router.get('/inventory/low-stock', requireAuth, (_req: Request, res: Response) => {
    const items = db
      .prepare(
        `SELECT p.*, c.name as category_name, w.name as warehouse_name
         FROM products p
         LEFT JOIN categories c ON c.id = p.category_id
         LEFT JOIN warehouses w ON w.id = p.warehouse_id
         WHERE p.is_active = 1 AND p.current_stock <= p.min_stock
         ORDER BY p.current_stock ASC, p.name ASC`
      )
      .all();
    res.json({ items });
  });

  router.get('/inventory/movements', requireAuth, (req: Request, res: Response) => {
    const productId = req.query.product_id ? Number(req.query.product_id) : null;
    let sql = `
      SELECT m.*, p.name as product_name, p.sku, p.unit, w.name as warehouse_name
      FROM stock_movements m
      JOIN products p ON p.id = m.product_id
      LEFT JOIN warehouses w ON w.id = m.warehouse_id
      WHERE 1=1
    `;
    const params: unknown[] = [];
    if (productId) {
      sql += ' AND m.product_id = ?';
      params.push(productId);
    }
    sql += ' ORDER BY m.id DESC LIMIT 300';
    const movements = db.prepare(sql).all(...params);
    res.json({ movements });
  });

  router.post('/inventory/adjust', requireAuth, requirePermission('inventory.manage'), (req: AuthRequest, res: Response) => {
    const { product_id, warehouse_id, adjustment_type, quantity, notes } = req.body || {};
    const qty = Number(quantity || 0);
    if (!product_id || qty <= 0) {
      res.status(400).json({ error: 'Product and positive quantity are required' });
      return;
    }

    const tx = db.transaction(() => {
      const prod = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(product_id)) as
        | { id: number; name: string; current_stock: number; purchase_price: number; warehouse_id: number }
        | undefined;
      if (!prod) throw new Error('Product not found');

      const settings = db.prepare('SELECT allow_negative_stock FROM settings WHERE id = 1').get() as { allow_negative_stock: number };
      const isAdd = adjustment_type === 'IN';
      if (!isAdd && prod.current_stock - qty < 0 && !settings.allow_negative_stock) {
        throw new Error(`Insufficient stock for ${prod.name}. Available: ${prod.current_stock}`);
      }

      const delta = isAdd ? qty : -qty;
      const now = addisDateTime();
      db.prepare('UPDATE products SET current_stock = current_stock + ?, updated_at = ? WHERE id = ?').run(delta, now, prod.id);
      db.prepare(
        `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, 'adjustment', '', ?, ?, ?)`
      ).run(
        prod.id,
        Number(warehouse_id || prod.warehouse_id || 1),
        isAdd ? 'ADJUSTMENT_IN' : 'ADJUSTMENT_OUT',
        qty,
        prod.purchase_price,
        notes || (isAdd ? 'Manual Stock In' : 'Manual Stock Out'),
        req.user!.username,
        now
      );

      checkLowStockNotification(prod.id);
      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: isAdd ? 'STOCK_IN' : 'STOCK_OUT',
        module: 'Inventory',
        recordId: String(prod.id),
        details: `${isAdd ? '+' : '-'}${qty} ${prod.name}: ${notes || ''}`,
      });
    });

    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Stock adjustment failed' });
    }
  });

  router.post('/inventory/transfer', requireAuth, requirePermission('inventory.manage'), (req: AuthRequest, res: Response) => {
    const { product_id, from_warehouse_id, to_warehouse_id, quantity, notes } = req.body || {};
    const qty = Number(quantity || 0);
    if (!product_id || !from_warehouse_id || !to_warehouse_id || qty <= 0) {
      res.status(400).json({ error: 'Valid product, source warehouse, destination warehouse, and quantity are required' });
      return;
    }
    if (Number(from_warehouse_id) === Number(to_warehouse_id)) {
      res.status(400).json({ error: 'Source and destination warehouses must be different' });
      return;
    }

    const tx = db.transaction(() => {
      const prod = db.prepare('SELECT id, name, current_stock, purchase_price FROM products WHERE id = ?').get(Number(product_id)) as
        | { id: number; name: string; current_stock: number; purchase_price: number }
        | undefined;
      if (!prod) throw new Error('Product not found');
      if (prod.current_stock < qty) throw new Error(`Cannot transfer ${qty}; only ${prod.current_stock} in stock.`);

      const now = addisDateTime();
      db.prepare('UPDATE products SET warehouse_id = ?, updated_at = ? WHERE id = ?').run(Number(to_warehouse_id), now, prod.id);
      db.prepare(
        `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
         VALUES (?, ?, 'TRANSFER_OUT', ?, ?, 'transfer', ?, ?, ?, ?)`
      ).run(prod.id, Number(from_warehouse_id), qty, prod.purchase_price, String(to_warehouse_id), notes || 'Warehouse transfer out', req.user!.username, now);

      db.prepare(
        `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
         VALUES (?, ?, 'TRANSFER_IN', ?, ?, 'transfer', ?, ?, ?, ?)`
      ).run(prod.id, Number(to_warehouse_id), qty, prod.purchase_price, String(from_warehouse_id), notes || 'Warehouse transfer in', req.user!.username, now);

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: 'TRANSFER',
        module: 'Inventory',
        recordId: String(prod.id),
        details: `Transferred ${qty} of ${prod.name} from WH#${from_warehouse_id} to WH#${to_warehouse_id}`,
      });
    });

    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Transfer failed' });
    }
  });

  // ==================== CUSTOMERS & SUPPLIERS ====================
  router.get('/customers', requireAuth, (_req: Request, res: Response) => {
    const customers = db.prepare('SELECT * FROM customers ORDER BY id ASC').all();
    res.json({ customers });
  });

  router.post('/customers', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const { full_name, customer_code, email, phone, address, opening_balance } = req.body || {};
    if (!full_name) {
      res.status(400).json({ error: 'Customer full name is required' });
      return;
    }
    const ob = Number(opening_balance || 0);
    const now = addisDateTime();
    const info = db
      .prepare(
        `INSERT INTO customers (full_name, customer_code, email, phone, address, opening_balance, total_purchases, total_paid, outstanding_balance, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 0, 0, ?, ?)`
      )
      .run(String(full_name).trim(), String(customer_code || '').trim(), String(email || '').trim(), phone || '', address || '', ob, ob, now);
    const custId = Number(info.lastInsertRowid);
    if (!customer_code) {
      db.prepare('UPDATE customers SET customer_code = ? WHERE id = ?').run(`CUS-${String(custId).padStart(4, '0')}`, custId);
    }
    if (ob !== 0) {
      db.prepare(
        `INSERT INTO opening_balance_entries (party_type, party_id, entry_type, amount, entry_date, notes, created_by, created_at)
         VALUES ('customer', ?, 'Opening Balance', ?, ?, 'Initial customer opening balance', ?, ?)`
      ).run(custId, ob, addisDate(), req.user!.username, now);
    }
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Customer', recordId: String(custId), details: full_name });
    res.status(201).json({ id: custId });
  });

  router.put('/customers/:id', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const { full_name, customer_code, email, phone, address } = req.body || {};
    if (!full_name) {
      res.status(400).json({ error: 'Customer name is required' });
      return;
    }
    db.prepare('UPDATE customers SET full_name = ?, customer_code = COALESCE(NULLIF(?, \'\'), customer_code), email = ?, phone = ?, address = ? WHERE id = ?').run(
      String(full_name).trim(),
      String(customer_code || '').trim(),
      String(email || '').trim(),
      phone || '',
      address || '',
      req.params.id
    );
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Customer', recordId: String(req.params.id), details: full_name });
    res.json({ ok: true });
  });

  router.delete('/customers/:id', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    if (id === 1) {
      res.status(400).json({ error: 'Walk-In Customer cannot be deleted' });
      return;
    }
    const hasSales = db.prepare('SELECT COUNT(*) as c FROM sales WHERE customer_id = ?').get(id) as { c: number };
    if (hasSales.c > 0) {
      res.status(400).json({ error: 'Cannot delete customer with recorded sales history' });
      return;
    }
    db.prepare('DELETE FROM customers WHERE id = ?').run(id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Customer', recordId: String(id), details: 'Deleted customer' });
    res.json({ ok: true });
  });

  router.post('/customers/:id/pay', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const customerId = Number(req.params.id);
    const { amount, currency, payment_method, notes, sale_id } = req.body || {};
    const amt = Number(amount || 0);
    if (amt <= 0) {
      res.status(400).json({ error: 'Payment amount must be greater than zero' });
      return;
    }

    const tx = db.transaction(() => {
      const cust = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId) as
        | { id: number; full_name: string; outstanding_balance: number }
        | undefined;
      if (!cust) throw new Error('Customer not found');

      const currCode = currency || 'ETB';
      const curr = db.prepare('SELECT exchange_rate_to_etb FROM currencies WHERE code = ?').get(currCode) as
        | { exchange_rate_to_etb: number }
        | undefined;
      const rate = curr?.exchange_rate_to_etb || 1;
      const amountEtb = Math.round(amt * rate * 100) / 100;
      const now = addisDateTime();

      db.prepare(
        `INSERT INTO customer_payments (customer_id, sale_id, amount, currency, exchange_rate, amount_etb, payment_method, notes, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(customerId, sale_id || null, amt, currCode, rate, amountEtb, payment_method || 'Cash', notes || '', req.user!.username, now);

      db.prepare('UPDATE customers SET total_paid = total_paid + ?, outstanding_balance = MAX(0, outstanding_balance - ?) WHERE id = ?').run(
        amountEtb,
        amountEtb,
        customerId
      );

      // If specific sale_id provided, apply to sale balance
      if (sale_id) {
        const sale = db.prepare('SELECT id, paid_amount, grand_total, exchange_rate FROM sales WHERE id = ?').get(Number(sale_id)) as
          | { id: number; paid_amount: number; grand_total: number; exchange_rate: number }
          | undefined;
        if (sale) {
          const addedInSaleCurrency = amountEtb / (sale.exchange_rate || 1);
          const newPaid = Math.min(sale.grand_total, sale.paid_amount + addedInSaleCurrency);
          const newBal = Math.max(0, sale.grand_total - newPaid);
          const newStatus = newBal <= 0.01 ? 'Paid' : 'Partially Paid';
          db.prepare('UPDATE sales SET paid_amount = ?, balance_amount = ?, status = ? WHERE id = ?').run(newPaid, newBal, newStatus, sale.id);
        }
      }

      postJournalEntry({
        referenceType: 'customer_payment',
        referenceId: String(customerId),
        description: `Customer debt payment from ${cust.full_name}`,
        createdBy: req.user!.username,
        lines: [
          { accountCode: paymentAccountCode(payment_method || 'Cash'), debit: amountEtb, credit: 0 },
          { accountCode: '1100', debit: 0, credit: amountEtb },
        ],
      });

      createNotification({
        type: 'CUSTOMER_PAYMENT',
        titleEn: `Customer Payment: ${cust.full_name}`,
        titleSo: `Lacag Bixin Macmiil: ${cust.full_name}`,
        messageEn: `Received ${amountEtb.toFixed(2)} ETB via ${payment_method || 'Cash'}.`,
        messageSo: `Waxaa la helay ${amountEtb.toFixed(2)} ETB oo lagu bixiyay ${payment_method || 'Cash'}.`,
        referenceType: 'customer',
        referenceId: String(customerId),
      });

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: 'PAYMENT',
        module: 'Customer',
        recordId: String(customerId),
        details: `Received ${amountEtb} ETB from ${cust.full_name}`,
      });
    });

    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Payment failed' });
    }
  });

  router.get('/customers/:id/statement', requireAuth, (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(id);
    const sales = db
      .prepare('SELECT id, invoice_number, sale_date, grand_total, paid_amount, balance_amount, currency, exchange_rate, status FROM sales WHERE customer_id = ? AND status NOT IN (\'Held\', \'Cancelled\') ORDER BY id DESC')
      .all(id);
    const payments = db
      .prepare('SELECT * FROM customer_payments WHERE customer_id = ? ORDER BY id DESC')
      .all(id);
    const openingEntries = db
      .prepare("SELECT * FROM opening_balance_entries WHERE party_type = 'customer' AND party_id = ? ORDER BY id DESC")
      .all(id);
    res.json({ customer, sales, payments, openingEntries });
  });

  router.get('/opening-balances', requireAuth, requirePermission('people.view'), (req: Request, res: Response) => {
    const partyType = req.query.party_type ? String(req.query.party_type) : '';
    let sql = `
      SELECT ob.*,
             CASE WHEN ob.party_type = 'customer' THEN c.full_name ELSE s.business_name END as party_name
      FROM opening_balance_entries ob
      LEFT JOIN customers c ON ob.party_type = 'customer' AND c.id = ob.party_id
      LEFT JOIN suppliers s ON ob.party_type = 'supplier' AND s.id = ob.party_id
      WHERE 1=1
    `;
    const params: unknown[] = [];
    if (partyType) {
      sql += ' AND ob.party_type = ?';
      params.push(partyType);
    }
    sql += ' ORDER BY ob.id DESC LIMIT 200';
    const entries = db.prepare(sql).all(...params);
    res.json({ entries });
  });

  router.post('/customers/:id/opening-balance', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const customerId = Number(req.params.id);
    const { entry_type, amount, entry_date, notes } = req.body || {};
    const amt = Number(amount || 0);
    if (amt <= 0) {
      res.status(400).json({ error: 'Amount must be greater than zero' });
      return;
    }
    const kind = entry_type === 'Credit' ? 'Credit' : entry_type === 'Debit' ? 'Debit' : 'Opening Balance';
    const tx = db.transaction(() => {
      const cust = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId) as
        | { id: number; full_name: string; outstanding_balance: number }
        | undefined;
      if (!cust) throw new Error('Customer not found');
      const now = addisDateTime();
      const eDate = entry_date || addisDate();
      const delta = kind === 'Credit' ? -amt : amt;

      const info = db
        .prepare(
          `INSERT INTO opening_balance_entries (party_type, party_id, entry_type, amount, entry_date, notes, created_by, created_at)
           VALUES ('customer', ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(customerId, kind, amt, eDate, String(notes || '').trim(), req.user!.username, now);

      db.prepare('UPDATE customers SET opening_balance = opening_balance + ?, outstanding_balance = MAX(0, outstanding_balance + ?) WHERE id = ?').run(
        delta,
        delta,
        customerId
      );

      postJournalEntry({
        entryDate: eDate,
        referenceType: 'customer_opening_balance',
        referenceId: String(info.lastInsertRowid),
        description: `Customer ${kind} (${cust.full_name}): ${notes || ''}`,
        createdBy: req.user!.username,
        lines:
          kind === 'Credit'
            ? [
                { accountCode: '3000', debit: amt, credit: 0 },
                { accountCode: '1100', debit: 0, credit: amt },
              ]
            : [
                { accountCode: '1100', debit: amt, credit: 0 },
                { accountCode: '3000', debit: 0, credit: amt },
              ],
      });

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: 'OPENING_BALANCE',
        module: 'Customer',
        recordId: String(customerId),
        details: `${kind} ${amt} ETB for ${cust.full_name}`,
      });
      return info.lastInsertRowid;
    });
    try {
      res.status(201).json({ id: tx() });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to save opening balance' });
    }
  });

  router.get('/suppliers', requireAuth, (_req: Request, res: Response) => {
    const suppliers = db.prepare('SELECT * FROM suppliers ORDER BY id ASC').all();
    res.json({ suppliers });
  });

  router.post('/suppliers', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const { business_name, supplier_code, contact_person, email, phone, address, opening_balance } = req.body || {};
    if (!business_name) {
      res.status(400).json({ error: 'Supplier business name is required' });
      return;
    }
    const ob = Number(opening_balance || 0);
    const now = addisDateTime();
    const info = db
      .prepare(
        `INSERT INTO suppliers (business_name, supplier_code, contact_person, email, phone, address, opening_balance, total_purchases, total_paid, outstanding_balance, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?)`
      )
      .run(String(business_name).trim(), String(supplier_code || '').trim(), contact_person || '', String(email || '').trim(), phone || '', address || '', ob, ob, now);
    const supId = Number(info.lastInsertRowid);
    if (!supplier_code) {
      db.prepare('UPDATE suppliers SET supplier_code = ? WHERE id = ?').run(`SUP-${String(supId).padStart(4, '0')}`, supId);
    }
    if (ob !== 0) {
      db.prepare(
        `INSERT INTO opening_balance_entries (party_type, party_id, entry_type, amount, entry_date, notes, created_by, created_at)
         VALUES ('supplier', ?, 'Opening Balance', ?, ?, 'Initial supplier opening balance', ?, ?)`
      ).run(supId, ob, addisDate(), req.user!.username, now);
    }
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Supplier', recordId: String(supId), details: business_name });
    res.status(201).json({ id: supId });
  });

  router.put('/suppliers/:id', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const { business_name, supplier_code, contact_person, email, phone, address } = req.body || {};
    if (!business_name) {
      res.status(400).json({ error: 'Supplier business name is required' });
      return;
    }
    db.prepare('UPDATE suppliers SET business_name = ?, supplier_code = COALESCE(NULLIF(?, \'\'), supplier_code), contact_person = ?, email = ?, phone = ?, address = ? WHERE id = ?').run(
      String(business_name).trim(),
      String(supplier_code || '').trim(),
      contact_person || '',
      String(email || '').trim(),
      phone || '',
      address || '',
      req.params.id
    );
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Supplier', recordId: String(req.params.id), details: business_name });
    res.json({ ok: true });
  });

  router.delete('/suppliers/:id', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const hasPur = db.prepare('SELECT COUNT(*) as c FROM purchases WHERE supplier_id = ?').get(id) as { c: number };
    if (hasPur.c > 0) {
      res.status(400).json({ error: 'Cannot delete supplier with recorded purchase history' });
      return;
    }
    db.prepare('DELETE FROM suppliers WHERE id = ?').run(id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Supplier', recordId: String(id), details: 'Deleted supplier' });
    res.json({ ok: true });
  });

  router.post('/suppliers/:id/pay', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const supplierId = Number(req.params.id);
    const { amount, currency, payment_method, notes, purchase_id } = req.body || {};
    const amt = Number(amount || 0);
    if (amt <= 0) {
      res.status(400).json({ error: 'Payment amount must be greater than zero' });
      return;
    }

    const tx = db.transaction(() => {
      const sup = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(supplierId) as
        | { id: number; business_name: string; outstanding_balance: number }
        | undefined;
      if (!sup) throw new Error('Supplier not found');

      const currCode = currency || 'ETB';
      const curr = db.prepare('SELECT exchange_rate_to_etb FROM currencies WHERE code = ?').get(currCode) as
        | { exchange_rate_to_etb: number }
        | undefined;
      const rate = curr?.exchange_rate_to_etb || 1;
      const amountEtb = Math.round(amt * rate * 100) / 100;
      const now = addisDateTime();

      db.prepare(
        `INSERT INTO supplier_payments (supplier_id, purchase_id, amount, currency, exchange_rate, amount_etb, payment_method, notes, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(supplierId, purchase_id || null, amt, currCode, rate, amountEtb, payment_method || 'Cash', notes || '', req.user!.username, now);

      db.prepare('UPDATE suppliers SET total_paid = total_paid + ?, outstanding_balance = MAX(0, outstanding_balance - ?) WHERE id = ?').run(
        amountEtb,
        amountEtb,
        supplierId
      );

      if (purchase_id) {
        const pur = db.prepare('SELECT id, paid_amount, grand_total, exchange_rate FROM purchases WHERE id = ?').get(Number(purchase_id)) as
          | { id: number; paid_amount: number; grand_total: number; exchange_rate: number }
          | undefined;
        if (pur) {
          const addedInPurCurrency = amountEtb / (pur.exchange_rate || 1);
          const newPaid = Math.min(pur.grand_total, pur.paid_amount + addedInPurCurrency);
          const newBal = Math.max(0, pur.grand_total - newPaid);
          const newStatus = newBal <= 0.01 ? 'Paid' : 'Partially Paid';
          db.prepare('UPDATE purchases SET paid_amount = ?, balance_amount = ?, status = ? WHERE id = ?').run(newPaid, newBal, newStatus, pur.id);
        }
      }

      postJournalEntry({
        referenceType: 'supplier_payment',
        referenceId: String(supplierId),
        description: `Supplier payment to ${sup.business_name}`,
        createdBy: req.user!.username,
        lines: [
          { accountCode: '2000', debit: amountEtb, credit: 0 },
          { accountCode: paymentAccountCode(payment_method || 'Cash'), debit: 0, credit: amountEtb },
        ],
      });

      createNotification({
        type: 'SUPPLIER_PAYMENT',
        titleEn: `Supplier Payment: ${sup.business_name}`,
        titleSo: `Lacag Bixin Alaab-qeebiye: ${sup.business_name}`,
        messageEn: `Paid ${amountEtb.toFixed(2)} ETB via ${payment_method || 'Cash'}.`,
        messageSo: `Waxaa la bixiyay ${amountEtb.toFixed(2)} ETB oo loo diray ${sup.business_name}.`,
        referenceType: 'supplier',
        referenceId: String(supplierId),
      });

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: 'PAYMENT',
        module: 'Supplier',
        recordId: String(supplierId),
        details: `Paid ${amountEtb} ETB to ${sup.business_name}`,
      });
    });

    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Supplier payment failed' });
    }
  });

  router.get('/suppliers/:id/statement', requireAuth, (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const supplier = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(id);
    const purchases = db
      .prepare('SELECT id, purchase_number, supplier_invoice_no, purchase_date, grand_total, paid_amount, balance_amount, currency, exchange_rate, status FROM purchases WHERE supplier_id = ? ORDER BY id DESC')
      .all(id);
    const payments = db
      .prepare('SELECT * FROM supplier_payments WHERE supplier_id = ? ORDER BY id DESC')
      .all(id);
    const openingEntries = db
      .prepare("SELECT * FROM opening_balance_entries WHERE party_type = 'supplier' AND party_id = ? ORDER BY id DESC")
      .all(id);
    res.json({ supplier, purchases, payments, openingEntries });
  });

  router.post('/suppliers/:id/opening-balance', requireAuth, requirePermission('people.manage'), (req: AuthRequest, res: Response) => {
    const supplierId = Number(req.params.id);
    const { entry_type, amount, entry_date, notes } = req.body || {};
    const amt = Number(amount || 0);
    if (amt <= 0) {
      res.status(400).json({ error: 'Amount must be greater than zero' });
      return;
    }
    const kind = entry_type === 'Debit' ? 'Debit' : entry_type === 'Credit' ? 'Credit' : 'Opening Balance';
    const tx = db.transaction(() => {
      const sup = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(supplierId) as
        | { id: number; business_name: string; outstanding_balance: number }
        | undefined;
      if (!sup) throw new Error('Supplier not found');
      const now = addisDateTime();
      const eDate = entry_date || addisDate();
      // For supplier payable: Credit / Opening Balance increases what we owe supplier; Debit reduces it
      const delta = kind === 'Debit' ? -amt : amt;

      const info = db
        .prepare(
          `INSERT INTO opening_balance_entries (party_type, party_id, entry_type, amount, entry_date, notes, created_by, created_at)
           VALUES ('supplier', ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(supplierId, kind, amt, eDate, String(notes || '').trim(), req.user!.username, now);

      db.prepare('UPDATE suppliers SET opening_balance = opening_balance + ?, outstanding_balance = MAX(0, outstanding_balance + ?) WHERE id = ?').run(
        delta,
        delta,
        supplierId
      );

      postJournalEntry({
        entryDate: eDate,
        referenceType: 'supplier_opening_balance',
        referenceId: String(info.lastInsertRowid),
        description: `Supplier ${kind} (${sup.business_name}): ${notes || ''}`,
        createdBy: req.user!.username,
        lines:
          kind === 'Debit'
            ? [
                { accountCode: '2000', debit: amt, credit: 0 },
                { accountCode: '3000', debit: 0, credit: amt },
              ]
            : [
                { accountCode: '3000', debit: amt, credit: 0 },
                { accountCode: '2000', debit: 0, credit: amt },
              ],
      });

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: 'OPENING_BALANCE',
        module: 'Supplier',
        recordId: String(supplierId),
        details: `${kind} ${amt} ETB for ${sup.business_name}`,
      });
      return info.lastInsertRowid;
    });
    try {
      res.status(201).json({ id: tx() });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to save opening balance' });
    }
  });

  // ==================== SALES & POS ====================
  router.get('/sales', requireAuth, (req: Request, res: Response) => {
    const status = req.query.status ? String(req.query.status) : '';
    const q = String(req.query.q || '').trim().toLowerCase();
    const customerId = req.query.customer_id ? Number(req.query.customer_id) : null;
    let sql = `
      SELECT s.*, c.full_name as customer_name, c.phone as customer_phone,
             COALESCE((SELECT GROUP_CONCAT(si.product_name || ' x' || CAST(si.quantity AS TEXT), ', ') FROM sale_items si WHERE si.sale_id = s.id), '') as items_summary,
             COALESCE((SELECT SUM(si.quantity) FROM sale_items si WHERE si.sale_id = s.id), 0) as total_quantity
      FROM sales s
      LEFT JOIN customers c ON c.id = s.customer_id
      WHERE 1=1
    `;
    const params: unknown[] = [];
    if (status) {
      sql += ' AND s.status = ?';
      params.push(status);
    }
    if (customerId) {
      sql += ' AND s.customer_id = ?';
      params.push(customerId);
    }
    if (q) {
      sql += ' AND (LOWER(s.invoice_number) LIKE ? OR LOWER(COALESCE(c.full_name, \'\')) LIKE ?)';
      params.push(`%${q}%`, `%${q}%`);
    }
    sql += ' ORDER BY s.id DESC LIMIT 300';
    const sales = db.prepare(sql).all(...params);
    res.json({ sales });
  });

  router.get('/sales/customer-summary', requireAuth, (_req: Request, res: Response) => {
    const summaries = db
      .prepare(
        `SELECT c.id, c.customer_code, c.full_name, c.phone, c.email, c.opening_balance, c.total_purchases, c.total_paid, c.outstanding_balance,
                COUNT(s.id) as invoice_count,
                COALESCE(SUM(s.grand_total * s.exchange_rate), 0) as total_sales_etb,
                COALESCE(SUM(s.paid_amount * s.exchange_rate), 0) as total_paid_etb,
                COALESCE(SUM(s.balance_amount * s.exchange_rate), 0) as total_due_etb
         FROM customers c
         LEFT JOIN sales s ON s.customer_id = c.id AND s.status NOT IN ('Held', 'Cancelled')
         GROUP BY c.id
         ORDER BY total_sales_etb DESC, c.id ASC`
      )
      .all();
    res.json({ summaries });
  });

  router.get('/sales/returns', requireAuth, (_req: Request, res: Response) => {
    const returns = db
      .prepare(
        `SELECT sr.*, c.full_name as customer_name,
                COALESCE((SELECT GROUP_CONCAT(sri.product_name || ' x' || CAST(sri.quantity AS TEXT), ', ') FROM sale_return_items sri WHERE sri.return_id = sr.id), '') as items_summary,
                COALESCE((SELECT SUM(sri.quantity) FROM sale_return_items sri WHERE sri.return_id = sr.id), 0) as total_quantity
         FROM sale_returns sr
         LEFT JOIN customers c ON c.id = sr.customer_id
         ORDER BY sr.id DESC LIMIT 200`
      )
      .all();
    res.json({ returns });
  });

  router.get('/sales/returns/:id', requireAuth, (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const ret = db
      .prepare(
        `SELECT sr.*, c.full_name as customer_name, c.phone as customer_phone
         FROM sale_returns sr
         LEFT JOIN customers c ON c.id = sr.customer_id
         WHERE sr.id = ?`
      )
      .get(id);
    if (!ret) {
      res.status(404).json({ error: 'Sale return not found' });
      return;
    }
    const items = db.prepare('SELECT * FROM sale_return_items WHERE return_id = ?').all(id);
    res.json({ saleReturn: ret, items });
  });

  router.get('/sales/:id', requireAuth, (req: Request, res: Response) => {
    const idOrInv = String(req.params.id);
    const sale = db
      .prepare(
        `SELECT s.*, c.full_name as customer_name, c.phone as customer_phone, c.address as customer_address
         FROM sales s
         LEFT JOIN customers c ON c.id = s.customer_id
         WHERE s.id = ? OR s.invoice_number = ?`
      )
      .get(Number(idOrInv) || -1, idOrInv) as { id: number } | undefined;

    if (!sale) {
      res.status(404).json({ error: 'Sale not found' });
      return;
    }
    const items = db.prepare('SELECT * FROM sale_items WHERE sale_id = ?').all(sale.id);
    res.json({ sale, items });
  });

  router.put('/sales/:id', requireAuth, requirePermission('sales.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const { sale_date, notes, customer_id, payment_method } = req.body || {};
    const existing = db.prepare('SELECT * FROM sales WHERE id = ?').get(id) as
      | { id: number; invoice_number: string; sale_date: string; customer_id: number; grand_total: number; paid_amount: number; balance_amount: number; exchange_rate: number; payment_method: string; status: string; notes: string }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Sale not found' });
      return;
    }
    const tx = db.transaction(() => {
      const nextCustomerId = customer_id ? Number(customer_id) : existing.customer_id;
      if (nextCustomerId !== existing.customer_id && existing.status !== 'Held' && existing.status !== 'Cancelled') {
        const gEtb = Math.round(existing.grand_total * existing.exchange_rate * 100) / 100;
        const pEtb = Math.round(existing.paid_amount * existing.exchange_rate * 100) / 100;
        const bEtb = Math.round(existing.balance_amount * existing.exchange_rate * 100) / 100;
        if (existing.customer_id) {
          db.prepare('UPDATE customers SET total_purchases = MAX(0, total_purchases - ?), total_paid = MAX(0, total_paid - ?), outstanding_balance = MAX(0, outstanding_balance - ?) WHERE id = ?').run(
            gEtb,
            pEtb,
            bEtb,
            existing.customer_id
          );
        }
        db.prepare('UPDATE customers SET total_purchases = total_purchases + ?, total_paid = total_paid + ?, outstanding_balance = outstanding_balance + ? WHERE id = ?').run(
          gEtb,
          pEtb,
          bEtb,
          nextCustomerId
        );
      }
      db.prepare('UPDATE sales SET sale_date = ?, notes = ?, customer_id = ?, payment_method = ? WHERE id = ?').run(
        sale_date || existing.sale_date,
        notes !== undefined ? String(notes) : existing.notes,
        nextCustomerId,
        payment_method || existing.payment_method,
        id
      );
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Sales', recordId: existing.invoice_number, details: `Updated sale ${existing.invoice_number}` });
    });
    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to update sale' });
    }
  });

  router.delete('/sales/:id', requireAuth, requirePermission('sales.delete'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(id) as
      | {
          id: number;
          invoice_number: string;
          sale_date: string;
          customer_id: number;
          warehouse_id: number;
          exchange_rate: number;
          vat_amount: number;
          grand_total: number;
          paid_amount: number;
          balance_amount: number;
          payment_method: string;
          status: string;
        }
      | undefined;
    if (!sale) {
      res.status(404).json({ error: 'Sale not found' });
      return;
    }
    const hasReturns = (db.prepare('SELECT COUNT(*) as c FROM sale_returns WHERE sale_id = ?').get(id) as { c: number }).c;
    if (hasReturns > 0) {
      res.status(400).json({ error: 'Cannot delete a sale that has recorded sales returns' });
      return;
    }

    const tx = db.transaction(() => {
      const now = addisDateTime();
      if (sale.status !== 'Held' && sale.status !== 'Cancelled') {
        const items = db.prepare('SELECT * FROM sale_items WHERE sale_id = ?').all(id) as Array<{
          product_id: number;
          quantity: number;
          cost_price: number;
        }>;
        let totalCogs = 0;
        for (const it of items) {
          db.prepare('UPDATE products SET current_stock = current_stock + ?, updated_at = ? WHERE id = ?').run(it.quantity, now, it.product_id);
          db.prepare(
            `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
             VALUES (?, ?, 'SALE_DELETE_RESTORE', ?, ?, 'sale_delete', ?, ?, ?, ?)`
          ).run(it.product_id, sale.warehouse_id, it.quantity, it.cost_price, sale.invoice_number, `Deleted sale ${sale.invoice_number}`, req.user!.username, now);
          totalCogs += it.quantity * it.cost_price;
        }

        const grandEtb = Math.round(sale.grand_total * sale.exchange_rate * 100) / 100;
        const paidEtb = Math.round(sale.paid_amount * sale.exchange_rate * 100) / 100;
        const balEtb = Math.max(0, Math.round((grandEtb - paidEtb) * 100) / 100);
        const vatEtb = Math.round(sale.vat_amount * sale.exchange_rate * 100) / 100;
        const revEtb = Math.max(0, Math.round((grandEtb - vatEtb) * 100) / 100);

        if (sale.customer_id) {
          db.prepare(
            'UPDATE customers SET total_purchases = MAX(0, total_purchases - ?), total_paid = MAX(0, total_paid - ?), outstanding_balance = MAX(0, outstanding_balance - ?) WHERE id = ?'
          ).run(grandEtb, paidEtb, balEtb, sale.customer_id);
        }

        const lines: Array<{ accountCode: string; debit: number; credit: number }> = [
          { accountCode: '4000', debit: revEtb, credit: 0 },
        ];
        if (vatEtb > 0) lines.push({ accountCode: '2100', debit: vatEtb, credit: 0 });
        if (paidEtb > 0) lines.push({ accountCode: paymentAccountCode(sale.payment_method || 'Cash'), debit: 0, credit: paidEtb });
        if (balEtb > 0) lines.push({ accountCode: '1100', debit: 0, credit: balEtb });
        if (totalCogs > 0) {
          const cogsRounded = Math.round(totalCogs * 100) / 100;
          lines.push({ accountCode: '1200', debit: cogsRounded, credit: 0 });
          lines.push({ accountCode: '5000', debit: 0, credit: cogsRounded });
        }

        postJournalEntry({
          entryDate: addisDate(),
          referenceType: 'sale_reversal',
          referenceId: sale.invoice_number,
          description: `Reversal of deleted sale ${sale.invoice_number}`,
          createdBy: req.user!.username,
          lines,
        });
      }

      db.prepare('DELETE FROM sales WHERE id = ?').run(id);
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Sales', recordId: sale.invoice_number, details: `Deleted sale ${sale.invoice_number}` });
    });

    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to delete sale' });
    }
  });

  router.post('/sales', requireAuth, requirePermission('sales.create'), (req: AuthRequest, res: Response) => {
    const {
      customer_id,
      warehouse_id,
      currency,
      discount_amount,
      payment_method,
      paid_amount,
      split_details,
      is_held,
      notes,
      items,
      sale_date,
    } = req.body || {};

    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Cart must contain at least one product' });
      return;
    }

    const tx = db.transaction(() => {
      const settings = db
        .prepare('SELECT sale_prefix, vat_rate, allow_negative_stock FROM settings WHERE id = 1')
        .get() as { sale_prefix: string; vat_rate: number; allow_negative_stock: number };

      const currCode = currency || 'ETB';
      const currRow = db.prepare('SELECT exchange_rate_to_etb FROM currencies WHERE code = ?').get(currCode) as
        | { exchange_rate_to_etb: number }
        | undefined;
      const exchangeRate = currRow?.exchange_rate_to_etb || 1;
      const now = addisDateTime();
      const sDate = sale_date || addisDate();

      let subtotal = 0;
      let totalVat = 0;
      let totalCogsEtb = 0;
      const computedItems: Array<{
        product_id: number;
        product_name: string;
        sku: string;
        unit: string;
        quantity: number;
        unit_price: number;
        cost_price: number;
        discount_amount: number;
        vat_rate: number;
        vat_amount: number;
        subtotal: number;
      }> = [];

      for (const item of items) {
        const qty = Number(item.quantity || 0);
        if (qty <= 0) throw new Error('Item quantity must be positive');
        const prod = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(item.product_id)) as
          | {
              id: number;
              name: string;
              sku: string;
              unit: string;
              purchase_price: number;
              selling_price: number;
              vat_rate: number;
              current_stock: number;
            }
          | undefined;
        if (!prod) throw new Error(`Product #${item.product_id} not found`);

        if (!is_held && prod.current_stock < qty && !settings.allow_negative_stock) {
          throw new Error(`Insufficient stock for ${prod.name}. Available: ${prod.current_stock} ${prod.unit}`);
        }

        const unitPrice = item.unit_price !== undefined ? Number(item.unit_price) : prod.selling_price / exchangeRate;
        const itemDiscount = Number(item.discount_amount || 0);
        const lineNet = Math.max(0, qty * unitPrice - itemDiscount);
        const vatRate = item.vat_rate !== undefined ? Number(item.vat_rate) : prod.vat_rate;
        const lineVat = Math.round(lineNet * (vatRate / 100) * 100) / 100;
        const lineTotal = Math.round((lineNet + lineVat) * 100) / 100;

        subtotal += lineNet;
        totalVat += lineVat;
        totalCogsEtb += qty * prod.purchase_price;

        computedItems.push({
          product_id: prod.id,
          product_name: prod.name,
          sku: prod.sku,
          unit: prod.unit,
          quantity: qty,
          unit_price: unitPrice,
          cost_price: prod.purchase_price,
          discount_amount: itemDiscount,
          vat_rate: vatRate,
          vat_amount: lineVat,
          subtotal: lineTotal,
        });
      }

      const overallDiscount = Number(discount_amount || 0);
      const grandTotal = Math.max(0, Math.round((subtotal - overallDiscount + totalVat) * 100) / 100);

      let paidAmt = Number(paid_amount ?? grandTotal);
      if (payment_method === 'Credit' || payment_method === 'Credit/Debt') {
        paidAmt = Number(paid_amount || 0);
      }
      paidAmt = Math.min(grandTotal, Math.max(0, Math.round(paidAmt * 100) / 100));
      const balanceAmt = Math.max(0, Math.round((grandTotal - paidAmt) * 100) / 100);

      let status = 'Paid';
      if (is_held) status = 'Held';
      else if (balanceAmt > 0.01 && paidAmt <= 0.01) status = 'Credit';
      else if (balanceAmt > 0.01) status = 'Partially Paid';

      const seq = getNextSequence('invoice_seq_sale');
      const invoiceNumber = formatCode(settings.sale_prefix || 'SAL-', seq);
      const custId = Number(customer_id || 1);

      const resSale = db
        .prepare(
          `INSERT INTO sales (invoice_number, sale_date, customer_id, warehouse_id, currency, exchange_rate, subtotal, discount_amount, vat_amount, grand_total, paid_amount, balance_amount, payment_method, split_details_json, status, notes, created_by_id, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          invoiceNumber,
          sDate,
          custId,
          Number(warehouse_id || 1),
          currCode,
          exchangeRate,
          Math.round(subtotal * 100) / 100,
          overallDiscount,
          Math.round(totalVat * 100) / 100,
          grandTotal,
          paidAmt,
          balanceAmt,
          payment_method || 'Cash',
          JSON.stringify(split_details || {}),
          status,
          notes || '',
          req.user!.id,
          req.user!.username,
          now
        );

      const saleId = Number(resSale.lastInsertRowid);

      const insertItem = db.prepare(
        `INSERT INTO sale_items (sale_id, product_id, product_name, sku, unit, quantity, unit_price, cost_price, discount_amount, vat_rate, vat_amount, subtotal)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      );

      for (const ci of computedItems) {
        insertItem.run(
          saleId,
          ci.product_id,
          ci.product_name,
          ci.sku,
          ci.unit,
          ci.quantity,
          ci.unit_price,
          ci.cost_price,
          ci.discount_amount,
          ci.vat_rate,
          ci.vat_amount,
          ci.subtotal
        );

        if (!is_held) {
          db.prepare('UPDATE products SET current_stock = current_stock - ?, updated_at = ? WHERE id = ?').run(ci.quantity, now, ci.product_id);
          db.prepare(
            `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
             VALUES (?, ?, 'SALE_OUT', ?, ?, 'sale', ?, ?, ?, ?)`
          ).run(ci.product_id, Number(warehouse_id || 1), ci.quantity, ci.cost_price, invoiceNumber, `POS Sale ${invoiceNumber}`, req.user!.username, now);
          checkLowStockNotification(ci.product_id);
        }
      }

      if (!is_held) {
        const grandEtb = Math.round(grandTotal * exchangeRate * 100) / 100;
        const paidEtb = Math.round(paidAmt * exchangeRate * 100) / 100;
        const balEtb = Math.max(0, Math.round((grandEtb - paidEtb) * 100) / 100);
        const vatEtb = Math.round(totalVat * exchangeRate * 100) / 100;
        const revEtb = Math.max(0, Math.round((grandEtb - vatEtb) * 100) / 100);

        // Update customer ledger
        db.prepare(
          'UPDATE customers SET total_purchases = total_purchases + ?, total_paid = total_paid + ?, outstanding_balance = outstanding_balance + ? WHERE id = ?'
        ).run(grandEtb, paidEtb, balEtb, custId);

        // Post Accounting Journal Entry (Revenue + VAT + Cash/AR, and COGS + Inventory)
        const lines: Array<{ accountCode: string; debit: number; credit: number }> = [];
        if (payment_method === 'Split' && split_details) {
          const c = Math.round(Number(split_details.cash || 0) * exchangeRate * 100) / 100;
          const b = Math.round(Number(split_details.bank || 0) * exchangeRate * 100) / 100;
          const m = Math.round(Number(split_details.mobile || 0) * exchangeRate * 100) / 100;
          const cr = Math.max(0, Math.round((grandEtb - (c + b + m)) * 100) / 100);
          if (c > 0) lines.push({ accountCode: '1000', debit: c, credit: 0 });
          if (b > 0) lines.push({ accountCode: '1010', debit: b, credit: 0 });
          if (m > 0) lines.push({ accountCode: '1020', debit: m, credit: 0 });
          if (cr > 0) lines.push({ accountCode: '1100', debit: cr, credit: 0 });
        } else {
          if (paidEtb > 0) {
            lines.push({ accountCode: paymentAccountCode(payment_method || 'Cash'), debit: paidEtb, credit: 0 });
          }
          if (balEtb > 0) {
            lines.push({ accountCode: '1100', debit: balEtb, credit: 0 });
          }
        }
        // Handle exact rounding delta on debit vs credit
        const debitSum = lines.reduce((s, l) => s + l.debit, 0);
        const creditTarget = revEtb + vatEtb;
        const adjustedRev = Math.max(0, Math.round((debitSum - vatEtb) * 100) / 100);
        lines.push({ accountCode: '4000', debit: 0, credit: Math.abs(debitSum - creditTarget) < 0.1 ? adjustedRev : revEtb });
        if (vatEtb > 0) lines.push({ accountCode: '2100', debit: 0, credit: vatEtb });

        if (totalCogsEtb > 0) {
          const cogsRounded = Math.round(totalCogsEtb * 100) / 100;
          lines.push({ accountCode: '5000', debit: cogsRounded, credit: 0 });
          lines.push({ accountCode: '1200', debit: 0, credit: cogsRounded });
        }

        postJournalEntry({
          entryDate: sDate,
          referenceType: 'sale',
          referenceId: invoiceNumber,
          description: `Sales Invoice ${invoiceNumber}`,
          createdBy: req.user!.username,
          lines,
        });

        createNotification({
          type: 'NEW_SALE',
          titleEn: `New Sale: ${invoiceNumber}`,
          titleSo: `Iib Cusub: ${invoiceNumber}`,
          messageEn: `Sale ${invoiceNumber} completed for ${grandTotal.toFixed(2)} ${currCode} (${status}).`,
          messageSo: `Iibka ${invoiceNumber} waa la dhammeystiray: ${grandTotal.toFixed(2)} ${currCode} (${status}).`,
          referenceType: 'sale',
          referenceId: String(saleId),
        });

        if (balEtb > 0) {
          createNotification({
            type: 'OUTSTANDING_DEBT',
            titleEn: `Credit Sale Balance: ${invoiceNumber}`,
            titleSo: `Deyn Iib Cusub: ${invoiceNumber}`,
            messageEn: `Remaining balance of ${balanceAmt.toFixed(2)} ${currCode} recorded on invoice ${invoiceNumber}.`,
            messageSo: `Haraaga deynta ${balanceAmt.toFixed(2)} ${currCode} waxaa lagu qoray biilka ${invoiceNumber}.`,
            referenceType: 'sale',
            referenceId: String(saleId),
          });
        }
      }

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: is_held ? 'HOLD_SALE' : 'CREATE',
        module: 'Sales',
        recordId: invoiceNumber,
        details: `Created ${status} sale ${invoiceNumber} (${grandTotal} ${currCode})`,
      });

      return { id: saleId, invoice_number: invoiceNumber, status };
    });

    try {
      const result = tx();
      res.status(201).json(result);
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to save sale' });
    }
  });

  router.post('/sales/:id/resume', requireAuth, requirePermission('sales.create'), (req: AuthRequest, res: Response) => {
    const saleId = Number(req.params.id);
    const { payment_method, paid_amount, split_details } = req.body || {};

    const tx = db.transaction(() => {
      const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(saleId) as
        | {
            id: number;
            invoice_number: string;
            sale_date: string;
            customer_id: number;
            warehouse_id: number;
            currency: string;
            exchange_rate: number;
            vat_amount: number;
            grand_total: number;
            status: string;
          }
        | undefined;
      if (!sale) throw new Error('Held sale not found');
      if (sale.status !== 'Held') throw new Error('Only held sales can be resumed');

      const settings = db.prepare('SELECT allow_negative_stock FROM settings WHERE id = 1').get() as { allow_negative_stock: number };
      const items = db.prepare('SELECT * FROM sale_items WHERE sale_id = ?').all(sale.id) as Array<{
        product_id: number;
        product_name: string;
        quantity: number;
        cost_price: number;
      }>;
      const now = addisDateTime();
      let totalCogsEtb = 0;

      for (const item of items) {
        const prod = db.prepare('SELECT current_stock FROM products WHERE id = ?').get(item.product_id) as { current_stock: number };
        if (prod.current_stock < item.quantity && !settings.allow_negative_stock) {
          throw new Error(`Insufficient stock for ${item.product_name}`);
        }
        db.prepare('UPDATE products SET current_stock = current_stock - ?, updated_at = ? WHERE id = ?').run(item.quantity, now, item.product_id);
        db.prepare(
          `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
           VALUES (?, ?, 'SALE_OUT', ?, ?, 'sale', ?, ?, ?, ?)`
        ).run(item.product_id, sale.warehouse_id, item.quantity, item.cost_price, sale.invoice_number, `Resumed POS Sale ${sale.invoice_number}`, req.user!.username, now);
        totalCogsEtb += item.quantity * item.cost_price;
        checkLowStockNotification(item.product_id);
      }

      const method = payment_method || 'Cash';
      let paidAmt = Number(paid_amount ?? sale.grand_total);
      if (method === 'Credit' || method === 'Credit/Debt') paidAmt = Number(paid_amount || 0);
      paidAmt = Math.min(sale.grand_total, Math.max(0, Math.round(paidAmt * 100) / 100));
      const balAmt = Math.max(0, Math.round((sale.grand_total - paidAmt) * 100) / 100);
      const newStatus = balAmt <= 0.01 ? 'Paid' : paidAmt <= 0.01 ? 'Credit' : 'Partially Paid';

      db.prepare('UPDATE sales SET paid_amount = ?, balance_amount = ?, payment_method = ?, split_details_json = ?, status = ? WHERE id = ?').run(
        paidAmt,
        balAmt,
        method,
        JSON.stringify(split_details || {}),
        newStatus,
        sale.id
      );

      const grandEtb = Math.round(sale.grand_total * sale.exchange_rate * 100) / 100;
      const paidEtb = Math.round(paidAmt * sale.exchange_rate * 100) / 100;
      const balEtb = Math.max(0, Math.round((grandEtb - paidEtb) * 100) / 100);
      const vatEtb = Math.round(sale.vat_amount * sale.exchange_rate * 100) / 100;
      const revEtb = Math.max(0, Math.round((grandEtb - vatEtb) * 100) / 100);

      db.prepare(
        'UPDATE customers SET total_purchases = total_purchases + ?, total_paid = total_paid + ?, outstanding_balance = outstanding_balance + ? WHERE id = ?'
      ).run(grandEtb, paidEtb, balEtb, sale.customer_id || 1);

      const lines: Array<{ accountCode: string; debit: number; credit: number }> = [];
      if (paidEtb > 0) lines.push({ accountCode: paymentAccountCode(method), debit: paidEtb, credit: 0 });
      if (balEtb > 0) lines.push({ accountCode: '1100', debit: balEtb, credit: 0 });
      lines.push({ accountCode: '4000', debit: 0, credit: revEtb });
      if (vatEtb > 0) lines.push({ accountCode: '2100', debit: 0, credit: vatEtb });
      if (totalCogsEtb > 0) {
        const cogsRounded = Math.round(totalCogsEtb * 100) / 100;
        lines.push({ accountCode: '5000', debit: cogsRounded, credit: 0 });
        lines.push({ accountCode: '1200', debit: 0, credit: cogsRounded });
      }
      postJournalEntry({
        entryDate: sale.sale_date,
        referenceType: 'sale',
        referenceId: sale.invoice_number,
        description: `Completed Held Sale ${sale.invoice_number}`,
        createdBy: req.user!.username,
        lines,
      });

      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'RESUME_SALE', module: 'Sales', recordId: sale.invoice_number, details: `Completed held sale ${sale.invoice_number}` });
    });

    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to resume sale' });
    }
  });

  router.post('/sales/:id/cancel', requireAuth, requirePermission('sales.create'), (req: AuthRequest, res: Response) => {
    const saleId = Number(req.params.id);
    const sale = db.prepare('SELECT id, invoice_number, status FROM sales WHERE id = ?').get(saleId) as
      | { id: number; invoice_number: string; status: string }
      | undefined;
    if (!sale) {
      res.status(404).json({ error: 'Sale not found' });
      return;
    }
    if (sale.status !== 'Held') {
      res.status(400).json({ error: 'Completed sales must be reversed via Sales Return' });
      return;
    }
    db.prepare("UPDATE sales SET status = 'Cancelled' WHERE id = ?").run(saleId);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CANCEL', module: 'Sales', recordId: sale.invoice_number, details: 'Cancelled held sale' });
    res.json({ ok: true });
  });

  router.post('/sales/returns', requireAuth, requirePermission('sales.return'), (req: AuthRequest, res: Response) => {
    const { sale_id, items, refund_method, notes, reason, status } = req.body || {};
    if (!sale_id || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Sale ID and at least one returned item are required' });
      return;
    }

    const tx = db.transaction(() => {
      const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(Number(sale_id)) as
        | {
            id: number;
            invoice_number: string;
            customer_id: number;
            warehouse_id: number;
            exchange_rate: number;
            balance_amount: number;
            status: string;
          }
        | undefined;
      if (!sale) throw new Error('Sale not found');
      if (sale.status === 'Held' || sale.status === 'Cancelled') throw new Error('Cannot return a held or cancelled sale');

      const settings = db.prepare('SELECT return_prefix FROM settings WHERE id = 1').get() as { return_prefix: string };
      const seq = getNextSequence('invoice_seq_return');
      const returnNumber = formatCode(settings.return_prefix || 'RET-', seq);
      const now = addisDateTime();
      const rDate = addisDate();

      let totalRefund = 0;
      let totalVat = 0;
      let totalCogs = 0;
      const returnLines: Array<{
        sale_item_id: number;
        product_id: number;
        product_name: string;
        quantity: number;
        unit_price: number;
        vat_amount: number;
        subtotal: number;
      }> = [];

      for (const reqItem of items) {
        const retQty = Number(reqItem.quantity || 0);
        if (retQty <= 0) continue;

        const si = db.prepare('SELECT * FROM sale_items WHERE id = ? AND sale_id = ?').get(Number(reqItem.sale_item_id), sale.id) as
          | {
              id: number;
              product_id: number;
              product_name: string;
              quantity: number;
              returned_qty: number;
              unit_price: number;
              cost_price: number;
              vat_rate: number;
            }
          | undefined;
        if (!si) throw new Error('Sale item not found');
        const remaining = si.quantity - si.returned_qty;
        if (retQty > remaining) {
          throw new Error(`Return quantity (${retQty}) exceeds remaining quantity (${remaining}) for ${si.product_name}`);
        }

        const net = retQty * si.unit_price;
        const vat = Math.round(net * (si.vat_rate / 100) * 100) / 100;
        const sub = Math.round((net + vat) * 100) / 100;

        totalRefund += sub;
        totalVat += vat;
        totalCogs += retQty * si.cost_price;

        returnLines.push({
          sale_item_id: si.id,
          product_id: si.product_id,
          product_name: si.product_name,
          quantity: retQty,
          unit_price: si.unit_price,
          vat_amount: vat,
          subtotal: sub,
        });

        db.prepare('UPDATE sale_items SET returned_qty = returned_qty + ? WHERE id = ?').run(retQty, si.id);
        db.prepare('UPDATE products SET current_stock = current_stock + ?, updated_at = ? WHERE id = ?').run(retQty, now, si.product_id);
        db.prepare(
          `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
           VALUES (?, ?, 'SALE_RETURN_IN', ?, ?, 'sale_return', ?, ?, ?, ?)`
        ).run(si.product_id, sale.warehouse_id, retQty, si.cost_price, returnNumber, `Return from ${sale.invoice_number}`, req.user!.username, now);
      }

      if (returnLines.length === 0) throw new Error('No valid return quantities specified');

      totalRefund = Math.round(totalRefund * 100) / 100;
      const retReason = String(reason || notes || '').trim();
      const retStatus = String(status || 'Refunded').trim();
      const resRet = db
        .prepare(
          `INSERT INTO sale_returns (return_number, sale_id, invoice_number, customer_id, return_date, total_refund, refund_method, reason, status, notes, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(returnNumber, sale.id, sale.invoice_number, sale.customer_id, rDate, totalRefund, refund_method || 'Cash', retReason, retStatus, notes || retReason, req.user!.username, now);
      const returnId = Number(resRet.lastInsertRowid);

      const insRetItem = db.prepare(
        `INSERT INTO sale_return_items (return_id, sale_item_id, product_id, product_name, quantity, unit_price, vat_amount, subtotal)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      );
      for (const rl of returnLines) {
        insRetItem.run(returnId, rl.sale_item_id, rl.product_id, rl.product_name, rl.quantity, rl.unit_price, rl.vat_amount, rl.subtotal);
      }

      // Check if full or partial return
      const allItems = db.prepare('SELECT quantity, returned_qty FROM sale_items WHERE sale_id = ?').all(sale.id) as Array<{
        quantity: number;
        returned_qty: number;
      }>;
      const fullyReturned = allItems.every((x) => x.returned_qty >= x.quantity);
      const newStatus = fullyReturned ? 'Returned' : 'Partially Returned';
      const newBalance = Math.max(0, sale.balance_amount - totalRefund);
      db.prepare('UPDATE sales SET status = ?, balance_amount = ? WHERE id = ?').run(newStatus, newBalance, sale.id);

      // Update customer balance if any debt reduced
      const refundEtb = Math.round(totalRefund * sale.exchange_rate * 100) / 100;
      const vatEtb = Math.round(totalVat * sale.exchange_rate * 100) / 100;
      const netEtb = Math.max(0, Math.round((refundEtb - vatEtb) * 100) / 100);
      const debtOffset = Math.min(sale.balance_amount * sale.exchange_rate, refundEtb);
      if (sale.customer_id && debtOffset > 0) {
        db.prepare('UPDATE customers SET outstanding_balance = MAX(0, outstanding_balance - ?) WHERE id = ?').run(debtOffset, sale.customer_id);
      }

      const jLines: Array<{ accountCode: string; debit: number; credit: number }> = [
        { accountCode: '4100', debit: netEtb, credit: 0 },
      ];
      if (vatEtb > 0) jLines.push({ accountCode: '2100', debit: vatEtb, credit: 0 });
      if (debtOffset > 0) jLines.push({ accountCode: '1100', debit: 0, credit: Math.round(debtOffset * 100) / 100 });
      const cashRefundEtb = Math.max(0, Math.round((refundEtb - debtOffset) * 100) / 100);
      if (cashRefundEtb > 0) jLines.push({ accountCode: paymentAccountCode(refund_method || 'Cash'), debit: 0, credit: cashRefundEtb });
      if (totalCogs > 0) {
        const cogsRounded = Math.round(totalCogs * 100) / 100;
        jLines.push({ accountCode: '1200', debit: cogsRounded, credit: 0 });
        jLines.push({ accountCode: '5000', debit: 0, credit: cogsRounded });
      }
      postJournalEntry({
        entryDate: rDate,
        referenceType: 'sale_return',
        referenceId: returnNumber,
        description: `Sales Return ${returnNumber} for ${sale.invoice_number}`,
        createdBy: req.user!.username,
        lines: jLines,
      });

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: 'RETURN',
        module: 'Sales',
        recordId: returnNumber,
        details: `Returned ${totalRefund} from ${sale.invoice_number}`,
      });

      return { id: returnId, return_number: returnNumber };
    });

    try {
      const result = tx();
      res.status(201).json(result);
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Return failed' });
    }
  });

  // ==================== PURCHASES & RETURNS ====================
  router.get('/purchases', requireAuth, (req: Request, res: Response) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    const supplierId = req.query.supplier_id ? Number(req.query.supplier_id) : null;
    let sql = `
      SELECT p.*, s.business_name as supplier_name, s.phone as supplier_phone,
             COALESCE((SELECT GROUP_CONCAT(pi.product_name || ' x' || CAST(pi.quantity AS TEXT), ', ') FROM purchase_items pi WHERE pi.purchase_id = p.id), '') as items_summary,
             COALESCE((SELECT SUM(pi.quantity) FROM purchase_items pi WHERE pi.purchase_id = p.id), 0) as total_quantity
      FROM purchases p
      LEFT JOIN suppliers s ON s.id = p.supplier_id
      WHERE 1=1
    `;
    const params: unknown[] = [];
    if (supplierId) {
      sql += ' AND p.supplier_id = ?';
      params.push(supplierId);
    }
    if (q) {
      sql += ' AND (LOWER(p.purchase_number) LIKE ? OR LOWER(COALESCE(p.supplier_invoice_no, \'\')) LIKE ? OR LOWER(COALESCE(s.business_name, \'\')) LIKE ?)';
      params.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }
    sql += ' ORDER BY p.id DESC LIMIT 300';
    const purchases = db.prepare(sql).all(...params);
    res.json({ purchases });
  });

  router.get('/purchases/supplier-summary', requireAuth, (_req: Request, res: Response) => {
    const summaries = db
      .prepare(
        `SELECT s.id, s.supplier_code, s.business_name, s.contact_person, s.phone, s.email, s.opening_balance, s.total_purchases, s.total_paid, s.outstanding_balance,
                COUNT(p.id) as purchase_count,
                COALESCE(SUM(p.grand_total * p.exchange_rate), 0) as total_purchases_etb,
                COALESCE(SUM(p.paid_amount * p.exchange_rate), 0) as total_paid_etb,
                COALESCE(SUM(p.balance_amount * p.exchange_rate), 0) as total_due_etb
         FROM suppliers s
         LEFT JOIN purchases p ON p.supplier_id = s.id
         GROUP BY s.id
         ORDER BY total_purchases_etb DESC, s.id ASC`
      )
      .all();
    res.json({ summaries });
  });

  router.get('/purchases/returns', requireAuth, (_req: Request, res: Response) => {
    const returns = db
      .prepare(
        `SELECT pr.*, s.business_name as supplier_name,
                COALESCE((SELECT GROUP_CONCAT(pri.product_name || ' x' || CAST(pri.quantity AS TEXT), ', ') FROM purchase_return_items pri WHERE pri.return_id = pr.id), '') as items_summary,
                COALESCE((SELECT SUM(pri.quantity) FROM purchase_return_items pri WHERE pri.return_id = pr.id), 0) as total_quantity
         FROM purchase_returns pr
         LEFT JOIN suppliers s ON s.id = pr.supplier_id
         ORDER BY pr.id DESC LIMIT 200`
      )
      .all();
    res.json({ returns });
  });

  router.get('/purchases/:id', requireAuth, (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const purchase = db
      .prepare(
        `SELECT p.*, s.business_name as supplier_name, s.contact_person, s.phone as supplier_phone, s.address as supplier_address
         FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ?`
      )
      .get(id);
    if (!purchase) {
      res.status(404).json({ error: 'Purchase not found' });
      return;
    }
    const items = db.prepare('SELECT * FROM purchase_items WHERE purchase_id = ?').all(id);
    res.json({ purchase, items });
  });

  router.post('/purchases', requireAuth, requirePermission('purchases.create'), (req: AuthRequest, res: Response) => {
    const { supplier_id, warehouse_id, currency, discount_amount, paid_amount, payment_method, purchase_date, supplier_invoice_no, notes, items } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'At least one purchase item is required' });
      return;
    }

    const tx = db.transaction(() => {
      const settings = db.prepare('SELECT purchase_prefix FROM settings WHERE id = 1').get() as { purchase_prefix: string };
      const currCode = currency || 'ETB';
      const currRow = db.prepare('SELECT exchange_rate_to_etb FROM currencies WHERE code = ?').get(currCode) as
        | { exchange_rate_to_etb: number }
        | undefined;
      const exchangeRate = currRow?.exchange_rate_to_etb || 1;
      const now = addisDateTime();
      const pDate = purchase_date || addisDate();

      let subtotal = 0;
      let totalVat = 0;

      const computed: Array<{
        product_id: number;
        product_name: string;
        sku: string;
        unit: string;
        quantity: number;
        purchase_price: number;
        vat_rate: number;
        vat_amount: number;
        subtotal: number;
      }> = [];

      for (const item of items) {
        const qty = Number(item.quantity || 0);
        const price = Number(item.purchase_price || 0);
        if (qty <= 0 || price < 0) throw new Error('Invalid quantity or purchase price');

        const prod = db.prepare('SELECT id, name, sku, unit, vat_rate, current_stock, purchase_price FROM products WHERE id = ?').get(
          Number(item.product_id)
        ) as
          | { id: number; name: string; sku: string; unit: string; vat_rate: number; current_stock: number; purchase_price: number }
          | undefined;
        if (!prod) throw new Error(`Product #${item.product_id} not found`);

        const lineNet = qty * price;
        const vatRate = item.vat_rate !== undefined ? Number(item.vat_rate) : prod.vat_rate;
        const vatAmt = Math.round(lineNet * (vatRate / 100) * 100) / 100;
        const lineTotal = Math.round((lineNet + vatAmt) * 100) / 100;

        subtotal += lineNet;
        totalVat += vatAmt;

        computed.push({
          product_id: prod.id,
          product_name: prod.name,
          sku: prod.sku,
          unit: prod.unit,
          quantity: qty,
          purchase_price: price,
          vat_rate: vatRate,
          vat_amount: vatAmt,
          subtotal: lineTotal,
        });
      }

      const disc = Number(discount_amount || 0);
      const grandTotal = Math.max(0, Math.round((subtotal - disc + totalVat) * 100) / 100);
      let paidAmt = Number(paid_amount ?? grandTotal);
      if (payment_method === 'Credit' || payment_method === 'Credit/Debt') paidAmt = Number(paid_amount || 0);
      paidAmt = Math.min(grandTotal, Math.max(0, Math.round(paidAmt * 100) / 100));
      const balAmt = Math.max(0, Math.round((grandTotal - paidAmt) * 100) / 100);
      const status = balAmt <= 0.01 ? 'Paid' : paidAmt <= 0.01 ? 'Credit' : 'Partially Paid';

      const seq = getNextSequence('invoice_seq_purchase');
      const purchaseNumber = formatCode(settings.purchase_prefix || 'PUR-', seq);
      const supId = supplier_id ? Number(supplier_id) : 1;

      const resPur = db
        .prepare(
          `INSERT INTO purchases (purchase_number, supplier_invoice_no, purchase_date, supplier_id, warehouse_id, currency, exchange_rate, subtotal, discount_amount, vat_amount, grand_total, paid_amount, balance_amount, payment_method, status, notes, created_by_id, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          purchaseNumber,
          String(supplier_invoice_no || '').trim(),
          pDate,
          supId,
          Number(warehouse_id || 1),
          currCode,
          exchangeRate,
          Math.round(subtotal * 100) / 100,
          disc,
          Math.round(totalVat * 100) / 100,
          grandTotal,
          paidAmt,
          balAmt,
          payment_method || 'Cash',
          status,
          notes || '',
          req.user!.id,
          req.user!.username,
          now
        );

      const purchaseId = Number(resPur.lastInsertRowid);
      const insItem = db.prepare(
        `INSERT INTO purchase_items (purchase_id, product_id, product_name, sku, unit, quantity, purchase_price, vat_rate, vat_amount, subtotal)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      );

      for (const ci of computed) {
        insItem.run(purchaseId, ci.product_id, ci.product_name, ci.sku, ci.unit, ci.quantity, ci.purchase_price, ci.vat_rate, ci.vat_amount, ci.subtotal);

        const prod = db.prepare('SELECT current_stock, purchase_price FROM products WHERE id = ?').get(ci.product_id) as {
          current_stock: number;
          purchase_price: number;
        };
        const unitCostEtb = ci.purchase_price * exchangeRate;
        const existingQty = Math.max(0, prod.current_stock);
        const avgCost =
          existingQty + ci.quantity > 0
            ? (existingQty * prod.purchase_price + ci.quantity * unitCostEtb) / (existingQty + ci.quantity)
            : unitCostEtb;

        db.prepare('UPDATE products SET current_stock = current_stock + ?, purchase_price = ?, updated_at = ? WHERE id = ?').run(
          ci.quantity,
          Math.round(avgCost * 100) / 100,
          now,
          ci.product_id
        );
        db.prepare(
          `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
           VALUES (?, ?, 'PURCHASE_IN', ?, ?, 'purchase', ?, ?, ?, ?)`
        ).run(ci.product_id, Number(warehouse_id || 1), ci.quantity, unitCostEtb, purchaseNumber, `Purchase ${purchaseNumber}`, req.user!.username, now);
      }

      const grandEtb = Math.round(grandTotal * exchangeRate * 100) / 100;
      const paidEtb = Math.round(paidAmt * exchangeRate * 100) / 100;
      const balEtb = Math.max(0, Math.round((grandEtb - paidEtb) * 100) / 100);
      const vatEtb = Math.round(totalVat * exchangeRate * 100) / 100;
      const invEtb = Math.max(0, Math.round((grandEtb - vatEtb) * 100) / 100);

      db.prepare(
        'UPDATE suppliers SET total_purchases = total_purchases + ?, total_paid = total_paid + ?, outstanding_balance = outstanding_balance + ? WHERE id = ?'
      ).run(grandEtb, paidEtb, balEtb, supId);

      const jLines: Array<{ accountCode: string; debit: number; credit: number }> = [
        { accountCode: '1200', debit: invEtb, credit: 0 },
      ];
      if (vatEtb > 0) jLines.push({ accountCode: '1300', debit: vatEtb, credit: 0 });
      if (paidEtb > 0) jLines.push({ accountCode: paymentAccountCode(payment_method || 'Cash'), debit: 0, credit: paidEtb });
      if (balEtb > 0) jLines.push({ accountCode: '2000', debit: 0, credit: balEtb });

      postJournalEntry({
        entryDate: pDate,
        referenceType: 'purchase',
        referenceId: purchaseNumber,
        description: `Purchase Order ${purchaseNumber}`,
        createdBy: req.user!.username,
        lines: jLines,
      });

      createNotification({
        type: 'NEW_PURCHASE',
        titleEn: `New Purchase: ${purchaseNumber}`,
        titleSo: `Iibsi Cusub (Alaab): ${purchaseNumber}`,
        messageEn: `Purchase ${purchaseNumber} recorded for ${grandTotal.toFixed(2)} ${currCode}.`,
        messageSo: `Iibsiga alaabta ${purchaseNumber} waa la diiwaangeliyay: ${grandTotal.toFixed(2)} ${currCode}.`,
        referenceType: 'purchase',
        referenceId: String(purchaseId),
      });

      logAudit({
        userId: req.user!.id,
        username: req.user!.username,
        action: 'CREATE',
        module: 'Purchase',
        recordId: purchaseNumber,
        details: `Created purchase ${purchaseNumber} (${grandTotal} ${currCode})`,
      });

      return { id: purchaseId, purchase_number: purchaseNumber };
    });

    try {
      const result = tx();
      res.status(201).json(result);
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to save purchase' });
    }
  });

  router.put('/purchases/:id', requireAuth, requirePermission('purchases.create'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const { notes, purchase_date } = req.body || {};
    const existing = db.prepare('SELECT purchase_number, purchase_date, notes FROM purchases WHERE id = ?').get(id) as
      | { purchase_number: string; purchase_date: string; notes: string }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Purchase not found' });
      return;
    }
    db.prepare('UPDATE purchases SET purchase_date = ?, notes = ? WHERE id = ?').run(
      purchase_date || existing.purchase_date,
      notes !== undefined ? notes : existing.notes,
      id
    );
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Purchase', recordId: existing.purchase_number, details: 'Updated purchase notes/date' });
    res.json({ ok: true });
  });

  router.post('/purchases/returns', requireAuth, requirePermission('purchases.return'), (req: AuthRequest, res: Response) => {
    const { purchase_id, items, notes, reason, status } = req.body || {};
    if (!purchase_id || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Purchase ID and return items are required' });
      return;
    }

    const tx = db.transaction(() => {
      const purchase = db.prepare('SELECT * FROM purchases WHERE id = ?').get(Number(purchase_id)) as
        | { id: number; purchase_number: string; supplier_id: number; warehouse_id: number; exchange_rate: number; balance_amount: number }
        | undefined;
      if (!purchase) throw new Error('Purchase not found');

      const settings = db.prepare('SELECT return_prefix FROM settings WHERE id = 1').get() as { return_prefix: string };
      const seq = getNextSequence('invoice_seq_return');
      const returnNumber = formatCode(settings.return_prefix || 'RET-', seq);
      const now = addisDateTime();
      const rDate = addisDate();

      let totalRefund = 0;
      let totalVat = 0;
      const lines: Array<{ purchase_item_id: number; product_id: number; product_name: string; quantity: number; purchase_price: number; vat_amount: number; subtotal: number }> = [];

      for (const reqItem of items) {
        const retQty = Number(reqItem.quantity || 0);
        if (retQty <= 0) continue;
        const pi = db.prepare('SELECT * FROM purchase_items WHERE id = ? AND purchase_id = ?').get(Number(reqItem.purchase_item_id), purchase.id) as
          | { id: number; product_id: number; product_name: string; quantity: number; returned_qty: number; purchase_price: number; vat_rate: number }
          | undefined;
        if (!pi) throw new Error('Purchase item not found');
        if (retQty > pi.quantity - pi.returned_qty) {
          throw new Error(`Return quantity exceeds purchased quantity for ${pi.product_name}`);
        }

        const prod = db.prepare('SELECT current_stock FROM products WHERE id = ?').get(pi.product_id) as { current_stock: number };
        if (prod.current_stock < retQty) {
          throw new Error(`Insufficient stock on hand (${prod.current_stock}) to return ${retQty} of ${pi.product_name}`);
        }

        const net = retQty * pi.purchase_price;
        const vat = Math.round(net * (pi.vat_rate / 100) * 100) / 100;
        const sub = Math.round((net + vat) * 100) / 100;
        totalRefund += sub;
        totalVat += vat;

        lines.push({
          purchase_item_id: pi.id,
          product_id: pi.product_id,
          product_name: pi.product_name,
          quantity: retQty,
          purchase_price: pi.purchase_price,
          vat_amount: vat,
          subtotal: sub,
        });

        db.prepare('UPDATE purchase_items SET returned_qty = returned_qty + ? WHERE id = ?').run(retQty, pi.id);
        db.prepare('UPDATE products SET current_stock = current_stock - ?, updated_at = ? WHERE id = ?').run(retQty, now, pi.product_id);
        db.prepare(
          `INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, unit_cost, reference_type, reference_id, notes, created_by, created_at)
           VALUES (?, ?, 'PURCHASE_RETURN_OUT', ?, ?, 'purchase_return', ?, ?, ?, ?)`
        ).run(pi.product_id, purchase.warehouse_id, retQty, pi.purchase_price * purchase.exchange_rate, returnNumber, `Return on ${purchase.purchase_number}`, req.user!.username, now);
      }

      if (lines.length === 0) throw new Error('No valid return items provided');

      totalRefund = Math.round(totalRefund * 100) / 100;
      const retReason = String(reason || notes || '').trim();
      const retStatus = String(status || 'Credited').trim();
      const resRet = db
        .prepare(
          `INSERT INTO purchase_returns (return_number, purchase_id, purchase_number, supplier_id, return_date, total_refund, reason, status, notes, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(returnNumber, purchase.id, purchase.purchase_number, purchase.supplier_id, rDate, totalRefund, retReason, retStatus, notes || retReason, req.user!.username, now);

      const retId = Number(resRet.lastInsertRowid);
      const ins = db.prepare(
        'INSERT INTO purchase_return_items (return_id, purchase_item_id, product_id, product_name, quantity, purchase_price, vat_amount, subtotal) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      );
      for (const l of lines) ins.run(retId, l.purchase_item_id, l.product_id, l.product_name, l.quantity, l.purchase_price, l.vat_amount, l.subtotal);

      const allItems = db.prepare('SELECT quantity, returned_qty FROM purchase_items WHERE purchase_id = ?').all(purchase.id) as Array<{ quantity: number; returned_qty: number }>;
      const fullyReturned = allItems.every((x) => x.returned_qty >= x.quantity);
      const newBal = Math.max(0, purchase.balance_amount - totalRefund);
      db.prepare('UPDATE purchases SET status = ?, balance_amount = ? WHERE id = ?').run(fullyReturned ? 'Returned' : 'Partially Returned', newBal, purchase.id);

      const refundEtb = Math.round(totalRefund * purchase.exchange_rate * 100) / 100;
      const vatEtb = Math.round(totalVat * purchase.exchange_rate * 100) / 100;
      const invEtb = Math.max(0, Math.round((refundEtb - vatEtb) * 100) / 100);
      const debtOffset = Math.min(purchase.balance_amount * purchase.exchange_rate, refundEtb);

      if (purchase.supplier_id && debtOffset > 0) {
        db.prepare('UPDATE suppliers SET outstanding_balance = MAX(0, outstanding_balance - ?) WHERE id = ?').run(debtOffset, purchase.supplier_id);
      }

      const jLines: Array<{ accountCode: string; debit: number; credit: number }> = [];
      if (debtOffset > 0) jLines.push({ accountCode: '2000', debit: Math.round(debtOffset * 100) / 100, credit: 0 });
      const cashBack = Math.max(0, Math.round((refundEtb - debtOffset) * 100) / 100);
      if (cashBack > 0) jLines.push({ accountCode: '1000', debit: cashBack, credit: 0 });
      jLines.push({ accountCode: '1200', debit: 0, credit: invEtb });
      if (vatEtb > 0) jLines.push({ accountCode: '1300', debit: 0, credit: vatEtb });

      postJournalEntry({
        entryDate: rDate,
        referenceType: 'purchase_return',
        referenceId: returnNumber,
        description: `Purchase Return ${returnNumber} for ${purchase.purchase_number}`,
        createdBy: req.user!.username,
        lines: jLines,
      });

      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'RETURN', module: 'Purchase', recordId: returnNumber, details: `Returned ${totalRefund} to supplier` });
      return { id: retId, return_number: returnNumber };
    });

    try {
      const result = tx();
      res.status(201).json(result);
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Purchase return failed' });
    }
  });

  // ==================== EXPENSES & CATEGORIES ====================
  router.get('/expense-categories', requireAuth, (_req: Request, res: Response) => {
    const categories = db.prepare('SELECT * FROM expense_categories ORDER BY name ASC').all();
    res.json({ categories });
  });

  router.post('/expense-categories', requireAuth, requirePermission('expenses.manage'), (req: AuthRequest, res: Response) => {
    const { name, description } = req.body || {};
    if (!name || !String(name).trim()) {
      res.status(400).json({ error: 'Category name is required' });
      return;
    }
    try {
      const info = db
        .prepare('INSERT INTO expense_categories (name, description, created_at) VALUES (?, ?, ?)')
        .run(String(name).trim(), String(description || '').trim(), addisDateTime());
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'ExpenseCategory', recordId: String(info.lastInsertRowid), details: name });
      res.status(201).json({ id: info.lastInsertRowid });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Expense category already exists' });
    }
  });

  router.put('/expense-categories/:id', requireAuth, requirePermission('expenses.manage'), (req: AuthRequest, res: Response) => {
    const { name, description } = req.body || {};
    if (!name || !String(name).trim()) {
      res.status(400).json({ error: 'Category name is required' });
      return;
    }
    try {
      db.prepare('UPDATE expense_categories SET name = ?, description = ? WHERE id = ?').run(
        String(name).trim(),
        String(description || '').trim(),
        req.params.id
      );
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'ExpenseCategory', recordId: String(req.params.id), details: name });
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to update expense category' });
    }
  });

  router.delete('/expense-categories/:id', requireAuth, requirePermission('expenses.manage'), (req: AuthRequest, res: Response) => {
    db.prepare('DELETE FROM expense_categories WHERE id = ?').run(req.params.id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'ExpenseCategory', recordId: String(req.params.id), details: 'Deleted expense category' });
    res.json({ ok: true });
  });

  router.get('/expenses', requireAuth, requirePermission('expenses.view'), (_req: Request, res: Response) => {
    const expenses = db.prepare('SELECT * FROM expenses ORDER BY id DESC LIMIT 300').all();
    res.json({ expenses });
  });

  router.post('/expenses', requireAuth, requirePermission('expenses.manage'), (req: AuthRequest, res: Response) => {
    const { expense_date, title, category, description, amount, currency, payment_method, receipt_ref, attachment_url } = req.body || {};
    const amt = Number(amount || 0);
    if (!category || (!description && !title) || amt <= 0) {
      res.status(400).json({ error: 'Category, title/description, and positive amount are required' });
      return;
    }

    const tx = db.transaction(() => {
      const currCode = currency || 'ETB';
      const curr = db.prepare('SELECT exchange_rate_to_etb FROM currencies WHERE code = ?').get(currCode) as
        | { exchange_rate_to_etb: number }
        | undefined;
      const rate = curr?.exchange_rate_to_etb || 1;
      const amtEtb = Math.round(amt * rate * 100) / 100;
      const seq = getNextSequence('invoice_seq_expense');
      const code = formatCode('EXP-', seq);
      const eDate = expense_date || addisDate();
      const now = addisDateTime();
      const expTitle = String(title || description || category).trim();
      const expDesc = String(description || expTitle).trim();

      const info = db
        .prepare(
          `INSERT INTO expenses (expense_code, title, expense_date, category, description, amount, currency, exchange_rate, amount_etb, payment_method, receipt_ref, attachment_url, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(code, expTitle, eDate, category, expDesc, amt, currCode, rate, amtEtb, payment_method || 'Cash', receipt_ref || '', attachment_url || '', req.user!.username, now);

      postJournalEntry({
        entryDate: eDate,
        referenceType: 'expense',
        referenceId: code,
        description: `Expense ${code} (${expTitle}): ${expDesc}`,
        createdBy: req.user!.username,
        lines: [
          { accountCode: '6000', debit: amtEtb, credit: 0 },
          { accountCode: paymentAccountCode(payment_method || 'Cash'), debit: 0, credit: amtEtb },
        ],
      });

      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Expense', recordId: code, details: `${expTitle} (${category}): ${amt} ${currCode}` });
      return { id: info.lastInsertRowid, expense_code: code };
    });

    try {
      res.status(201).json(tx());
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to save expense' });
    }
  });

  router.put('/expenses/:id', requireAuth, requirePermission('expenses.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const existing = db.prepare('SELECT * FROM expenses WHERE id = ?').get(id) as
      | {
          id: number;
          expense_code: string;
          title: string;
          expense_date: string;
          category: string;
          description: string;
          amount: number;
          currency: string;
          exchange_rate: number;
          amount_etb: number;
          payment_method: string;
          receipt_ref: string;
          attachment_url: string;
        }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Expense not found' });
      return;
    }

    const { expense_date, title, category, description, amount, currency, payment_method, receipt_ref, attachment_url } = req.body || {};
    const nextAmt = amount !== undefined ? Number(amount) : existing.amount;
    if (nextAmt <= 0) {
      res.status(400).json({ error: 'Amount must be positive' });
      return;
    }

    const tx = db.transaction(() => {
      const nextCurr = currency || existing.currency || 'ETB';
      const currRow = db.prepare('SELECT exchange_rate_to_etb FROM currencies WHERE code = ?').get(nextCurr) as
        | { exchange_rate_to_etb: number }
        | undefined;
      const nextRate = nextCurr === existing.currency ? existing.exchange_rate : currRow?.exchange_rate_to_etb || 1;
      const nextAmtEtb = Math.round(nextAmt * nextRate * 100) / 100;
      const nextMethod = payment_method || existing.payment_method;
      const nextDate = expense_date || existing.expense_date;

      if (Math.abs(nextAmtEtb - existing.amount_etb) > 0.01 || nextMethod !== existing.payment_method) {
        postJournalEntry({
          entryDate: nextDate,
          referenceType: 'expense_adjustment',
          referenceId: existing.expense_code,
          description: `Adjustment for edited expense ${existing.expense_code}`,
          createdBy: req.user!.username,
          lines: [
            { accountCode: paymentAccountCode(existing.payment_method), debit: existing.amount_etb, credit: 0 },
            { accountCode: '6000', debit: 0, credit: existing.amount_etb },
          ],
        });
        postJournalEntry({
          entryDate: nextDate,
          referenceType: 'expense',
          referenceId: existing.expense_code,
          description: `Updated expense ${existing.expense_code}: ${title || existing.title}`,
          createdBy: req.user!.username,
          lines: [
            { accountCode: '6000', debit: nextAmtEtb, credit: 0 },
            { accountCode: paymentAccountCode(nextMethod), debit: 0, credit: nextAmtEtb },
          ],
        });
      }

      db.prepare(
        `UPDATE expenses
         SET title = ?, expense_date = ?, category = ?, description = ?, amount = ?, currency = ?, exchange_rate = ?, amount_etb = ?, payment_method = ?, receipt_ref = ?, attachment_url = ?
         WHERE id = ?`
      ).run(
        title !== undefined ? String(title).trim() : existing.title,
        nextDate,
        category || existing.category,
        description !== undefined ? String(description).trim() : existing.description,
        nextAmt,
        nextCurr,
        nextRate,
        nextAmtEtb,
        nextMethod,
        receipt_ref !== undefined ? receipt_ref : existing.receipt_ref,
        attachment_url !== undefined ? attachment_url : existing.attachment_url,
        id
      );

      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Expense', recordId: existing.expense_code, details: `Updated expense ${existing.expense_code}` });
    });

    try {
      tx();
      res.json({ ok: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to update expense' });
    }
  });

  router.delete('/expenses/:id', requireAuth, requirePermission('expenses.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const exp = db.prepare('SELECT * FROM expenses WHERE id = ?').get(id) as
      | { id: number; expense_code: string; amount_etb: number; payment_method: string }
      | undefined;
    if (!exp) {
      res.status(404).json({ error: 'Expense not found' });
      return;
    }
    const tx = db.transaction(() => {
      db.prepare('DELETE FROM expenses WHERE id = ?').run(id);
      postJournalEntry({
        referenceType: 'expense_reversal',
        referenceId: exp.expense_code,
        description: `Reversal of deleted expense ${exp.expense_code}`,
        createdBy: req.user!.username,
        lines: [
          { accountCode: paymentAccountCode(exp.payment_method), debit: exp.amount_etb, credit: 0 },
          { accountCode: '6000', debit: 0, credit: exp.amount_etb },
        ],
      });
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Expense', recordId: exp.expense_code, details: 'Deleted and reversed expense' });
    });
    tx();
    res.json({ ok: true });
  });

  // ==================== ACCOUNTING ====================
  router.get('/accounting/accounts', requireAuth, requirePermission('accounting.view'), (_req: Request, res: Response) => {
    const accounts = db.prepare('SELECT * FROM accounts ORDER BY code ASC').all();
    res.json({ accounts });
  });

  router.post('/accounting/accounts', requireAuth, requirePermission('accounting.manage'), (req: AuthRequest, res: Response) => {
    const { code, name, type } = req.body || {};
    if (!code || !name || !type) {
      res.status(400).json({ error: 'Account code, name, and type are required' });
      return;
    }
    try {
      const info = db.prepare('INSERT INTO accounts (code, name, type, balance, is_system) VALUES (?, ?, ?, 0, 0)').run(
        String(code).trim(),
        String(name).trim(),
        String(type)
      );
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Accounting', recordId: String(code), details: `Added account ${code} ${name}` });
      res.status(201).json({ id: info.lastInsertRowid });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Account code already exists' });
    }
  });

  router.get('/accounting/journal', requireAuth, requirePermission('accounting.view'), (_req: Request, res: Response) => {
    const entries = db.prepare('SELECT * FROM journal_entries ORDER BY id DESC LIMIT 200').all() as Array<Record<string, unknown>>;
    const getLines = db.prepare(
      `SELECT jl.*, a.code as account_code, a.name as account_name, a.type as account_type
       FROM journal_lines jl JOIN accounts a ON a.id = jl.account_id WHERE jl.journal_entry_id = ?`
    );
    const enriched = entries.map((e) => ({ ...e, lines: getLines.all(e.id) }));
    res.json({ entries: enriched });
  });

  router.post('/accounting/journal', requireAuth, requirePermission('accounting.manage'), (req: AuthRequest, res: Response) => {
    const { entry_date, description, lines } = req.body || {};
    if (!description || !Array.isArray(lines) || lines.length < 2) {
      res.status(400).json({ error: 'Description and at least 2 balanced journal lines are required' });
      return;
    }
    try {
      const tx = db.transaction(() => {
        const entryId = postJournalEntry({
          entryDate: entry_date || addisDate(),
          referenceType: 'manual',
          referenceId: 'MANUAL',
          description,
          createdBy: req.user!.username,
          lines,
        });
        logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Journal', recordId: String(entryId), details: description });
        return entryId;
      });
      const id = tx();
      res.status(201).json({ id });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Journal entry failed' });
    }
  });

  router.get('/accounting/ledger/:accountId', requireAuth, requirePermission('accounting.view'), (req: Request, res: Response) => {
    const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(Number(req.params.accountId));
    const lines = db
      .prepare(
        `SELECT jl.*, je.entry_number, je.entry_date, je.description, je.reference_type, je.reference_id
         FROM journal_lines jl
         JOIN journal_entries je ON je.id = jl.journal_entry_id
         WHERE jl.account_id = ?
         ORDER BY je.id ASC`
      )
      .all(Number(req.params.accountId));
    res.json({ account, lines });
  });

  router.get('/accounting/statements', requireAuth, requirePermission('accounting.view'), (_req: Request, res: Response) => {
    const accounts = db.prepare('SELECT * FROM accounts ORDER BY code ASC').all() as Array<{
      id: number;
      code: string;
      name: string;
      type: string;
      balance: number;
    }>;

    // Trial Balance
    const trialBalance = accounts.map((a) => {
      const isDebitNormal = a.type === 'Asset' || a.type === 'Expense';
      const debit = isDebitNormal && a.balance >= 0 ? a.balance : !isDebitNormal && a.balance < 0 ? Math.abs(a.balance) : 0;
      const credit = !isDebitNormal && a.balance >= 0 ? a.balance : isDebitNormal && a.balance < 0 ? Math.abs(a.balance) : 0;
      return { ...a, debit, credit };
    });

    const revAccounts = accounts.filter((a) => a.type === 'Revenue');
    const expAccounts = accounts.filter((a) => a.type === 'Expense');
    const totalRevenue = revAccounts.reduce((s, a) => s + a.balance, 0);
    const totalExpenses = expAccounts.reduce((s, a) => s + a.balance, 0);
    const netIncome = totalRevenue - totalExpenses;

    const assets = accounts.filter((a) => a.type === 'Asset');
    const liabilities = accounts.filter((a) => a.type === 'Liability');
    const equity = accounts.filter((a) => a.type === 'Equity');
    const totalAssets = assets.reduce((s, a) => s + a.balance, 0);
    const totalLiabilities = liabilities.reduce((s, a) => s + a.balance, 0);
    const totalEquity = equity.reduce((s, a) => s + a.balance, 0) + netIncome;

    // Cash Flow Statement from Cash/Bank/Mobile accounts (1000, 1010, 1020)
    const cashLines = db
      .prepare(
        `SELECT je.reference_type, COALESCE(SUM(jl.debit), 0) as inflow, COALESCE(SUM(jl.credit), 0) as outflow
         FROM journal_lines jl
         JOIN journal_entries je ON je.id = jl.journal_entry_id
         JOIN accounts a ON a.id = jl.account_id
         WHERE a.code IN ('1000', '1010', '1020')
         GROUP BY je.reference_type`
      )
      .all() as Array<{ reference_type: string; inflow: number; outflow: number }>;

    const cashBalance = accounts
      .filter((a) => ['1000', '1010', '1020'].includes(a.code))
      .reduce((s, a) => s + a.balance, 0);

    res.json({
      trialBalance,
      incomeStatement: { revAccounts, expAccounts, totalRevenue, totalExpenses, netIncome },
      balanceSheet: { assets, liabilities, equity, netIncome, totalAssets, totalLiabilities, totalEquity },
      cashFlow: { cashLines, cashBalance },
    });
  });

  router.get('/accounting/periods', requireAuth, requirePermission('accounting.view'), (_req: Request, res: Response) => {
    const periods = db.prepare('SELECT * FROM financial_periods ORDER BY start_date DESC').all();
    res.json({ periods });
  });

  router.post('/accounting/periods', requireAuth, requirePermission('accounting.manage'), (req: AuthRequest, res: Response) => {
    const { name, start_date, end_date } = req.body || {};
    if (!name || !start_date || !end_date) {
      res.status(400).json({ error: 'Name, start date, and end date are required' });
      return;
    }
    try {
      const info = db
        .prepare("INSERT INTO financial_periods (name, start_date, end_date, status) VALUES (?, ?, ?, 'Open')")
        .run(String(name).trim(), start_date, end_date);
      res.status(201).json({ id: info.lastInsertRowid });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Period already exists' });
    }
  });

  router.put('/accounting/periods/:id/toggle', requireAuth, requirePermission('accounting.manage'), (req: AuthRequest, res: Response) => {
    const p = db.prepare('SELECT * FROM financial_periods WHERE id = ?').get(req.params.id) as { id: number; status: string; name: string } | undefined;
    if (!p) {
      res.status(404).json({ error: 'Financial period not found' });
      return;
    }
    const next = p.status === 'Open' ? 'Closed' : 'Open';
    db.prepare('UPDATE financial_periods SET status = ?, closed_by = ?, closed_at = ? WHERE id = ?').run(
      next,
      next === 'Closed' ? req.user!.username : '',
      next === 'Closed' ? addisDateTime() : '',
      p.id
    );
    logAudit({ userId: req.user!.id, username: req.user!.username, action: next === 'Closed' ? 'CLOSE_PERIOD' : 'REOPEN_PERIOD', module: 'Accounting', recordId: p.name, details: `${next} period ${p.name}` });
    res.json({ status: next });
  });

  // ==================== CURRENCIES ====================
  router.get('/currencies', requireAuth, (_req: Request, res: Response) => {
    const currencies = db.prepare('SELECT * FROM currencies ORDER BY is_default DESC, code ASC').all();
    const history = db.prepare('SELECT * FROM exchange_rate_history ORDER BY id DESC LIMIT 100').all();
    res.json({ currencies, history });
  });

  router.post('/currencies', requireAuth, requirePermission('settings.manage'), (req: AuthRequest, res: Response) => {
    const { code, name, symbol, exchange_rate_to_etb, decimal_places, is_default } = req.body || {};
    const currCode = String(code || '').trim().toUpperCase();
    const rate = Number(exchange_rate_to_etb || 0);
    if (!currCode || !name || !symbol || rate <= 0) {
      res.status(400).json({ error: 'Currency code, name, symbol, and positive exchange rate are required' });
      return;
    }
    const now = addisDateTime();
    try {
      const tx = db.transaction(() => {
        if (is_default) db.prepare('UPDATE currencies SET is_default = 0').run();
        db.prepare(
          `INSERT INTO currencies (code, name, symbol, decimal_places, is_default, exchange_rate_to_etb, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        ).run(currCode, String(name).trim(), String(symbol).trim(), Number(decimal_places ?? 2), is_default ? 1 : 0, rate, now);
        db.prepare('INSERT INTO exchange_rate_history (currency_code, rate_to_etb, changed_by, changed_at) VALUES (?, ?, ?, ?)').run(
          currCode,
          rate,
          req.user!.username,
          now
        );
        if (is_default) {
          db.prepare('UPDATE settings SET default_currency = ?, updated_at = ? WHERE id = 1').run(currCode, now);
        }
        logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'Currency', recordId: currCode, details: `Added ${currCode} (${rate} ETB)` });
      });
      tx();
      res.status(201).json({ code: currCode });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Currency already exists' });
    }
  });

  router.put('/currencies/:code', requireAuth, requirePermission('settings.manage'), (req: AuthRequest, res: Response) => {
    const code = String(req.params.code).toUpperCase();
    const existing = db.prepare('SELECT * FROM currencies WHERE code = ?').get(code) as
      | { code: string; name: string; symbol: string; decimal_places: number; exchange_rate_to_etb: number }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Currency not found' });
      return;
    }
    const { name, symbol, decimal_places, exchange_rate_to_etb, is_default } = req.body || {};
    const rate = exchange_rate_to_etb !== undefined ? Number(exchange_rate_to_etb) : existing.exchange_rate_to_etb;
    if (!rate || rate <= 0) {
      res.status(400).json({ error: 'Exchange rate must be a positive number' });
      return;
    }
    const now = addisDateTime();
    const tx = db.transaction(() => {
      db.prepare('UPDATE currencies SET name = ?, symbol = ?, decimal_places = ?, exchange_rate_to_etb = ?, updated_at = ? WHERE code = ?').run(
        name ? String(name).trim() : existing.name,
        symbol ? String(symbol).trim() : existing.symbol,
        decimal_places !== undefined ? Number(decimal_places) : existing.decimal_places,
        rate,
        now,
        code
      );
      if (rate !== existing.exchange_rate_to_etb) {
        db.prepare('INSERT INTO exchange_rate_history (currency_code, rate_to_etb, changed_by, changed_at) VALUES (?, ?, ?, ?)').run(
          code,
          rate,
          req.user!.username,
          now
        );
      }
      if (is_default) {
        db.prepare('UPDATE currencies SET is_default = 0').run();
        db.prepare('UPDATE currencies SET is_default = 1 WHERE code = ?').run(code);
        db.prepare('UPDATE settings SET default_currency = ?, updated_at = ? WHERE id = 1').run(code, now);
      }
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE_RATE', module: 'Currency', recordId: code, details: `Updated ${code} rate to ${rate} ETB` });
    });
    tx();
    res.json({ ok: true });
  });

  router.put('/currencies/:code/default', requireAuth, requirePermission('settings.manage'), (req: AuthRequest, res: Response) => {
    const code = String(req.params.code).toUpperCase();
    const existing = db.prepare('SELECT code FROM currencies WHERE code = ?').get(code);
    if (!existing) {
      res.status(404).json({ error: 'Currency not found' });
      return;
    }
    const now = addisDateTime();
    const tx = db.transaction(() => {
      db.prepare('UPDATE currencies SET is_default = 0').run();
      db.prepare('UPDATE currencies SET is_default = 1, updated_at = ? WHERE code = ?').run(now, code);
      db.prepare('UPDATE settings SET default_currency = ?, updated_at = ? WHERE id = 1').run(code, now);
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'SET_DEFAULT', module: 'Currency', recordId: code, details: `Set default currency to ${code}` });
    });
    tx();
    res.json({ ok: true });
  });

  router.delete('/currencies/:code', requireAuth, requirePermission('settings.manage'), (req: AuthRequest, res: Response) => {
    const code = String(req.params.code).toUpperCase();
    const row = db.prepare('SELECT * FROM currencies WHERE code = ?').get(code) as { code: string; is_default: number } | undefined;
    if (!row) {
      res.status(404).json({ error: 'Currency not found' });
      return;
    }
    if (row.is_default === 1 || code === 'ETB') {
      res.status(400).json({ error: 'Default or primary ETB currency cannot be deleted' });
      return;
    }
    const usedInSales = (db.prepare('SELECT COUNT(*) as c FROM sales WHERE currency = ?').get(code) as { c: number }).c;
    const usedInPurchases = (db.prepare('SELECT COUNT(*) as c FROM purchases WHERE currency = ?').get(code) as { c: number }).c;
    if (usedInSales > 0 || usedInPurchases > 0) {
      res.status(400).json({ error: 'Cannot delete currency referenced by historical transactions' });
      return;
    }
    db.prepare('DELETE FROM currencies WHERE code = ?').run(code);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'Currency', recordId: code, details: `Deleted currency ${code}` });
    res.json({ ok: true });
  });

  // ==================== USERS, ROLES & AUDIT ====================
  router.get('/users', requireAuth, requirePermission('users.manage'), (_req: Request, res: Response) => {
    const users = db
      .prepare('SELECT id, first_name, last_name, username, email, phone, role, permissions_json, is_active, two_factor_enabled, last_login_at, created_at FROM users ORDER BY id ASC')
      .all() as Array<Record<string, unknown>>;
    res.json({
      users: users.map((u) => ({
        ...u,
        permissions: JSON.parse(String(u.permissions_json || '[]')),
      })),
      roles: ROLES,
      allPermissions: ALL_PERMISSIONS,
      roleDefaults: ROLE_DEFAULT_PERMISSIONS,
    });
  });

  router.post('/users', requireAuth, requirePermission('users.manage'), (req: AuthRequest, res: Response) => {
    const { first_name, last_name, username, email, phone, password, role, permissions } = req.body || {};
    if (!first_name || !last_name || !username || !password || !role) {
      res.status(400).json({ error: 'First name, last name, username, password, and role are required' });
      return;
    }
    const perms = Array.isArray(permissions) && permissions.length > 0 ? permissions : ROLE_DEFAULT_PERMISSIONS[role] || [];
    try {
      const info = db
        .prepare(
          `INSERT INTO users (first_name, last_name, username, email, phone, password_hash, role, permissions_json, is_active, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
        )
        .run(
          String(first_name).trim(),
          String(last_name).trim(),
          String(username).trim(),
          String(email || '').trim(),
          String(phone || '').trim(),
          hashPassword(String(password)),
          role,
          JSON.stringify(perms),
          addisDateTime()
        );
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'CREATE', module: 'User', recordId: String(info.lastInsertRowid), details: `Created ${role} user ${username}` });
      res.status(201).json({ id: info.lastInsertRowid });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Username already exists' });
    }
  });

  router.put('/users/:id', requireAuth, requirePermission('users.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    const { first_name, last_name, email, phone, role, permissions, is_active, password } = req.body || {};
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!existing) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    const permsJson = Array.isArray(permissions) ? JSON.stringify(permissions) : String(existing.permissions_json);
    db.prepare(
      'UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, role = ?, permissions_json = ?, is_active = ? WHERE id = ?'
    ).run(
      first_name ?? existing.first_name,
      last_name ?? existing.last_name,
      email ?? existing.email,
      phone ?? existing.phone,
      role ?? existing.role,
      permsJson,
      is_active !== undefined ? (is_active ? 1 : 0) : existing.is_active,
      id
    );
    if (password && String(password).length >= 6) {
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(String(password)), id);
    }
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'User', recordId: String(id), details: `Updated user ${existing.username}` });
    res.json({ ok: true });
  });

  router.delete('/users/:id', requireAuth, requirePermission('users.manage'), (req: AuthRequest, res: Response) => {
    const id = Number(req.params.id);
    if (id === req.user!.id) {
      res.status(400).json({ error: 'You cannot delete your own active account' });
      return;
    }
    if (id === 1) {
      res.status(400).json({ error: 'Primary Super Administrator cannot be deleted' });
      return;
    }
    db.prepare('DELETE FROM users WHERE id = ?').run(id);
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'DELETE', module: 'User', recordId: String(id), details: 'Deleted user' });
    res.json({ ok: true });
  });

  router.get('/audit-logs', requireAuth, requirePermission('users.manage'), (req: Request, res: Response) => {
    const username = String(req.query.username || '').trim();
    const logs = username
      ? db.prepare('SELECT * FROM audit_logs WHERE username = ? ORDER BY id DESC LIMIT 300').all(username)
      : db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 300').all();
    res.json({ logs });
  });

  router.get('/login-history', requireAuth, requirePermission('users.manage'), (_req: Request, res: Response) => {
    const history = db
      .prepare(
        `SELECT s.created_at, s.expires_at, s.ip_info, s.user_agent, s.is_active, u.username, u.role
         FROM sessions s JOIN users u ON u.id = s.user_id
         ORDER BY s.created_at DESC LIMIT 200`
      )
      .all();
    res.json({ history });
  });

  // ==================== SETTINGS ====================
  router.get('/settings', requireAuth, (_req: Request, res: Response) => {
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    res.json({ settings });
  });

  router.put('/settings', requireAuth, requirePermission('settings.manage'), (req: AuthRequest, res: Response) => {
    const b = req.body || {};
    const current = db.prepare('SELECT * FROM settings WHERE id = 1').get() as Record<string, unknown>;
    const now = addisDateTime();
    db.prepare(
      `UPDATE settings SET
        business_name = ?, system_name = ?, logo_url = ?, favicon_url = ?, phone = ?, email = ?, website = ?, address = ?, tin = ?,
        vat_rate = ?, allow_negative_stock = ?, default_currency = ?, default_language = ?,
        receipt_header = ?, receipt_footer = ?, sale_prefix = ?, purchase_prefix = ?, return_prefix = ?,
        min_password_length = ?, require_2fa = ?, updated_at = ?
       WHERE id = 1`
    ).run(
      b.business_name ?? current.business_name,
      b.system_name ?? current.system_name,
      b.logo_url ?? current.logo_url,
      b.favicon_url !== undefined ? b.favicon_url : (current.favicon_url ?? ''),
      b.phone ?? current.phone,
      b.email ?? current.email,
      b.website ?? current.website,
      b.address ?? current.address,
      b.tin ?? current.tin,
      b.vat_rate !== undefined ? Number(b.vat_rate) : current.vat_rate,
      b.allow_negative_stock !== undefined ? (b.allow_negative_stock ? 1 : 0) : current.allow_negative_stock,
      b.default_currency ?? current.default_currency,
      b.default_language ?? current.default_language,
      b.receipt_header ?? current.receipt_header,
      b.receipt_footer ?? current.receipt_footer,
      b.sale_prefix ?? current.sale_prefix,
      b.purchase_prefix ?? current.purchase_prefix,
      b.return_prefix ?? current.return_prefix,
      b.min_password_length !== undefined ? Number(b.min_password_length) : current.min_password_length,
      b.require_2fa !== undefined ? (b.require_2fa ? 1 : 0) : current.require_2fa,
      now
    );
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'UPDATE', module: 'Settings', details: 'Updated system & branding settings' });
    res.json({ settings: db.prepare('SELECT * FROM settings WHERE id = 1').get() });
  });

  // ==================== NOTIFICATIONS ====================
  router.get('/notifications', requireAuth, (_req: Request, res: Response) => {
    const notifications = db.prepare('SELECT * FROM notifications ORDER BY id DESC LIMIT 100').all();
    const unread = (db.prepare('SELECT COUNT(*) as c FROM notifications WHERE is_read = 0').get() as { c: number }).c;
    res.json({ notifications, unread });
  });

  router.put('/notifications/read-all', requireAuth, (_req: Request, res: Response) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE is_read = 0').run();
    res.json({ ok: true });
  });

  router.put('/notifications/:id/read', requireAuth, (req: Request, res: Response) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').run(req.params.id);
    res.json({ ok: true });
  });

  // ==================== REPORTS ====================
  router.get('/reports/:type', requireAuth, requirePermission('reports.view'), (req: Request, res: Response) => {
    const type = String(req.params.type);
    const start = String(req.query.start || addisDate(-30));
    const end = String(req.query.end || addisDate(0));

    switch (type) {
      case 'daily_sales':
      case 'sales': {
        const rows = db
          .prepare(
            `SELECT s.invoice_number, s.sale_date, COALESCE(c.full_name, 'Walk-In') as customer, s.payment_method, s.currency, s.subtotal, s.discount_amount, s.vat_amount, s.grand_total, s.paid_amount, s.balance_amount, s.status, s.created_by
             FROM sales s LEFT JOIN customers c ON c.id = s.customer_id
             WHERE s.status NOT IN ('Held', 'Cancelled') AND s.sale_date BETWEEN ? AND ?
             ORDER BY s.sale_date DESC, s.id DESC`
          )
          .all(start, end);
        res.json({ rows });
        return;
      }
      case 'monthly_sales': {
        const rows = db
          .prepare(
            `SELECT substr(sale_date, 1, 7) as month, COUNT(*) as invoices,
                    COALESCE(SUM(subtotal * exchange_rate), 0) as subtotal_etb,
                    COALESCE(SUM(vat_amount * exchange_rate), 0) as vat_etb,
                    COALESCE(SUM(grand_total * exchange_rate), 0) as total_etb,
                    COALESCE(SUM(paid_amount * exchange_rate), 0) as paid_etb
             FROM sales WHERE status NOT IN ('Held', 'Cancelled') AND sale_date BETWEEN ? AND ?
             GROUP BY month ORDER BY month DESC`
          )
          .all(start, end);
        res.json({ rows });
        return;
      }
      case 'annual_sales': {
        const rows = db
          .prepare(
            `SELECT substr(sale_date, 1, 4) as year, COUNT(*) as invoices,
                    COALESCE(SUM(subtotal * exchange_rate), 0) as subtotal_etb,
                    COALESCE(SUM(vat_amount * exchange_rate), 0) as vat_etb,
                    COALESCE(SUM(grand_total * exchange_rate), 0) as total_etb
             FROM sales WHERE status NOT IN ('Held', 'Cancelled')
             GROUP BY year ORDER BY year DESC`
          )
          .all();
        res.json({ rows });
        return;
      }
      case 'purchases': {
        const rows = db
          .prepare(
            `SELECT p.purchase_number, p.purchase_date, COALESCE(s.business_name, 'Supplier') as supplier, p.currency, p.subtotal, p.vat_amount, p.grand_total, p.paid_amount, p.balance_amount, p.status, p.created_by
             FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id
             WHERE p.purchase_date BETWEEN ? AND ?
             ORDER BY p.purchase_date DESC, p.id DESC`
          )
          .all(start, end);
        res.json({ rows });
        return;
      }
      case 'profit_loss': {
        const rev = db
          .prepare(
            `SELECT COALESCE(SUM((subtotal - discount_amount) * exchange_rate), 0) as revenue, COALESCE(SUM(vat_amount * exchange_rate), 0) as vat
             FROM sales WHERE status NOT IN ('Held', 'Cancelled') AND sale_date BETWEEN ? AND ?`
          )
          .get(start, end) as { revenue: number; vat: number };
        const cogs = (
          db
            .prepare(
              `SELECT COALESCE(SUM((si.quantity - si.returned_qty) * si.cost_price), 0) as cogs
               FROM sale_items si JOIN sales s ON s.id = si.sale_id
               WHERE s.status NOT IN ('Held', 'Cancelled') AND s.sale_date BETWEEN ? AND ?`
            )
            .get(start, end) as { cogs: number }
        ).cogs;
        const expenses = (
          db
            .prepare('SELECT COALESCE(SUM(amount_etb), 0) as total FROM expenses WHERE expense_date BETWEEN ? AND ?')
            .get(start, end) as { total: number }
        ).total;
        const grossProfit = rev.revenue - cogs;
        const netProfit = grossProfit - expenses;
        const margin = rev.revenue > 0 ? (netProfit / rev.revenue) * 100 : 0;
        res.json({
          rows: [
            { item: 'Sales Revenue (Excl. VAT)', amount_etb: rev.revenue },
            { item: 'Cost of Goods Sold (COGS)', amount_etb: -cogs },
            { item: 'Gross Profit', amount_etb: grossProfit },
            { item: 'Operating Expenses', amount_etb: -expenses },
            { item: 'Net Profit', amount_etb: netProfit },
            { item: 'Net Profit Margin (%)', amount_etb: Number(margin.toFixed(2)) },
          ],
        });
        return;
      }
      case 'inventory': {
        const rows = db
          .prepare(
            `SELECT p.sku, p.barcode, p.name, COALESCE(c.name, '-') as category, p.unit, p.current_stock, p.min_stock, p.purchase_price, p.selling_price, (p.current_stock * p.purchase_price) as cost_valuation
             FROM products p LEFT JOIN categories c ON c.id = p.category_id
             WHERE p.is_active = 1 ORDER BY p.name ASC`
          )
          .all();
        res.json({ rows });
        return;
      }
      case 'low_stock': {
        const rows = db
          .prepare(
            `SELECT p.sku, p.name, COALESCE(c.name, '-') as category, p.unit, p.current_stock, p.min_stock, p.purchase_price
             FROM products p LEFT JOIN categories c ON c.id = p.category_id
             WHERE p.is_active = 1 AND p.current_stock <= p.min_stock ORDER BY p.current_stock ASC`
          )
          .all();
        res.json({ rows });
        return;
      }
      case 'customer_debt': {
        const rows = db
          .prepare('SELECT id, full_name, phone, address, total_purchases, total_paid, outstanding_balance FROM customers WHERE outstanding_balance > 0 ORDER BY outstanding_balance DESC')
          .all();
        res.json({ rows });
        return;
      }
      case 'supplier_debt': {
        const rows = db
          .prepare('SELECT id, business_name, contact_person, phone, total_purchases, total_paid, outstanding_balance FROM suppliers WHERE outstanding_balance > 0 ORDER BY outstanding_balance DESC')
          .all();
        res.json({ rows });
        return;
      }
      case 'expenses': {
        const rows = db
          .prepare('SELECT expense_code, expense_date, category, description, amount, currency, amount_etb, payment_method, created_by FROM expenses WHERE expense_date BETWEEN ? AND ? ORDER BY expense_date DESC')
          .all(start, end);
        res.json({ rows });
        return;
      }
      case 'vat': {
        const salesVat = db
          .prepare(
            `SELECT invoice_number as ref, sale_date as date, 'Output VAT (Sales)' as type, (subtotal - discount_amount) * exchange_rate as taxable_etb, vat_amount * exchange_rate as vat_etb
             FROM sales WHERE status NOT IN ('Held', 'Cancelled') AND sale_date BETWEEN ? AND ?`
          )
          .all(start, end);
        const purVat = db
          .prepare(
            `SELECT purchase_number as ref, purchase_date as date, 'Input VAT (Purchases)' as type, (subtotal - discount_amount) * exchange_rate as taxable_etb, vat_amount * exchange_rate as vat_etb
             FROM purchases WHERE purchase_date BETWEEN ? AND ?`
          )
          .all(start, end);
        res.json({ rows: [...salesVat, ...purVat] });
        return;
      }
      case 'employee_performance': {
        const rows = db
          .prepare(
            `SELECT created_by as employee, COUNT(*) as sales_count, COALESCE(SUM(grand_total * exchange_rate), 0) as total_sales_etb, COALESCE(SUM(paid_amount * exchange_rate), 0) as collected_etb
             FROM sales WHERE status NOT IN ('Held', 'Cancelled') AND sale_date BETWEEN ? AND ?
             GROUP BY created_by ORDER BY total_sales_etb DESC`
          )
          .all(start, end);
        res.json({ rows });
        return;
      }
      case 'payments': {
        const custP = db
          .prepare(
            `SELECT 'Customer Payment' as type, c.full_name as party, cp.amount, cp.currency, cp.amount_etb, cp.payment_method, cp.created_by, cp.created_at
             FROM customer_payments cp JOIN customers c ON c.id = cp.customer_id
             WHERE substr(cp.created_at, 1, 10) BETWEEN ? AND ?`
          )
          .all(start, end);
        const supP = db
          .prepare(
            `SELECT 'Supplier Payment' as type, s.business_name as party, sp.amount, sp.currency, sp.amount_etb, sp.payment_method, sp.created_by, sp.created_at
             FROM supplier_payments sp JOIN suppliers s ON s.id = sp.supplier_id
             WHERE substr(sp.created_at, 1, 10) BETWEEN ? AND ?`
          )
          .all(start, end);
        res.json({ rows: [...custP, ...supP] });
        return;
      }
      case 'sales_returns': {
        const rows = db
          .prepare(
            `SELECT sr.return_number, sr.invoice_number, sr.return_date, COALESCE(c.full_name, 'Walk-In') as customer, sr.refund_method, sr.total_refund, sr.status, sr.reason, sr.created_by
             FROM sale_returns sr LEFT JOIN customers c ON c.id = sr.customer_id
             WHERE sr.return_date BETWEEN ? AND ?
             ORDER BY sr.return_date DESC, sr.id DESC`
          )
          .all(start, end);
        res.json({ rows });
        return;
      }
      case 'purchase_returns': {
        const rows = db
          .prepare(
            `SELECT pr.return_number, pr.purchase_number, pr.return_date, COALESCE(s.business_name, 'Supplier') as supplier, pr.total_refund, pr.status, pr.reason, pr.created_by
             FROM purchase_returns pr LEFT JOIN suppliers s ON s.id = pr.supplier_id
             WHERE pr.return_date BETWEEN ? AND ?
             ORDER BY pr.return_date DESC, pr.id DESC`
          )
          .all(start, end);
        res.json({ rows });
        return;
      }
      case 'cash_flow': {
        const cashInSales = (
          db
            .prepare("SELECT COALESCE(SUM(paid_amount * exchange_rate), 0) as v FROM sales WHERE status NOT IN ('Held','Cancelled') AND sale_date BETWEEN ? AND ?")
            .get(start, end) as { v: number }
        ).v;
        const cashInCustPay = (
          db
            .prepare('SELECT COALESCE(SUM(amount_etb), 0) as v FROM customer_payments WHERE substr(created_at, 1, 10) BETWEEN ? AND ?')
            .get(start, end) as { v: number }
        ).v;
        const cashOutPurchases = (
          db
            .prepare('SELECT COALESCE(SUM(paid_amount * exchange_rate), 0) as v FROM purchases WHERE purchase_date BETWEEN ? AND ?')
            .get(start, end) as { v: number }
        ).v;
        const cashOutSupPay = (
          db
            .prepare('SELECT COALESCE(SUM(amount_etb), 0) as v FROM supplier_payments WHERE substr(created_at, 1, 10) BETWEEN ? AND ?')
            .get(start, end) as { v: number }
        ).v;
        const cashOutExpenses = (
          db
            .prepare('SELECT COALESCE(SUM(amount_etb), 0) as v FROM expenses WHERE expense_date BETWEEN ? AND ?')
            .get(start, end) as { v: number }
        ).v;
        const cashOutSaleReturns = (
          db
            .prepare('SELECT COALESCE(SUM(total_refund), 0) as v FROM sale_returns WHERE return_date BETWEEN ? AND ?')
            .get(start, end) as { v: number }
        ).v;
        const totalInflow = cashInSales + cashInCustPay;
        const totalOutflow = cashOutPurchases + cashOutSupPay + cashOutExpenses + cashOutSaleReturns;
        res.json({
          rows: [
            { cash_flow_item: 'Cash Receipts from Sales', type: 'Inflow', amount_etb: cashInSales },
            { cash_flow_item: 'Customer Debt Collections', type: 'Inflow', amount_etb: cashInCustPay },
            { cash_flow_item: 'Payments for Purchases', type: 'Outflow', amount_etb: -cashOutPurchases },
            { cash_flow_item: 'Supplier Debt Payments', type: 'Outflow', amount_etb: -cashOutSupPay },
            { cash_flow_item: 'Operating Expenses Paid', type: 'Outflow', amount_etb: -cashOutExpenses },
            { cash_flow_item: 'Sales Return Refunds', type: 'Outflow', amount_etb: -cashOutSaleReturns },
            { cash_flow_item: 'Net Cash Flow', type: 'Net', amount_etb: totalInflow - totalOutflow },
          ],
        });
        return;
      }
      case 'outstanding_balances': {
        const custBalances = db
          .prepare("SELECT customer_code as code, full_name as party, 'Customer Receivable' as balance_type, phone, total_purchases, total_paid, outstanding_balance FROM customers WHERE outstanding_balance > 0")
          .all();
        const supBalances = db
          .prepare("SELECT supplier_code as code, business_name as party, 'Supplier Payable' as balance_type, phone, total_purchases, total_paid, outstanding_balance FROM suppliers WHERE outstanding_balance > 0")
          .all();
        res.json({ rows: [...custBalances, ...supBalances] });
        return;
      }
      case 'stock_valuation': {
        const rows = db
          .prepare(
            `SELECT p.product_code, p.sku, p.name, COALESCE(c.name, '-') as category, p.unit, p.current_stock, p.purchase_price as unit_cost, p.selling_price as unit_price, (p.current_stock * p.purchase_price) as cost_value_etb, (p.current_stock * p.selling_price) as retail_value_etb, ((p.selling_price - p.purchase_price) * p.current_stock) as potential_profit_etb
             FROM products p LEFT JOIN categories c ON c.id = p.category_id
             WHERE p.is_active = 1
             ORDER BY cost_value_etb DESC`
          )
          .all();
        res.json({ rows });
        return;
      }
      case 'stock_movements': {
        const rows = db
          .prepare(
            `SELECT m.created_at, p.sku, p.name as product_name, m.movement_type, m.quantity, m.unit_cost, m.reference_id, m.notes, m.created_by
             FROM stock_movements m JOIN products p ON p.id = m.product_id
             WHERE substr(m.created_at, 1, 10) BETWEEN ? AND ?
             ORDER BY m.id DESC`
          )
          .all(start, end);
        res.json({ rows });
        return;
      }
      default:
        res.status(400).json({ error: 'Unknown report type' });
    }
  });

  // ==================== BACKUP & RESTORE ====================
  router.get('/backup/export', requireAuth, requirePermission('backup.manage'), (req: AuthRequest, res: Response) => {
    const tables = [
      'settings',
      'currencies',
      'exchange_rate_history',
      'users',
      'categories',
      'units',
      'vat_rates',
      'warehouses',
      'products',
      'stock_movements',
      'customers',
      'customer_payments',
      'suppliers',
      'supplier_payments',
      'opening_balance_entries',
      'sales',
      'sale_items',
      'sale_returns',
      'sale_return_items',
      'purchases',
      'purchase_items',
      'purchase_returns',
      'purchase_return_items',
      'expense_categories',
      'expenses',
      'accounts',
      'journal_entries',
      'journal_lines',
      'financial_periods',
      'notifications',
      'audit_logs',
    ];
    const data: Record<string, unknown[]> = {};
    for (const t of tables) {
      data[t] = db.prepare(`SELECT * FROM ${t}`).all();
    }
    logAudit({ userId: req.user!.id, username: req.user!.username, action: 'BACKUP_EXPORT', module: 'Backup', details: 'Exported full ERP database backup' });
    res.json({
      system: 'QABDIID BUSNESS 1',
      exportedAt: addisDateTime(),
      timezone: 'Africa/Addis_Ababa',
      data,
    });
  });

  router.post('/backup/restore', requireAuth, requirePermission('backup.manage'), (req: AuthRequest, res: Response) => {
    const payload = req.body;
    if (!payload || payload.system !== 'QABDIID BUSNESS 1' || !payload.data || typeof payload.data !== 'object') {
      res.status(400).json({ error: 'Invalid QABDIID BUSNESS 1 backup file' });
      return;
    }

    const orderedTables = [
      'settings',
      'currencies',
      'exchange_rate_history',
      'users',
      'categories',
      'units',
      'vat_rates',
      'warehouses',
      'products',
      'stock_movements',
      'customers',
      'customer_payments',
      'suppliers',
      'supplier_payments',
      'opening_balance_entries',
      'sales',
      'sale_items',
      'sale_returns',
      'sale_return_items',
      'purchases',
      'purchase_items',
      'purchase_returns',
      'purchase_return_items',
      'expense_categories',
      'expenses',
      'accounts',
      'journal_entries',
      'journal_lines',
      'financial_periods',
      'notifications',
      'audit_logs',
    ];

    try {
      db.pragma('foreign_keys = OFF');
      const tx = db.transaction(() => {
        for (const table of [...orderedTables].reverse()) {
          if (Array.isArray(payload.data[table])) {
            db.prepare(`DELETE FROM ${table}`).run();
          }
        }
        for (const table of orderedTables) {
          const rows = payload.data[table];
          if (!Array.isArray(rows) || rows.length === 0) continue;
          const cols = Object.keys(rows[0] as Record<string, unknown>);
          const placeholders = cols.map(() => '?').join(', ');
          const stmt = db.prepare(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${placeholders})`);
          for (const row of rows) {
            const rec = row as Record<string, unknown>;
            stmt.run(...cols.map((c) => rec[c] ?? null));
          }
        }
      });
      tx();
      db.pragma('foreign_keys = ON');
      logAudit({ userId: req.user!.id, username: req.user!.username, action: 'BACKUP_RESTORE', module: 'Backup', details: 'Restored ERP database from backup' });
      res.json({ ok: true });
    } catch (err: unknown) {
      db.pragma('foreign_keys = ON');
      res.status(400).json({ error: err instanceof Error ? err.message : 'Restore failed' });
    }
  });

  // ==================== DEBTS MANAGEMENT ====================
  router.get('/debts', requireAuth, requirePermission('people.view'), (_req: Request, res: Response) => {
    const customerDebts = db
      .prepare('SELECT * FROM customers WHERE outstanding_balance > 0 ORDER BY outstanding_balance DESC')
      .all();
    const supplierDebts = db
      .prepare('SELECT * FROM suppliers WHERE outstanding_balance > 0 ORDER BY outstanding_balance DESC')
      .all();
    const unpaidSales = db
      .prepare(
        `SELECT s.id, s.invoice_number, s.sale_date, s.customer_id, COALESCE(c.full_name, 'Walk-In') as customer_name, c.phone as customer_phone,
                s.currency, s.exchange_rate, s.grand_total, s.paid_amount, s.balance_amount, s.status
         FROM sales s
         LEFT JOIN customers c ON c.id = s.customer_id
         WHERE s.balance_amount > 0.01 AND s.status NOT IN ('Held', 'Cancelled')
         ORDER BY s.id DESC`
      )
      .all();
    const unpaidPurchases = db
      .prepare(
        `SELECT p.id, p.purchase_number, p.purchase_date, p.supplier_id, COALESCE(s.business_name, 'Supplier') as supplier_name, s.phone as supplier_phone,
                p.currency, p.exchange_rate, p.grand_total, p.paid_amount, p.balance_amount, p.status
         FROM purchases p
         LEFT JOIN suppliers s ON s.id = p.supplier_id
         WHERE p.balance_amount > 0.01
         ORDER BY p.id DESC`
      )
      .all();
    const paymentHistory = db
      .prepare(
        `SELECT * FROM (
           SELECT 'Customer' as party_type, c.full_name as party_name, cp.amount, cp.currency, cp.amount_etb, cp.payment_method, cp.notes, cp.created_by, cp.created_at
           FROM customer_payments cp JOIN customers c ON c.id = cp.customer_id
           UNION ALL
           SELECT 'Supplier' as party_type, s.business_name as party_name, sp.amount, sp.currency, sp.amount_etb, sp.payment_method, sp.notes, sp.created_by, sp.created_at
           FROM supplier_payments sp JOIN suppliers s ON s.id = sp.supplier_id
         )
         ORDER BY created_at DESC LIMIT 200`
      )
      .all();

    res.json({ customerDebts, supplierDebts, unpaidSales, unpaidPurchases, paymentHistory });
  });

  return router;
}
