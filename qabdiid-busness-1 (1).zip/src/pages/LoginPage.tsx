import React, { useState } from 'react';
import { Lock, User as UserIcon } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { LiquidThemeSelector } from '../components/LiquidThemeSelector.tsx';

export function LoginPage() {
  const { login, language, setLanguage, t } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(username, password);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : t('loginError'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-transparent flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md bg-white dark:bg-[#0B1F4D] border border-[#E2E8F0] dark:border-[#1E3A8A] rounded-2xl p-8 erp-card">
        <div className="flex items-center justify-between mb-8 gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src="/src/assets/images/qabdiid_brand_mark_1794940828806.jpg"
              alt="QABDIID BUSNESS 1"
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-xl object-cover border border-[#06B6D4]/40 bg-white shrink-0"
            />
            <div className="min-w-0">
              <div className="font-display font-bold text-base text-[#0B1F4D] dark:text-[#F8FAFC] truncate">
                QABDIID BUSNESS 1
              </div>
              <div className="text-xs text-slate-500 dark:text-[#06B6D4] truncate">
                {t('appTagline')}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <div className="flex items-center p-0.5 rounded-xl bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-[#1E3A8A]">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 text-xs font-semibold rounded-lg ${
                  language === 'en' ? 'bg-[#2563EB] text-white' : 'text-slate-500 dark:text-slate-300'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('so')}
                className={`px-2 py-1 text-xs font-semibold rounded-lg ${
                  language === 'so' ? 'bg-[#2563EB] text-white' : 'text-slate-500 dark:text-slate-300'
                }`}
              >
                SO
              </button>
            </div>
            <LiquidThemeSelector />
          </div>
        </div>

        <h1 className="font-display text-xl font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-1">
          {t('signIn')}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-300 mb-6">{t('loginWelcome')}</p>

        {error && (
          <div className="mb-4 px-3.5 py-2.5 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 text-xs font-medium text-red-700 dark:text-red-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#0B1F4D] dark:text-slate-200 mb-1.5">
              {t('username')}
            </label>
            <div className="relative">
              <UserIcon className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-[#1E3A8A] bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC] focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#0B1F4D] dark:text-slate-200 mb-1.5">
              {t('password')}
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-[#1E3A8A] bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC] focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-sm font-semibold shadow-[0_4px_14px_rgba(37,99,235,0.35)] hover:shadow-[0_6px_18px_rgba(37,99,235,0.45)] active:scale-[0.99] transition-all disabled:opacity-60"
          >
            {loading ? t('loading') : t('signIn')}
          </button>
        </form>

        <div className="mt-6 pt-5 border-t border-[#E2E8F0] dark:border-white/10 text-xs text-slate-500 dark:text-slate-300 space-y-1">
          <div className="font-semibold text-[#0B1F4D] dark:text-white">Default System Accounts:</div>
          <div className="flex justify-between font-mono-num">
            <span>Super Admin: admin / admin123</span>
            <button
              type="button"
              onClick={() => {
                setUsername('admin');
                setPassword('admin123');
              }}
              className="text-[#2563EB] dark:text-[#06B6D4] hover:underline font-sans font-semibold"
            >
              Fill
            </button>
          </div>
          <div className="flex justify-between font-mono-num">
            <span>Cashier: cashier / cashier123</span>
            <button
              type="button"
              onClick={() => {
                setUsername('cashier');
                setPassword('cashier123');
              }}
              className="text-[#2563EB] dark:text-[#06B6D4] hover:underline font-sans font-semibold"
            >
              Fill
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
