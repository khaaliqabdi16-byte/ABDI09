import React, { useEffect, useState, useCallback } from 'react';
import { Plus, Trash2, Edit2, Printer, Download, Upload, Paperclip, X } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { exportReportPdf, formatMoney } from '../utils/export.ts';
import { compressImageFile } from '../utils/image.ts';
import { CurrencyCode, Expense, ExpenseCategoryItem } from '../types/erp.ts';

type ExpensesTab = 'list' | 'categories';

export function ExpensesPage() {
  const { t, settings, currencies, activeSubTab, setActiveSubTab, hasPermission, showToast } = useApp();
  const [tab, setTab] = useState<ExpensesTab>(() => (activeSubTab === 'categories' ? 'categories' : 'list'));
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [categories, setCategories] = useState<ExpenseCategoryItem[]>([]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [title, setTitle] = useState('');
  const [expenseDate, setExpenseDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [category, setCategory] = useState('General Expenses');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<CurrencyCode>('ETB');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [receiptRef, setReceiptRef] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');

  const [catModalOpen, setCatModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<ExpenseCategoryItem | null>(null);
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');

  useEffect(() => {
    if (activeSubTab === 'list' || activeSubTab === 'categories') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const handleTabChange = (next: ExpensesTab) => {
    setTab(next);
    setActiveSubTab(next);
  };

  const loadData = useCallback(async () => {
    try {
      const [eRes, cRes] = await Promise.all([
        apiFetch<{ expenses: Expense[] }>('/api/expenses'),
        apiFetch<{ categories: ExpenseCategoryItem[] }>('/api/expense-categories'),
      ]);
      setExpenses(eRes.expenses);
      setCategories(cRes.categories);
      if (cRes.categories.length > 0) {
        setCategory((prev) => (cRes.categories.some((c) => c.name === prev) ? prev : cRes.categories[0].name));
      }
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load expenses', 'error');
    }
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const totalEtb = expenses.reduce((s, e) => s + e.amount_etb, 0);

  const openAddExpense = () => {
    setEditingExpense(null);
    setTitle('');
    setExpenseDate(new Date().toISOString().slice(0, 10));
    setCategory(categories[0]?.name || 'General Expenses');
    setDescription('');
    setAmount('');
    setCurrency('ETB');
    setPaymentMethod('Cash');
    setReceiptRef('');
    setAttachmentUrl('');
    setModalOpen(true);
  };

  const openEditExpense = (ex: Expense) => {
    setEditingExpense(ex);
    setTitle(ex.title || ex.description || '');
    setExpenseDate(ex.expense_date);
    setCategory(ex.category);
    setDescription(ex.description || '');
    setAmount(String(ex.amount));
    setCurrency(ex.currency);
    setPaymentMethod(ex.payment_method);
    setReceiptRef(ex.receipt_ref || '');
    setAttachmentUrl(ex.attachment_url || '');
    setModalOpen(true);
  };

  const handleAttachmentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      if (file.type.startsWith('image/')) {
        const dataUrl = await compressImageFile(file, 800, 0.8);
        setAttachmentUrl(dataUrl);
      } else {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') setAttachmentUrl(reader.result);
        };
        reader.readAsDataURL(file);
      }
      showToast('Attachment loaded', 'success');
    } catch {
      showToast('Unable to read attachment file', 'error');
    }
  };

  const saveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        expense_date: expenseDate,
        title,
        category,
        description: description || title,
        amount: Number(amount),
        currency,
        payment_method: paymentMethod,
        receipt_ref: receiptRef,
        attachment_url: attachmentUrl,
      };
      if (editingExpense) {
        await apiFetch(`/api/expenses/${editingExpense.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('Expense updated', 'success');
      } else {
        await apiFetch('/api/expenses', { method: 'POST', body: JSON.stringify(payload) });
        showToast('Expense recorded', 'success');
      }
      setModalOpen(false);
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save expense', 'error');
    }
  };

  const deleteExpense = async (id: number) => {
    try {
      await apiFetch(`/api/expenses/${id}`, { method: 'DELETE' });
      showToast('Expense reversed & deleted', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to delete expense', 'error');
    }
  };

  const saveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCat) {
        await apiFetch(`/api/expense-categories/${editingCat.id}`, {
          method: 'PUT',
          body: JSON.stringify({ name: catName, description: catDesc }),
        });
        showToast('Expense category updated', 'success');
      } else {
        await apiFetch('/api/expense-categories', {
          method: 'POST',
          body: JSON.stringify({ name: catName, description: catDesc }),
        });
        showToast('Expense category added', 'success');
      }
      setCatModalOpen(false);
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save category', 'error');
    }
  };

  const deleteCategory = async (id: number) => {
    try {
      await apiFetch(`/api/expense-categories/${id}`, { method: 'DELETE' });
      showToast('Expense category deleted', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to delete category', 'error');
    }
  };

  const printExpenseReport = () => {
    exportReportPdf(
      'Expense Report',
      expenses.map((ex) => ({
        Code: ex.expense_code,
        Date: ex.expense_date,
        Title: ex.title || ex.description,
        Category: ex.category,
        Method: ex.payment_method,
        Amount: `${ex.amount} ${ex.currency}`,
        'ETB Total': ex.amount_etb,
        By: ex.created_by,
      })),
      settings
    );
  };

  return (
    <div className="space-y-5">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 erp-card no-print">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleTabChange('list')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold ${
                tab === 'list' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              {t('expenses')} ({expenses.length})
            </button>
            <button
              onClick={() => handleTabChange('categories')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold ${
                tab === 'categories' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              {t('expenseCategories')} ({categories.length})
            </button>
          </div>
          <div className="pl-3 border-l border-slate-200 dark:border-slate-700">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 block">{t('totalExpenses')}</span>
            <span className="text-sm font-bold font-mono-num text-amber-700 dark:text-amber-400">
              {formatMoney(totalEtb, 'ETB')}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {tab === 'list' && (
            <>
              <button
                onClick={printExpenseReport}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs font-medium hover:bg-[#F8FAFC] dark:hover:bg-slate-800"
              >
                <Download className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />
                {t('exportPdf')}
              </button>
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs font-medium hover:bg-[#F8FAFC] dark:hover:bg-slate-800"
              >
                <Printer className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />
                Print
              </button>
            </>
          )}
          {hasPermission('expenses.manage') && tab === 'list' && (
            <button
              onClick={openAddExpense}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              {t('addExpense')}
            </button>
          )}
          {hasPermission('expenses.manage') && tab === 'categories' && (
            <button
              onClick={() => {
                setEditingCat(null);
                setCatName('');
                setCatDesc('');
                setCatModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Category
            </button>
          )}
        </div>
      </div>

      {tab === 'list' ? (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Code</th>
                  <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('expenseTitle')} / {t('description')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('category')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('paymentMethod')}</th>
                  <th className="text-right px-4 py-3 font-medium">Amount</th>
                  <th className="text-right px-4 py-3 font-medium">ETB Total</th>
                  <th className="text-left px-4 py-3 font-medium">{t('attachment')}</th>
                  <th className="text-right px-4 py-3 font-medium no-print">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {expenses.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-10 text-center text-slate-500">
                      {t('noRecords')}
                    </td>
                  </tr>
                ) : (
                  expenses.map((ex) => (
                    <tr key={ex.id}>
                      <td className="px-4 py-3 font-mono-num font-semibold">{ex.expense_code}</td>
                      <td className="px-4 py-3 font-mono-num text-slate-500">{ex.expense_date}</td>
                      <td className="px-4 py-3">
                        <div className="font-semibold">{ex.title || ex.description}</div>
                        {ex.title && ex.description && ex.title !== ex.description && (
                          <div className="text-[11px] text-slate-500">{ex.description}</div>
                        )}
                        {ex.receipt_ref && <div className="text-[11px] text-slate-400 font-mono-num">Ref: {ex.receipt_ref}</div>}
                      </td>
                      <td className="px-4 py-3">{ex.category}</td>
                      <td className="px-4 py-3">{ex.payment_method}</td>
                      <td className="px-4 py-3 text-right font-mono-num">{formatMoney(ex.amount, ex.currency)}</td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold">{formatMoney(ex.amount_etb, 'ETB')}</td>
                      <td className="px-4 py-3">
                        {ex.attachment_url ? (
                          <a
                            href={ex.attachment_url}
                            target="_blank"
                            rel="noreferrer"
                            download={`expense_${ex.expense_code}`}
                            className="inline-flex items-center gap-1 text-[#2563EB] dark:text-[#06B6D4] hover:underline"
                          >
                            <Paperclip className="w-3.5 h-3.5" /> View
                          </a>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right no-print">
                        {hasPermission('expenses.manage') && (
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => openEditExpense(ex)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                              title={t('edit')}
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => deleteExpense(ex.id)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600"
                              title={t('delete')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Name</th>
                  <th className="text-left px-4 py-3 font-medium">{t('description')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {categories.map((c) => (
                  <tr key={c.id}>
                    <td className="px-4 py-3 font-semibold">{c.name}</td>
                    <td className="px-4 py-3 text-slate-500">{c.description || '-'}</td>
                    <td className="px-4 py-3 text-right">
                      {hasPermission('expenses.manage') && (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              setEditingCat(c);
                              setCatName(c.name);
                              setCatDesc(c.description || '');
                              setCatModalOpen(true);
                            }}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteCategory(c.id)}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Expense Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={saveExpense} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-3 text-xs erp-card max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0] dark:border-slate-800">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
                {editingExpense ? `${t('edit')} ${editingExpense.expense_code}` : t('addExpense')}
              </h3>
              <button type="button" onClick={() => setModalOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block font-medium mb-1">{t('expenseTitle')}</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Shop Rent / Utility Bill..."
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium mb-1">{t('date')}</label>
                <input
                  type="date"
                  required
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('category')}</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="block font-medium mb-1">{t('description')}</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium mb-1">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  min={0.01}
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('currency')}</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code}>{c.code}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium mb-1">{t('paymentMethod')}</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="Cash">{t('cash')}</option>
                  <option value="Card">{t('cardPayment')}</option>
                  <option value="Bank Transfer">{t('bankTransfer')}</option>
                  <option value="Mobile Money">{t('mobileMoney')}</option>
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">Receipt Ref #</label>
                <input
                  type="text"
                  value={receiptRef}
                  onChange={(e) => setReceiptRef(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
            </div>
            <div>
              <label className="block font-medium mb-1">{t('attachment')}</label>
              <div className="flex items-center gap-2">
                <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 shrink-0">
                  <Upload className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span>{t('chooseFile')}</span>
                  <input type="file" accept="image/*,.pdf" onChange={handleAttachmentUpload} className="hidden" />
                </label>
                <input
                  type="text"
                  value={attachmentUrl}
                  onChange={(e) => setAttachmentUrl(e.target.value)}
                  placeholder="https://... or uploaded file"
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add/Edit Expense Category Modal */}
      {catModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={saveCategory} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-3 text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">{editingCat ? `${t('edit')} Category` : 'Add Expense Category'}</h3>
              <button type="button" onClick={() => setCatModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div>
              <label className="block font-medium mb-1">Category Name</label>
              <input
                type="text"
                required
                value={catName}
                onChange={(e) => setCatName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
              />
            </div>
            <div>
              <label className="block font-medium mb-1">{t('description')}</label>
              <input
                type="text"
                value={catDesc}
                onChange={(e) => setCatDesc(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setCatModalOpen(false)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700">{t('cancel')}</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold">{t('save')}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
