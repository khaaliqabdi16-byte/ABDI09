import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Plus, Search, Upload, Download, Edit2, Trash2, Package, Eye, X } from 'lucide-react';
import * as XLSX from 'xlsx';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { exportExcel, formatMoney } from '../utils/export.ts';
import { Category, Product, UnitItem, VatRateItem, Warehouse } from '../types/erp.ts';

type CatalogTab = 'products' | 'categories' | 'units' | 'vat';

export function CatalogPage() {
  const { t, hasPermission, showToast, activeSubTab, setActiveSubTab } = useApp();
  const [tab, setTab] = useState<CatalogTab>(() =>
    activeSubTab === 'categories' || activeSubTab === 'units' || activeSubTab === 'vat' ? activeSubTab : 'products'
  );

  useEffect(() => {
    if (activeSubTab === 'products' || activeSubTab === 'categories' || activeSubTab === 'units' || activeSubTab === 'vat') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const switchTab = (next: CatalogTab) => {
    setTab(next);
    setActiveSubTab(next);
  };

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [units, setUnits] = useState<UnitItem[]>([]);
  const [vatRates, setVatRates] = useState<VatRateItem[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [search, setSearch] = useState('');

  const [prodModalOpen, setProdModalOpen] = useState(false);
  const [viewProd, setViewProd] = useState<Product | null>(null);
  const [editingProd, setEditingProd] = useState<Product | null>(null);
  const [form, setForm] = useState({
    name: '',
    product_code: '',
    sku: '',
    barcode: '',
    category_id: '',
    unit: 'PC',
    purchase_price: '0',
    selling_price: '0',
    wholesale_price: '0',
    vat_rate: '15',
    current_stock: '0',
    min_stock: '5',
    warehouse_id: '1',
    expiry_date: '',
    image_url: '',
    description: '',
    is_active: true,
  });

  // Categories form state (Add & Edit)
  const [editingCatId, setEditingCatId] = useState<number | null>(null);
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');

  // Units form state (Add & Edit)
  const [editingUnitId, setEditingUnitId] = useState<number | null>(null);
  const [unitName, setUnitName] = useState('');
  const [unitShort, setUnitShort] = useState('');
  const [unitDesc, setUnitDesc] = useState('');

  // VAT form state (Add & Edit)
  const [editingVatId, setEditingVatId] = useState<number | null>(null);
  const [vatName, setVatName] = useState('');
  const [vatPct, setVatPct] = useState('15');
  const [vatType, setVatType] = useState('Standard');
  const [vatDefault, setVatDefault] = useState(false);

  const fileImportRef = useRef<HTMLInputElement>(null);

  const loadData = useCallback(async () => {
    try {
      const [pRes, cRes, uRes, vRes, wRes] = await Promise.all([
        apiFetch<{ products: Product[] }>(`/api/products?q=${encodeURIComponent(search)}`),
        apiFetch<{ categories: Category[] }>('/api/categories'),
        apiFetch<{ units: UnitItem[] }>('/api/units'),
        apiFetch<{ vatRates: VatRateItem[] }>('/api/vat-rates'),
        apiFetch<{ warehouses: Warehouse[] }>('/api/warehouses'),
      ]);
      setProducts(pRes.products);
      setCategories(cRes.categories);
      setUnits(uRes.units);
      setVatRates(vRes.vatRates);
      setWarehouses(wRes.warehouses);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load catalog', 'error');
    }
  }, [search, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const defaultVatPct = vatRates.find((v) => v.is_default === 1)?.percentage ?? 15;

  const openNewProduct = () => {
    const skuCode = `SKU-${Date.now().toString().slice(-5)}`;
    setEditingProd(null);
    setForm({
      name: '',
      product_code: `PRD-${Date.now().toString().slice(-5)}`,
      sku: skuCode,
      barcode: `${Date.now().toString().slice(-12)}`,
      category_id: categories[0] ? String(categories[0].id) : '',
      unit: units[0]?.short_name || 'PC',
      purchase_price: '0',
      selling_price: '0',
      wholesale_price: '0',
      vat_rate: String(defaultVatPct),
      current_stock: '0',
      min_stock: '5',
      warehouse_id: warehouses[0] ? String(warehouses[0].id) : '1',
      expiry_date: '',
      image_url: '',
      description: '',
      is_active: true,
    });
    setProdModalOpen(true);
  };

  const openEditProduct = (p: Product) => {
    setEditingProd(p);
    setForm({
      name: p.name,
      product_code: p.product_code || p.sku,
      sku: p.sku,
      barcode: p.barcode,
      category_id: p.category_id ? String(p.category_id) : '',
      unit: p.unit,
      purchase_price: String(p.purchase_price),
      selling_price: String(p.selling_price),
      wholesale_price: String(p.wholesale_price),
      vat_rate: String(p.vat_rate),
      current_stock: String(p.current_stock),
      min_stock: String(p.min_stock),
      warehouse_id: String(p.warehouse_id || 1),
      expiry_date: p.expiry_date || '',
      image_url: p.image_url || '',
      description: p.description || '',
      is_active: p.is_active === 1,
    });
    setProdModalOpen(true);
  };

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setForm((prev) => ({ ...prev, image_url: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...form,
        category_id: form.category_id ? Number(form.category_id) : null,
        purchase_price: Number(form.purchase_price),
        selling_price: Number(form.selling_price),
        wholesale_price: Number(form.wholesale_price),
        vat_rate: Number(form.vat_rate),
        current_stock: Number(form.current_stock),
        min_stock: Number(form.min_stock),
        warehouse_id: Number(form.warehouse_id || 1),
      };
      if (editingProd) {
        await apiFetch(`/api/products/${editingProd.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('Product updated', 'success');
      } else {
        await apiFetch('/api/products', { method: 'POST', body: JSON.stringify(payload) });
        showToast('Product created', 'success');
      }
      setProdModalOpen(false);
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to save product', 'error');
    }
  };

  const deleteProduct = async (id: number) => {
    try {
      await apiFetch(`/api/products/${id}`, { method: 'DELETE' });
      showToast('Product removed/deactivated', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to delete product', 'error');
    }
  };

  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const wb = XLSX.read(ev.target?.result, { type: 'binary' });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet);
        const res = await apiFetch<{ imported: number }>('/api/products/import', {
          method: 'POST',
          body: JSON.stringify({ rows }),
        });
        showToast(`Imported ${res.imported} product(s)`, 'success');
        await loadData();
      } catch (err: unknown) {
        showToast(err instanceof Error ? err.message : 'Import failed', 'error');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  const saveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim()) return;
    try {
      if (editingCatId) {
        await apiFetch(`/api/categories/${editingCatId}`, {
          method: 'PUT',
          body: JSON.stringify({ name: catName, description: catDesc }),
        });
        showToast('Category updated', 'success');
      } else {
        await apiFetch('/api/categories', {
          method: 'POST',
          body: JSON.stringify({ name: catName, description: catDesc }),
        });
        showToast('Category added', 'success');
      }
      setEditingCatId(null);
      setCatName('');
      setCatDesc('');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save category', 'error');
    }
  };

  const deleteCategory = async (id: number) => {
    try {
      await apiFetch(`/api/categories/${id}`, { method: 'DELETE' });
      showToast('Category deleted', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to delete category', 'error');
    }
  };

  const saveUnit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitName.trim() || !unitShort.trim()) return;
    try {
      if (editingUnitId) {
        await apiFetch(`/api/units/${editingUnitId}`, {
          method: 'PUT',
          body: JSON.stringify({ unit_name: unitName, short_name: unitShort, description: unitDesc }),
        });
        showToast('Unit updated', 'success');
      } else {
        await apiFetch('/api/units', {
          method: 'POST',
          body: JSON.stringify({ unit_name: unitName, short_name: unitShort, description: unitDesc }),
        });
        showToast('Unit added', 'success');
      }
      setEditingUnitId(null);
      setUnitName('');
      setUnitShort('');
      setUnitDesc('');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save unit', 'error');
    }
  };

  const deleteUnit = async (id: number) => {
    try {
      await apiFetch(`/api/units/${id}`, { method: 'DELETE' });
      showToast('Unit deleted', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to delete unit', 'error');
    }
  };

  const saveVat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vatName.trim()) return;
    try {
      if (editingVatId) {
        await apiFetch(`/api/vat-rates/${editingVatId}`, {
          method: 'PUT',
          body: JSON.stringify({
            name: vatName,
            percentage: Number(vatPct),
            vat_type: vatType,
            is_default: vatDefault,
          }),
        });
        showToast('VAT rate updated', 'success');
      } else {
        await apiFetch('/api/vat-rates', {
          method: 'POST',
          body: JSON.stringify({
            name: vatName,
            percentage: Number(vatPct),
            vat_type: vatType,
            is_default: vatDefault,
          }),
        });
        showToast('VAT rate added', 'success');
      }
      setEditingVatId(null);
      setVatName('');
      setVatPct('15');
      setVatType('Standard');
      setVatDefault(false);
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save VAT rate', 'error');
    }
  };

  const deleteVat = async (id: number) => {
    try {
      await apiFetch(`/api/vat-rates/${id}`, { method: 'DELETE' });
      showToast('VAT rate deleted', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to delete VAT rate', 'error');
    }
  };

  return (
    <div className="space-y-5">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 erp-card flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => switchTab('products')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'products' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('products')} ({products.length})
          </button>
          <button
            onClick={() => switchTab('categories')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'categories' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('categories')} ({categories.length})
          </button>
          <button
            onClick={() => switchTab('units')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'units' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('units')} ({units.length})
          </button>
          <button
            onClick={() => switchTab('vat')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'vat' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('vatRates')} ({vatRates.length})
          </button>
        </div>

        {tab === 'products' && (
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name, code, SKU, barcode..."
                className="pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs w-60"
              />
            </div>

            <button
              onClick={() =>
                exportExcel(
                  'qabdiid_products',
                  products.map((p) => ({
                    product_code: p.product_code || p.sku,
                    name: p.name,
                    sku: p.sku,
                    barcode: p.barcode,
                    category: p.category_name || '',
                    unit: p.unit,
                    purchase_price: p.purchase_price,
                    selling_price: p.selling_price,
                    wholesale_price: p.wholesale_price,
                    vat_rate: p.vat_rate,
                    current_stock: p.current_stock,
                    min_stock: p.min_stock,
                  }))
                )
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <Download className="w-3.5 h-3.5" />
              {t('exportExcel')}
            </button>

            {hasPermission('catalog.manage') && (
              <>
                <input ref={fileImportRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleExcelImport} className="hidden" />
                <button
                  onClick={() => fileImportRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <Upload className="w-3.5 h-3.5" />
                  {t('importProducts')}
                </button>
                <button
                  onClick={openNewProduct}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  {t('addProduct')}
                </button>
              </>
            )}
          </div>
        )}
      </div>

      {/* Products Table */}
      {tab === 'products' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Product</th>
                  <th className="text-left px-4 py-3 font-medium">Code / {t('sku')} / {t('barcode')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('category')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('unit')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('purchasePrice')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('sellingPrice')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('vat')} %</th>
                  <th className="text-right px-4 py-3 font-medium">{t('currentStock')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {products.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-10 text-center text-slate-500">
                      {t('noRecords')}
                    </td>
                  </tr>
                ) : (
                  products.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 overflow-hidden flex items-center justify-center shrink-0">
                            {p.image_url ? (
                              <img src={p.image_url} alt={p.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                            ) : (
                              <Package className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900 dark:text-slate-100">{p.name}</div>
                            <div className="text-[11px] text-slate-500">ID #{p.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono-num">
                        <div className="font-semibold text-[#2563EB] dark:text-[#06B6D4]">{p.product_code || p.sku}</div>
                        <div className="text-[11px] text-slate-500">{p.sku} · {p.barcode}</div>
                      </td>
                      <td className="px-4 py-3">{p.category_name || '-'}</td>
                      <td className="px-4 py-3 font-mono-num">{p.unit}</td>
                      <td className="px-4 py-3 text-right font-mono-num">{formatMoney(p.purchase_price, 'ETB')}</td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold">{formatMoney(p.selling_price, 'ETB')}</td>
                      <td className="px-4 py-3 text-right font-mono-num">{p.vat_rate}%</td>
                      <td className={`px-4 py-3 text-right font-mono-num font-semibold ${p.current_stock <= p.min_stock ? 'text-red-600' : ''}`}>
                        {p.current_stock} {p.unit}
                      </td>
                      <td className="px-4 py-3">
                        <span className={p.is_active ? 'text-emerald-700 dark:text-emerald-400 font-medium' : 'text-slate-400'}>
                          {p.is_active ? t('active') : t('inactive')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => setViewProd(p)}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                            title={t('viewDetails')}
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {hasPermission('catalog.manage') && (
                            <>
                              <button
                                onClick={() => openEditProduct(p)}
                                className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => deleteProduct(p.id)}
                                className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Categories Tab */}
      {tab === 'categories' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {hasPermission('catalog.manage') && (
            <form
              onSubmit={saveCategory}
              className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card space-y-3 h-fit"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm">{editingCatId ? 'Edit Category' : 'Add Category'}</h3>
                {editingCatId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingCatId(null);
                      setCatName('');
                      setCatDesc('');
                    }}
                    className="text-xs text-slate-500 hover:underline"
                  >
                    {t('cancel')}
                  </button>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Category Name</label>
                <input
                  type="text"
                  required
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">{t('description')}</label>
                <input
                  type="text"
                  value={catDesc}
                  onChange={(e) => setCatDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm"
                />
              </div>
              <button type="submit" className="w-full py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </form>
          )}

          <div className="lg:col-span-2 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="text-left px-4 py-3 font-medium">Name</th>
                  <th className="text-left px-4 py-3 font-medium">{t('description')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {categories.map((c) => (
                  <tr key={c.id}>
                    <td className="px-4 py-3 font-semibold">{c.name}</td>
                    <td className="px-4 py-3 text-slate-500">{c.description}</td>
                    <td className="px-4 py-3 text-right">
                      {hasPermission('catalog.manage') && (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              setEditingCatId(c.id);
                              setCatName(c.name);
                              setCatDesc(c.description || '');
                            }}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => deleteCategory(c.id)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Units Tab */}
      {tab === 'units' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {hasPermission('catalog.manage') && (
            <form
              onSubmit={saveUnit}
              className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card space-y-3 h-fit"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm">{editingUnitId ? 'Edit Unit' : 'Add Unit'}</h3>
                {editingUnitId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingUnitId(null);
                      setUnitName('');
                      setUnitShort('');
                      setUnitDesc('');
                    }}
                    className="text-xs text-slate-500 hover:underline"
                  >
                    {t('cancel')}
                  </button>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Unit Name</label>
                <input
                  type="text"
                  required
                  placeholder="Piece, Box, Carton, Kg..."
                  value={unitName}
                  onChange={(e) => setUnitName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Short Name</label>
                <input
                  type="text"
                  required
                  placeholder="PC, Box, KG, L, M..."
                  value={unitShort}
                  onChange={(e) => setUnitShort(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm font-mono-num"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">{t('description')}</label>
                <input
                  type="text"
                  value={unitDesc}
                  onChange={(e) => setUnitDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm"
                />
              </div>
              <button type="submit" className="w-full py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </form>
          )}

          <div className="lg:col-span-2 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="text-left px-4 py-3 font-medium">Unit Name</th>
                  <th className="text-left px-4 py-3 font-medium">Short Name</th>
                  <th className="text-left px-4 py-3 font-medium">{t('description')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {units.map((u) => (
                  <tr key={u.id}>
                    <td className="px-4 py-3 font-semibold">{u.unit_name}</td>
                    <td className="px-4 py-3 font-mono-num font-semibold text-[#2563EB] dark:text-[#06B6D4]">{u.short_name}</td>
                    <td className="px-4 py-3 text-slate-500">{u.description}</td>
                    <td className="px-4 py-3 text-right">
                      {hasPermission('catalog.manage') && (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              setEditingUnitId(u.id);
                              setUnitName(u.unit_name);
                              setUnitShort(u.short_name);
                              setUnitDesc(u.description || '');
                            }}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => deleteUnit(u.id)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VAT Tab */}
      {tab === 'vat' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {hasPermission('catalog.manage') && (
            <form
              onSubmit={saveVat}
              className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card space-y-3 h-fit"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm">{editingVatId ? 'Edit VAT Rate' : 'Add VAT Rate'}</h3>
                {editingVatId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingVatId(null);
                      setVatName('');
                      setVatPct('15');
                      setVatType('Standard');
                      setVatDefault(false);
                    }}
                    className="text-xs text-slate-500 hover:underline"
                  >
                    {t('cancel')}
                  </button>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">VAT Name</label>
                <input
                  type="text"
                  required
                  placeholder="Standard VAT 15%"
                  value={vatName}
                  onChange={(e) => setVatName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium mb-1">VAT Percentage (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    min={0}
                    max={100}
                    required
                    value={vatPct}
                    onChange={(e) => setVatPct(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">VAT Type</label>
                  <select
                    value={vatType}
                    onChange={(e) => setVatType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm"
                  >
                    <option value="Standard">Standard</option>
                    <option value="Zero Rated">Zero Rated</option>
                    <option value="Exempt">Exempt</option>
                    <option value="Inclusive">Inclusive</option>
                  </select>
                </div>
              </div>
              <label className="inline-flex items-center gap-2 text-xs">
                <input type="checkbox" checked={vatDefault} onChange={(e) => setVatDefault(e.target.checked)} className="accent-[#2563EB]" />
                <span>Set as Default VAT Rate for Sales & Purchases</span>
              </label>
              <button type="submit" className="w-full py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </form>
          )}

          <div className="lg:col-span-2 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="text-left px-4 py-3 font-medium">VAT Name</th>
                  <th className="text-right px-4 py-3 font-medium">Percentage</th>
                  <th className="text-left px-4 py-3 font-medium">VAT Type</th>
                  <th className="text-left px-4 py-3 font-medium">Default</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {vatRates.map((v) => (
                  <tr key={v.id}>
                    <td className="px-4 py-3 font-semibold">{v.name}</td>
                    <td className="px-4 py-3 text-right font-mono-num font-bold text-[#2563EB] dark:text-[#06B6D4]">{v.percentage}%</td>
                    <td className="px-4 py-3">{v.vat_type}</td>
                    <td className="px-4 py-3">{v.is_default ? 'Yes' : 'No'}</td>
                    <td className="px-4 py-3 text-right">
                      {hasPermission('catalog.manage') && (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              setEditingVatId(v.id);
                              setVatName(v.name);
                              setVatPct(String(v.percentage));
                              setVatType(v.vat_type);
                              setVatDefault(v.is_default === 1);
                            }}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => deleteVat(v.id)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Product Modal */}
      {prodModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form
            onSubmit={saveProduct}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-2xl p-5 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">{editingProd ? t('editProduct') : t('addProduct')}</h3>
              <button type="button" onClick={() => setProdModalOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-medium mb-1">Product Name</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('productCode')}</label>
                <input
                  type="text"
                  value={form.product_code}
                  onChange={(e) => setForm({ ...form, product_code: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('sku')}</label>
                <input
                  type="text"
                  required
                  value={form.sku}
                  onChange={(e) => setForm({ ...form, sku: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('barcode')}</label>
                <input
                  type="text"
                  value={form.barcode}
                  onChange={(e) => setForm({ ...form, barcode: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('category')}</label>
                <select
                  value={form.category_id}
                  onChange={(e) => setForm({ ...form, category_id: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="">Uncategorized</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">{t('unit')}</label>
                <select
                  value={form.unit}
                  onChange={(e) => setForm({ ...form, unit: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  {units.map((u) => (
                    <option key={u.id} value={u.short_name}>
                      {u.unit_name} ({u.short_name})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">{t('purchasePrice')} (ETB)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={form.purchase_price}
                  onChange={(e) => setForm({ ...form, purchase_price: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('sellingPrice')} (ETB)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={form.selling_price}
                  onChange={(e) => setForm({ ...form, selling_price: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('wholesalePrice')} (ETB)</label>
                <input
                  type="number"
                  step="0.01"
                  value={form.wholesale_price}
                  onChange={(e) => setForm({ ...form, wholesale_price: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('vat')} (%)</label>
                <select
                  value={form.vat_rate}
                  onChange={(e) => setForm({ ...form, vat_rate: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono-num"
                >
                  {vatRates.map((v) => (
                    <option key={v.id} value={String(v.percentage)}>
                      {v.name} ({v.percentage}%)
                    </option>
                  ))}
                  {!vatRates.some((v) => String(v.percentage) === String(form.vat_rate)) && (
                    <option value={form.vat_rate}>{form.vat_rate}%</option>
                  )}
                </select>
              </div>
              {!editingProd && (
                <div>
                  <label className="block font-medium mb-1">Opening Stock</label>
                  <input
                    type="number"
                    step="0.01"
                    value={form.current_stock}
                    onChange={(e) => setForm({ ...form, current_stock: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                  />
                </div>
              )}
              <div>
                <label className="block font-medium mb-1">{t('minStock')}</label>
                <input
                  type="number"
                  step="0.01"
                  value={form.min_stock}
                  onChange={(e) => setForm({ ...form, min_stock: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('expiryDate')}</label>
                <input
                  type="date"
                  value={form.expiry_date}
                  onChange={(e) => setForm({ ...form, expiry_date: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block font-medium mb-1">Product Image Upload</label>
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 overflow-hidden flex items-center justify-center shrink-0">
                    {form.image_url ? (
                      <img src={form.image_url} alt={form.name || 'Product'} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    ) : (
                      <Package className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        try {
                          const { compressImageFile } = await import('../utils/image.ts');
                          const dataUrl = await compressImageFile(file, 640, 0.82);
                          setForm((prev) => ({ ...prev, image_url: dataUrl }));
                        } catch {
                          handleImageFile(e);
                        }
                      }}
                      className="w-full text-xs"
                    />
                    <input
                      type="text"
                      placeholder="Or paste image URL..."
                      value={form.image_url}
                      onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                      className="w-full px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 bg-transparent text-xs"
                    />
                  </div>
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="block font-medium mb-1">{t('description')}</label>
                <input
                  type="text"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
              <label className="inline-flex items-center gap-2 sm:col-span-2">
                <input
                  type="checkbox"
                  checked={form.is_active}
                  onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
                />
                <span>{t('active')}</span>
              </label>
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setProdModalOpen(false)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Product Details View Modal */}
      {viewProd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-lg p-5 space-y-4 text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0] dark:border-slate-800">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">{viewProd.name}</h3>
              <button onClick={() => setViewProd(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-24 h-24 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 overflow-hidden flex items-center justify-center shrink-0">
                {viewProd.image_url ? (
                  <img src={viewProd.image_url} alt={viewProd.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  <Package className="w-8 h-8 text-slate-400" />
                )}
              </div>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 flex-1">
                <div><span className="text-slate-500">Product Code:</span> <strong className="font-mono-num">{viewProd.product_code || viewProd.sku}</strong></div>
                <div><span className="text-slate-500">SKU:</span> <strong className="font-mono-num">{viewProd.sku}</strong></div>
                <div><span className="text-slate-500">Barcode:</span> <strong className="font-mono-num">{viewProd.barcode}</strong></div>
                <div><span className="text-slate-500">Category:</span> <strong>{viewProd.category_name || '-'}</strong></div>
                <div><span className="text-slate-500">Unit:</span> <strong>{viewProd.unit}</strong></div>
                <div><span className="text-slate-500">VAT:</span> <strong>{viewProd.vat_rate}%</strong></div>
                <div><span className="text-slate-500">Purchase Price:</span> <strong className="font-mono-num">{formatMoney(viewProd.purchase_price, 'ETB')}</strong></div>
                <div><span className="text-slate-500">Selling Price:</span> <strong className="font-mono-num">{formatMoney(viewProd.selling_price, 'ETB')}</strong></div>
                <div><span className="text-slate-500">Current Stock:</span> <strong className="font-mono-num">{viewProd.current_stock} {viewProd.unit}</strong></div>
                <div><span className="text-slate-500">Min Stock:</span> <strong className="font-mono-num">{viewProd.min_stock} {viewProd.unit}</strong></div>
              </div>
            </div>
            {viewProd.description && (
              <div className="p-3 rounded-xl bg-[#F8FAFC] dark:bg-[#111827] text-slate-600 dark:text-slate-300">
                {viewProd.description}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
