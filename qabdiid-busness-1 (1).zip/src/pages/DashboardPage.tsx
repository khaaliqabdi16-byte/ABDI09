import React, { useEffect, useState, useCallback } from 'react';
import {
  Calendar,
  RefreshCw,
  AlertTriangle,
  TrendingUp,
  ShoppingBag,
  Wallet,
  DollarSign,
  Landmark,
  Users,
  Truck,
  Boxes,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { formatMoney } from '../utils/export.ts';
import { DualBarChart, HorizontalDistributionList } from '../components/Charts.tsx';

interface DashboardData {
  range: { start: string; end: string };
  cards: {
    totalSales: number;
    totalPurchases: number;
    totalExpenses: number;
    grossProfit: number;
    netProfit: number;
    customerDebt: number;
    supplierDebt: number;
    inventoryValue: number;
  };
  financials: {
    salesRevenue: number;
    cogs: number;
    grossProfit: number;
    operatingExpenses: number;
    otherIncome: number;
    otherExpenses: number;
    netProfit: number;
    netProfitMargin: number;
  };
  charts: {
    salesByDate: Array<{ date: string; total: number }>;
    purchasesByDate: Array<{ date: string; total: number }>;
    monthlyProfit: Array<{ month: string; revenue: number; profit: number }>;
    categorySales: Array<{ category: string; total: number }>;
  };
  topProducts: Array<{ id: number; name: string; sku: string; unit: string; qty_sold: number; total_revenue: number }>;
  lowStockProducts: Array<{ id: number; name: string; sku: string; current_stock: number; min_stock: number; unit: string; category_name: string }>;
  recentTransactions: Array<{ type: string; ref: string; date: string; grand_total: number; currency: string; status: string; created_at: string }>;
  recentActivities: Array<{ id: number; username: string; action: string; module: string; record_id: string; details: string; created_at: string }>;
}

const DATE_PRESETS = [
  { key: 'today', labelKey: 'today' },
  { key: 'yesterday', labelKey: 'yesterday' },
  { key: '7d', labelKey: 'last7Days' },
  { key: '30d', labelKey: 'last30Days' },
  { key: 'this_month', labelKey: 'thisMonth' },
  { key: 'last_month', labelKey: 'lastMonth' },
  { key: 'this_year', labelKey: 'thisYear' },
  { key: 'custom', labelKey: 'customRange' },
];

export function DashboardPage() {
  const { t, showToast } = useApp();
  const [range, setRange] = useState('this_month');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({ range });
      if (range === 'custom' && customStart && customEnd) {
        qs.set('start', customStart);
        qs.set('end', customEnd);
      }
      const res = await apiFetch<DashboardData>(`/api/dashboard?${qs.toString()}`);
      setData(res);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load dashboard', 'error');
    } finally {
      setLoading(false);
    }
  }, [range, customStart, customEnd, showToast]);

  useEffect(() => {
    if (range !== 'custom' || (customStart && customEnd)) {
      loadDashboard();
    }
  }, [loadDashboard, range, customStart, customEnd]);

  const combinedTrend = React.useMemo(() => {
    if (!data) return [];
    const map = new Map<string, { label: string; primary: number; secondary: number }>();
    for (const s of data.charts.salesByDate) {
      map.set(s.date, { label: s.date.slice(5), primary: s.total, secondary: 0 });
    }
    for (const p of data.charts.purchasesByDate) {
      const existing = map.get(p.date);
      if (existing) existing.secondary = p.total;
      else map.set(p.date, { label: p.date.slice(5), primary: 0, secondary: p.total });
    }
    return Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([, val]) => val);
  }, [data]);

  const cards = data
    ? [
        {
          label: t('totalSales'),
          val: formatMoney(data.cards.totalSales, 'ETB'),
          tone: 'text-[#2563EB] dark:text-[#06B6D4]',
          icon: TrendingUp,
          iconBg: 'bg-[#2563EB]/10 text-[#2563EB] dark:bg-[#2563EB]/20 dark:text-[#06B6D4]',
        },
        {
          label: t('totalPurchases'),
          val: formatMoney(data.cards.totalPurchases, 'ETB'),
          tone: 'text-[#0B1F4D] dark:text-[#F8FAFC]',
          icon: ShoppingBag,
          iconBg: 'bg-[#0B1F4D]/10 text-[#0B1F4D] dark:bg-white/10 dark:text-[#F8FAFC]',
        },
        {
          label: t('totalExpenses'),
          val: formatMoney(data.cards.totalExpenses, 'ETB'),
          tone: 'text-amber-700 dark:text-amber-400',
          icon: Wallet,
          iconBg: 'bg-amber-500/10 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400',
        },
        {
          label: t('grossProfit'),
          val: formatMoney(data.cards.grossProfit, 'ETB'),
          tone: data.cards.grossProfit >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-600',
          icon: DollarSign,
          iconBg: 'bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400',
        },
        {
          label: t('netProfit'),
          val: formatMoney(data.cards.netProfit, 'ETB'),
          tone: data.cards.netProfit >= 0 ? 'text-[#2563EB] dark:text-[#06B6D4]' : 'text-red-600',
          icon: Landmark,
          iconBg: 'bg-[#06B6D4]/15 text-[#0891B2] dark:bg-[#06B6D4]/20 dark:text-[#06B6D4]',
        },
        {
          label: t('customerDebt'),
          val: formatMoney(data.cards.customerDebt, 'ETB'),
          tone: 'text-amber-700 dark:text-amber-400',
          icon: Users,
          iconBg: 'bg-amber-500/10 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400',
        },
        {
          label: t('supplierDebt'),
          val: formatMoney(data.cards.supplierDebt, 'ETB'),
          tone: 'text-[#0B1F4D] dark:text-[#F8FAFC]',
          icon: Truck,
          iconBg: 'bg-[#0B1F4D]/10 text-[#0B1F4D] dark:bg-white/10 dark:text-[#F8FAFC]',
        },
        {
          label: t('inventoryValue'),
          val: formatMoney(data.cards.inventoryValue, 'ETB'),
          tone: 'text-[#0B1F4D] dark:text-[#06B6D4]',
          icon: Boxes,
          iconBg: 'bg-[#2563EB]/10 text-[#2563EB] dark:bg-[#06B6D4]/20 dark:text-[#06B6D4]',
        },
      ]
    : [];

  return (
    <div className="space-y-6">
      {/* Date Filter Bar */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 erp-card flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {DATE_PRESETS.map((p) => (
            <button
              key={p.key}
              onClick={() => setRange(p.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 ${
                range === p.key
                  ? 'bg-[#2563EB] text-white shadow-[0_2px_8px_rgba(37,99,235,0.3)]'
                  : 'bg-[#F8FAFC] dark:bg-[#111827] text-[#111827] dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/50'
              }`}
            >
              {t(p.labelKey)}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {range === 'custom' && (
            <>
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-xs font-mono-num"
              />
              <span className="text-xs text-slate-400">–</span>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-xs font-mono-num"
              />
            </>
          )}
          {data && (
            <span className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono-num">
              <Calendar className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />
              {data.range.start} / {data.range.end}
            </span>
          )}
          <button
            onClick={loadDashboard}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-xs font-medium text-[#0B1F4D] dark:text-[#F8FAFC] hover:border-[#2563EB] whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4] ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* 8 Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {loading && !data
          ? Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-24 rounded-2xl bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 animate-pulse p-5" />
            ))
          : cards.map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.label}
                  className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card hover:border-[#2563EB]/40 dark:hover:border-[#06B6D4]/40 transition-all flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-slate-500 dark:text-slate-400">{card.label}</span>
                    <span className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${card.iconBg}`}>
                      <Icon className="w-4 h-4" />
                    </span>
                  </div>
                  <span className={`text-xl font-bold font-mono-num mt-2.5 ${card.tone}`}>{card.val}</span>
                </div>
              );
            })}
      </div>

      {/* Financial Performance & Sales/Purchases Trend */}
      {data && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('financialSummary')}
            </h2>
            <div className="divide-y divide-[#E2E8F0] dark:divide-slate-800 text-sm">
              {[
                { label: t('salesRevenue'), value: formatMoney(data.financials.salesRevenue, 'ETB') },
                { label: t('cogs'), value: formatMoney(data.financials.cogs, 'ETB') },
                { label: t('grossProfit'), value: formatMoney(data.financials.grossProfit, 'ETB'), bold: true },
                { label: t('operatingExpenses'), value: formatMoney(data.financials.operatingExpenses, 'ETB') },
                { label: t('otherIncome'), value: formatMoney(data.financials.otherIncome, 'ETB') },
                { label: t('otherExpenses'), value: formatMoney(data.financials.otherExpenses, 'ETB') },
                { label: t('netProfit'), value: formatMoney(data.financials.netProfit, 'ETB'), bold: true, accent: true },
                { label: t('netProfitMargin'), value: `${data.financials.netProfitMargin.toFixed(2)}%`, bold: true },
              ].map((row) => (
                <div key={row.label} className="py-2.5 flex items-center justify-between gap-2">
                  <span className={`${row.bold ? 'font-semibold text-[#0B1F4D] dark:text-[#F8FAFC]' : 'text-slate-600 dark:text-slate-400'}`}>
                    {row.label}
                  </span>
                  <span
                    className={`font-mono-num ${
                      row.accent
                        ? data.financials.netProfit >= 0
                          ? 'text-[#2563EB] dark:text-[#06B6D4] font-bold'
                          : 'text-red-600 font-bold'
                        : row.bold
                        ? 'font-semibold text-[#0B1F4D] dark:text-[#F8FAFC]'
                        : 'text-[#111827] dark:text-slate-200'
                    }`}
                  >
                    {row.value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="xl:col-span-2 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('salesTrend')}
            </h2>
            <DualBarChart
              data={combinedTrend}
              primaryLabel={t('totalSales')}
              secondaryLabel={t('totalPurchases')}
              emptyText={t('noRecords')}
            />
          </div>
        </div>
      )}

      {/* Monthly Profit & Category Sales */}
      {data && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('monthlyProfit')}
            </h2>
            <DualBarChart
              data={data.charts.monthlyProfit.map((m) => ({
                label: m.month.slice(5),
                primary: m.revenue,
                secondary: Math.max(0, m.profit),
              }))}
              primaryLabel={t('salesRevenue')}
              secondaryLabel={t('netProfit')}
              emptyText={t('noRecords')}
            />
          </div>

          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('salesByCategory')}
            </h2>
            <HorizontalDistributionList
              items={data.charts.categorySales.map((c) => ({ label: c.category, value: c.total }))}
              emptyText={t('noRecords')}
            />
          </div>
        </div>
      )}

      {/* Top Selling Products & Low Stock Alerts */}
      {data && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('topSellingProducts')}
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left pb-2 font-medium">Product</th>
                    <th className="text-right pb-2 font-medium">{t('quantity')}</th>
                    <th className="text-right pb-2 font-medium">{t('total')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E2E8F0]/70 dark:divide-slate-800">
                  {data.topProducts.length === 0 ? (
                    <tr>
                      <td colSpan={3} className="py-6 text-center text-slate-500">
                        {t('noRecords')}
                      </td>
                    </tr>
                  ) : (
                    data.topProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-[#F8FAFC] dark:hover:bg-white/5">
                        <td className="py-2.5 pr-2">
                          <div className="font-medium text-[#111827] dark:text-slate-100">{p.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono-num">{p.sku}</div>
                        </td>
                        <td className="py-2.5 text-right font-mono-num">
                          {p.qty_sold} {p.unit}
                        </td>
                        <td className="py-2.5 text-right font-mono-num font-semibold text-[#2563EB] dark:text-[#06B6D4]">
                          {formatMoney(p.total_revenue, 'ETB')}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('lowStockAlerts')}
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left pb-2 font-medium">Product</th>
                    <th className="text-right pb-2 font-medium">{t('currentStock')}</th>
                    <th className="text-right pb-2 font-medium">{t('minStock')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E2E8F0]/70 dark:divide-slate-800">
                  {data.lowStockProducts.length === 0 ? (
                    <tr>
                      <td colSpan={3} className="py-6 text-center text-slate-500">
                        All stock levels are healthy
                      </td>
                    </tr>
                  ) : (
                    data.lowStockProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-[#F8FAFC] dark:hover:bg-white/5">
                        <td className="py-2.5 pr-2">
                          <div className="font-medium text-[#111827] dark:text-slate-100">{p.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono-num">
                            {p.sku} · {p.category_name || '-'}
                          </div>
                        </td>
                        <td className="py-2.5 text-right font-mono-num text-red-600 dark:text-red-400 font-semibold">
                          <span className="inline-flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            {p.current_stock} {p.unit}
                          </span>
                        </td>
                        <td className="py-2.5 text-right font-mono-num text-slate-500">
                          {p.min_stock} {p.unit}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Recent Transactions & Recent Activities */}
      {data && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('recentTransactions')}
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left pb-2 font-medium">Reference</th>
                    <th className="text-left pb-2 font-medium">{t('date')}</th>
                    <th className="text-left pb-2 font-medium">{t('status')}</th>
                    <th className="text-right pb-2 font-medium">{t('total')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E2E8F0]/70 dark:divide-slate-800">
                  {data.recentTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-6 text-center text-slate-500">
                        {t('noRecords')}
                      </td>
                    </tr>
                  ) : (
                    data.recentTransactions.map((tx, idx) => (
                      <tr key={tx.ref + idx} className="hover:bg-[#F8FAFC] dark:hover:bg-white/5">
                        <td className="py-2.5">
                          <div className="font-mono-num font-medium text-[#0B1F4D] dark:text-[#F8FAFC]">{tx.ref}</div>
                          <div className="text-[11px] text-slate-500">{tx.type}</div>
                        </td>
                        <td className="py-2.5 font-mono-num text-slate-500">{tx.date}</td>
                        <td className="py-2.5 text-slate-700 dark:text-slate-300">{tx.status}</td>
                        <td className="py-2.5 text-right font-mono-num font-semibold text-[#111827] dark:text-[#06B6D4]">
                          {formatMoney(tx.grand_total, tx.currency)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC] mb-4">
              {t('recentActivities')}
            </h2>
            <div className="divide-y divide-[#E2E8F0]/70 dark:divide-slate-800 text-xs">
              {data.recentActivities.length === 0 ? (
                <div className="py-6 text-center text-slate-500">{t('noRecords')}</div>
              ) : (
                data.recentActivities.map((act) => (
                  <div key={act.id} className="py-2.5 flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold text-[#0B1F4D] dark:text-slate-100">
                        {act.username} · {act.module} ({act.action})
                      </div>
                      <div className="text-slate-500 dark:text-slate-400">{act.details}</div>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono-num shrink-0">{act.created_at.slice(5)}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
