import React, { useEffect, useState, useCallback } from 'react';
import { Plus, Edit2, Trash2, CheckCircle2, ArrowRightLeft, Coins, X } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { formatMoney } from '../utils/export.ts';
import { Currency } from '../types/erp.ts';

interface RateHistoryRow {
  id: number;
  currency_code: string;
  rate_to_etb: number;
  changed_by: string;
  changed_at: string;
}

export function CurrenciesPage() {
  const { t, refreshSettings, showToast } = useApp();
  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [history, setHistory] = useState<RateHistoryRow[]>([]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingCode, setEditingCode] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('');
  const [rate, setRate] = useState('1');
  const [decimalPlaces, setDecimalPlaces] = useState('2');
  const [isDefault, setIsDefault] = useState(false);

  // Currency Converter Calculator
  const [convAmount, setConvAmount] = useState('100');
  const [convFrom, setConvFrom] = useState('USD');
  const [convTo, setConvTo] = useState('ETB');

  const loadData = useCallback(async () => {
    try {
      const res = await apiFetch<{ currencies: Currency[]; history: RateHistoryRow[] }>('/api/currencies');
      setCurrencies(res.currencies);
      setHistory(res.history);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load currencies', 'error');
    }
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openCreate = () => {
    setEditingCode(null);
    setCode('');
    setName('');
    setSymbol('');
    setRate('1');
    setDecimalPlaces('2');
    setIsDefault(false);
    setModalOpen(true);
  };

  const openEdit = (c: Currency) => {
    setEditingCode(c.code);
    setCode(c.code);
    setName(c.name);
    setSymbol(c.symbol);
    setRate(String(c.exchange_rate_to_etb));
    setDecimalPlaces(String(c.decimal_places ?? 2));
    setIsDefault(c.is_default === 1);
    setModalOpen(true);
  };

  const saveCurrency = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCode) {
        await apiFetch(`/api/currencies/${encodeURIComponent(editingCode)}`, {
          method: 'PUT',
          body: JSON.stringify({
            name,
            symbol,
            exchange_rate_to_etb: Number(rate),
            decimal_places: Number(decimalPlaces),
            is_default: isDefault,
          }),
        });
        showToast(`Currency ${editingCode} updated`, 'success');
      } else {
        await apiFetch('/api/currencies', {
          method: 'POST',
          body: JSON.stringify({
            code: code.toUpperCase(),
            name,
            symbol,
            exchange_rate_to_etb: Number(rate),
            decimal_places: Number(decimalPlaces),
            is_default: isDefault,
          }),
        });
        showToast(`Currency ${code.toUpperCase()} added`, 'success');
      }
      setModalOpen(false);
      await Promise.all([loadData(), refreshSettings()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save currency', 'error');
    }
  };

  const setDefaultCurrency = async (currCode: string) => {
    try {
      await apiFetch(`/api/currencies/${encodeURIComponent(currCode)}/default`, { method: 'PUT' });
      showToast(`Default currency set to ${currCode}`, 'success');
      await Promise.all([loadData(), refreshSettings()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to set default currency', 'error');
    }
  };

  const deleteCurrency = async (currCode: string) => {
    try {
      await apiFetch(`/api/currencies/${encodeURIComponent(currCode)}`, { method: 'DELETE' });
      showToast(`Currency ${currCode} deleted`, 'success');
      await Promise.all([loadData(), refreshSettings()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to delete currency', 'error');
    }
  };

  const fromRate = currencies.find((c) => c.code === convFrom)?.exchange_rate_to_etb || 1;
  const toRate = currencies.find((c) => c.code === convTo)?.exchange_rate_to_etb || 1;
  const toSymbol = currencies.find((c) => c.code === convTo)?.symbol;
  const convertedResult = toRate > 0 ? (Number(convAmount || 0) * fromRate) / toRate : 0;

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 erp-card">
        <div>
          <h2 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC] flex items-center gap-2">
            <Coins className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" />
            {t('currencies')} ({currencies.length})
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Manage store currencies & exchange rates. Historical invoices retain their original recorded exchange rates.
          </p>
        </div>
        <button
          onClick={openCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Currency
        </button>
      </div>

      {/* Currencies Table */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                <th className="text-left px-4 py-3 font-medium">Code</th>
                <th className="text-left px-4 py-3 font-medium">Name</th>
                <th className="text-left px-4 py-3 font-medium">Symbol</th>
                <th className="text-right px-4 py-3 font-medium">Rate to ETB</th>
                <th className="text-right px-4 py-3 font-medium">Decimals</th>
                <th className="text-left px-4 py-3 font-medium">Default</th>
                <th className="text-left px-4 py-3 font-medium">Updated At</th>
                <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {currencies.map((c) => (
                <tr key={c.code} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="px-4 py-3 font-mono-num font-bold text-[#0B1F4D] dark:text-[#F8FAFC]">{c.code}</td>
                  <td className="px-4 py-3 font-medium">{c.name}</td>
                  <td className="px-4 py-3 font-mono-num">{c.symbol}</td>
                  <td className="px-4 py-3 text-right font-mono-num font-semibold text-[#2563EB] dark:text-[#06B6D4]">
                    1 {c.code} = {c.exchange_rate_to_etb} ETB
                  </td>
                  <td className="px-4 py-3 text-right font-mono-num">{c.decimal_places ?? 2}</td>
                  <td className="px-4 py-3">
                    {c.is_default === 1 ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Default
                      </span>
                    ) : (
                      <button
                        onClick={() => setDefaultCurrency(c.code)}
                        className="text-[#2563EB] dark:text-[#06B6D4] hover:underline font-medium"
                      >
                        Set as Default
                      </button>
                    )}
                  </td>
                  <td className="px-4 py-3 font-mono-num text-slate-500">{c.updated_at}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        onClick={() => openEdit(c)}
                        className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title={t('edit')}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      {c.is_default !== 1 && c.code !== 'ETB' && (
                        <button
                          onClick={() => deleteCurrency(c.code)}
                          className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"
                          title={t('delete')}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Currency Converter & Exchange Rate History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-4 erp-card">
          <h3 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC] flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" />
            Currency Converter Calculator
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-medium mb-1">Amount</label>
              <input
                type="number"
                step="0.01"
                value={convAmount}
                onChange={(e) => setConvAmount(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
              />
            </div>
            <div>
              <label className="block font-medium mb-1">From</label>
              <select
                value={convFrom}
                onChange={(e) => setConvFrom(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827]"
              >
                {currencies.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code} — {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium mb-1">To</label>
              <select
                value={convTo}
                onChange={(e) => setConvTo(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827]"
              >
                {currencies.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code} — {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="p-4 rounded-xl bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between">
            <span className="text-slate-500 dark:text-slate-400">Converted Amount</span>
            <span className="text-lg font-bold font-mono-num text-[#2563EB] dark:text-[#06B6D4]">
              {formatMoney(convertedResult, convTo, toSymbol)}
            </span>
          </div>
        </div>

        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-3 erp-card">
          <h3 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Exchange Rate History</h3>
          <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {history.length === 0 ? (
              <div className="py-6 text-center text-slate-500">{t('noRecords')}</div>
            ) : (
              history.map((h) => (
                <div key={h.id} className="py-2 flex justify-between">
                  <span>
                    1 <strong className="font-mono-num">{h.currency_code}</strong> ={' '}
                    <strong className="font-mono-num text-[#2563EB] dark:text-[#06B6D4]">{h.rate_to_etb} ETB</strong>
                  </span>
                  <span className="text-slate-500 font-mono-num">
                    {h.changed_by} · {h.changed_at}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Add / Edit Currency Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form
            onSubmit={saveCurrency}
            className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-3 text-xs erp-card"
          >
            <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0] dark:border-slate-800">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
                {editingCode ? `Edit Currency: ${editingCode}` : 'Add Currency'}
              </h3>
              <button type="button" onClick={() => setModalOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium mb-1">Currency Code</label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  disabled={Boolean(editingCode)}
                  placeholder="USD, EUR, SOS..."
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num uppercase disabled:opacity-60"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Symbol</label>
                <input
                  type="text"
                  required
                  placeholder="$, €, Br..."
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div className="col-span-2">
                <label className="block font-medium mb-1">Currency Name</label>
                <input
                  type="text"
                  required
                  placeholder="US Dollar, Euro, Somali Shilling..."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Exchange Rate (to 1 ETB)</label>
                <input
                  type="number"
                  step="0.0001"
                  min={0.0001}
                  required
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Decimal Places</label>
                <input
                  type="number"
                  min={0}
                  max={4}
                  value={decimalPlaces}
                  onChange={(e) => setDecimalPlaces(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
            </div>
            <label className="inline-flex items-center gap-2 pt-1">
              <input type="checkbox" checked={isDefault} onChange={(e) => setIsDefault(e.target.checked)} className="accent-[#2563EB]" />
              <span>Set as Default Currency</span>
            </label>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
