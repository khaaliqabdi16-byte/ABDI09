import React, { useEffect, useState, useCallback } from 'react';
import { Plus, CreditCard, FileText, Trash2, Edit2, X } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { exportReportPdf, formatMoney } from '../utils/export.ts';
import { Customer, Supplier, CurrencyCode, OpeningBalanceEntry } from '../types/erp.ts';

type PeopleTab = 'customers' | 'customer_opening' | 'suppliers' | 'supplier_opening';

export function PeoplePage() {
  const { t, settings, currencies, activeSubTab, setActiveSubTab, hasPermission, showToast, refreshNotifications } = useApp();
  const [tab, setTab] = useState<PeopleTab>(() =>
    activeSubTab === 'customer_opening' || activeSubTab === 'suppliers' || activeSubTab === 'supplier_opening'
      ? activeSubTab
      : 'customers'
  );
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [openingEntries, setOpeningEntries] = useState<OpeningBalanceEntry[]>([]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formCode, setFormCode] = useState('');
  const [formName, setFormName] = useState('');
  const [formContact, setFormContact] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formOpening, setFormOpening] = useState('0');

  const [obPartyId, setObPartyId] = useState<number>(0);
  const [obType, setObType] = useState<'Opening Balance' | 'Debit' | 'Credit'>('Opening Balance');
  const [obAmount, setObAmount] = useState('');
  const [obDate, setObDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [obNotes, setObNotes] = useState('');

  const [payModal, setPayModal] = useState<{ type: 'customer' | 'supplier'; id: number; name: string; balance: number } | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payCurrency, setPayCurrency] = useState<CurrencyCode>('ETB');
  const [payMethod, setPayMethod] = useState('Cash');
  const [payNotes, setPayNotes] = useState('');

  const [statement, setStatement] = useState<{
    type: 'customer' | 'supplier';
    name: string;
    records: Array<Record<string, unknown>>;
    payments: Array<Record<string, unknown>>;
  } | null>(null);

  useEffect(() => {
    if (
      activeSubTab === 'customers' ||
      activeSubTab === 'customer_opening' ||
      activeSubTab === 'suppliers' ||
      activeSubTab === 'supplier_opening'
    ) {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const handleTabChange = (next: PeopleTab) => {
    setTab(next);
    setActiveSubTab(next);
  };

  const loadData = useCallback(async () => {
    try {
      const [cRes, sRes, obRes] = await Promise.all([
        apiFetch<{ customers: Customer[] }>('/api/customers'),
        apiFetch<{ suppliers: Supplier[] }>('/api/suppliers'),
        apiFetch<{ entries: OpeningBalanceEntry[] }>('/api/opening-balances'),
      ]);
      setCustomers(cRes.customers);
      setSuppliers(sRes.suppliers);
      setOpeningEntries(obRes.entries);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load people', 'error');
    }
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    if (tab === 'customer_opening' && customers.length > 0) {
      setObPartyId((prev) => (customers.some((c) => c.id === prev) ? prev : customers[0].id));
    } else if (tab === 'supplier_opening' && suppliers.length > 0) {
      setObPartyId((prev) => (suppliers.some((s) => s.id === prev) ? prev : suppliers[0].id));
    }
  }, [tab, customers, suppliers]);

  const isCustomerMode = tab === 'customers' || tab === 'customer_opening';

  const openCreate = () => {
    setEditingId(null);
    setFormCode('');
    setFormName('');
    setFormContact('');
    setFormEmail('');
    setFormPhone('');
    setFormAddress('');
    setFormOpening('0');
    setModalOpen(true);
  };

  const openEditCust = (c: Customer) => {
    setEditingId(c.id);
    setFormCode(c.customer_code || '');
    setFormName(c.full_name);
    setFormEmail(c.email || '');
    setFormPhone(c.phone);
    setFormAddress(c.address);
    setModalOpen(true);
  };

  const openEditSup = (s: Supplier) => {
    setEditingId(s.id);
    setFormCode(s.supplier_code || '');
    setFormName(s.business_name);
    setFormContact(s.contact_person);
    setFormEmail(s.email || '');
    setFormPhone(s.phone);
    setFormAddress(s.address);
    setModalOpen(true);
  };

  const savePerson = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isCustomerMode) {
        const body = {
          customer_code: formCode,
          full_name: formName,
          email: formEmail,
          phone: formPhone,
          address: formAddress,
          opening_balance: Number(formOpening || 0),
        };
        if (editingId) await apiFetch(`/api/customers/${editingId}`, { method: 'PUT', body: JSON.stringify(body) });
        else await apiFetch('/api/customers', { method: 'POST', body: JSON.stringify(body) });
      } else {
        const body = {
          supplier_code: formCode,
          business_name: formName,
          contact_person: formContact,
          email: formEmail,
          phone: formPhone,
          address: formAddress,
          opening_balance: Number(formOpening || 0),
        };
        if (editingId) await apiFetch(`/api/suppliers/${editingId}`, { method: 'PUT', body: JSON.stringify(body) });
        else await apiFetch('/api/suppliers', { method: 'POST', body: JSON.stringify(body) });
      }
      setModalOpen(false);
      showToast('Saved successfully', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
  };

  const deletePerson = async (kind: 'customers' | 'suppliers', id: number) => {
    try {
      await apiFetch(`/api/${kind}/${id}`, { method: 'DELETE' });
      showToast('Deleted successfully', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Cannot delete', 'error');
    }
  };

  const submitOpeningBalance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!obPartyId || Number(obAmount) <= 0) {
      showToast('Select a record and enter a positive amount', 'error');
      return;
    }
    try {
      const endpoint =
        tab === 'customer_opening'
          ? `/api/customers/${obPartyId}/opening-balance`
          : `/api/suppliers/${obPartyId}/opening-balance`;
      await apiFetch(endpoint, {
        method: 'POST',
        body: JSON.stringify({
          entry_type: obType,
          amount: Number(obAmount),
          entry_date: obDate,
          notes: obNotes,
        }),
      });
      setObAmount('');
      setObNotes('');
      showToast('Opening balance entry recorded', 'success');
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to save opening balance', 'error');
    }
  };

  const submitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModal) return;
    try {
      const endpoint = payModal.type === 'customer' ? `/api/customers/${payModal.id}/pay` : `/api/suppliers/${payModal.id}/pay`;
      await apiFetch(endpoint, {
        method: 'POST',
        body: JSON.stringify({
          amount: Number(payAmount),
          currency: payCurrency,
          payment_method: payMethod,
          notes: payNotes,
        }),
      });
      setPayModal(null);
      setPayNotes('');
      showToast('Payment recorded', 'success');
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Payment failed', 'error');
    }
  };

  const viewStatement = async (type: 'customer' | 'supplier', id: number, name: string) => {
    try {
      if (type === 'customer') {
        const res = await apiFetch<{ sales: Array<Record<string, unknown>>; payments: Array<Record<string, unknown>> }>(`/api/customers/${id}/statement`);
        setStatement({ type, name, records: res.sales, payments: res.payments });
      } else {
        const res = await apiFetch<{ purchases: Array<Record<string, unknown>>; payments: Array<Record<string, unknown>> }>(`/api/suppliers/${id}/statement`);
        setStatement({ type, name, records: res.purchases, payments: res.payments });
      }
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load statement', 'error');
    }
  };

  const filteredOpeningEntries = openingEntries.filter((e) =>
    tab === 'customer_opening' ? e.party_type === 'customer' : e.party_type === 'supplier'
  );

  return (
    <div className="space-y-5">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 erp-card">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => handleTabChange('customers')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              tab === 'customers' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
            }`}
          >
            {t('customers')} ({customers.length})
          </button>
          <button
            onClick={() => handleTabChange('customer_opening')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              tab === 'customer_opening' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
            }`}
          >
            {t('customerOpeningBalance')}
          </button>
          <button
            onClick={() => handleTabChange('suppliers')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              tab === 'suppliers' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
            }`}
          >
            {t('suppliers')} ({suppliers.length})
          </button>
          <button
            onClick={() => handleTabChange('supplier_opening')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              tab === 'supplier_opening' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
            }`}
          >
            {t('supplierOpeningBalance')}
          </button>
        </div>

        {(tab === 'customers' || tab === 'suppliers') && hasPermission('people.manage') && (
          <button
            onClick={openCreate}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            {tab === 'customers' ? t('addCustomer') : t('addSupplier')}
          </button>
        )}
      </div>

      {(tab === 'customers' || tab === 'suppliers') && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Code</th>
                  <th className="text-left px-4 py-3 font-medium">Name</th>
                  <th className="text-left px-4 py-3 font-medium">Contact / Address</th>
                  <th className="text-right px-4 py-3 font-medium">Opening</th>
                  <th className="text-right px-4 py-3 font-medium">Total</th>
                  <th className="text-right px-4 py-3 font-medium">Paid</th>
                  <th className="text-right px-4 py-3 font-medium">Outstanding</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {tab === 'customers'
                  ? customers.map((c) => (
                      <tr key={c.id}>
                        <td className="px-4 py-3 font-mono-num text-slate-500">{c.customer_code || `#${c.id}`}</td>
                        <td className="px-4 py-3 font-semibold">{c.full_name}</td>
                        <td className="px-4 py-3 text-slate-500">
                          <div>{c.phone || '-'} {c.email ? `· ${c.email}` : ''}</div>
                          <div className="text-[11px]">{c.address || '-'}</div>
                        </td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(c.opening_balance, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(c.total_purchases, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(c.total_paid, 'ETB')}</td>
                        <td className={`px-4 py-3 text-right font-mono-num font-semibold ${c.outstanding_balance > 0 ? 'text-amber-600' : ''}`}>
                          {formatMoney(c.outstanding_balance, 'ETB')}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              onClick={() => viewStatement('customer', c.id, c.full_name)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                              title={t('viewStatement')}
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                            {hasPermission('people.manage') && (
                              <>
                                <button
                                  onClick={() => {
                                    setPayModal({ type: 'customer', id: c.id, name: c.full_name, balance: c.outstanding_balance });
                                    setPayAmount(String(c.outstanding_balance || ''));
                                  }}
                                  className="p-1.5 rounded-lg border border-[#E2E8F0] dark:border-slate-700 text-[#2563EB] dark:text-[#06B6D4] hover:bg-[#2563EB]/10 transition-colors"
                                  title={t('recordPayment')}
                                >
                                  <CreditCard className="w-3.5 h-3.5" />
                                </button>
                                <button onClick={() => openEditCust(c)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700">
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                {c.id !== 1 && (
                                  <button onClick={() => deletePerson('customers', c.id)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600">
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  : suppliers.map((s) => (
                      <tr key={s.id}>
                        <td className="px-4 py-3 font-mono-num text-slate-500">{s.supplier_code || `#${s.id}`}</td>
                        <td className="px-4 py-3">
                          <div className="font-semibold">{s.business_name}</div>
                          <div className="text-[11px] text-slate-500">{s.contact_person}</div>
                        </td>
                        <td className="px-4 py-3 text-slate-500">
                          <div>{s.phone || '-'} {s.email ? `· ${s.email}` : ''}</div>
                          <div className="text-[11px]">{s.address || '-'}</div>
                        </td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(s.opening_balance, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(s.total_purchases, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(s.total_paid, 'ETB')}</td>
                        <td className={`px-4 py-3 text-right font-mono-num font-semibold ${s.outstanding_balance > 0 ? 'text-amber-600' : ''}`}>
                          {formatMoney(s.outstanding_balance, 'ETB')}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              onClick={() => viewStatement('supplier', s.id, s.business_name)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                              title={t('viewStatement')}
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                            {hasPermission('people.manage') && (
                              <>
                                <button
                                  onClick={() => {
                                    setPayModal({ type: 'supplier', id: s.id, name: s.business_name, balance: s.outstanding_balance });
                                    setPayAmount(String(s.outstanding_balance || ''));
                                  }}
                                  className="p-1.5 rounded-lg border border-[#E2E8F0] dark:border-slate-700 text-[#2563EB] dark:text-[#06B6D4] hover:bg-[#2563EB]/10 transition-colors"
                                  title={t('recordPayment')}
                                >
                                  <CreditCard className="w-3.5 h-3.5" />
                                </button>
                                <button onClick={() => openEditSup(s)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700">
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button onClick={() => deletePerson('suppliers', s.id)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600">
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {(tab === 'customer_opening' || tab === 'supplier_opening') && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {hasPermission('people.manage') && (
            <form
              onSubmit={submitOpeningBalance}
              className="lg:col-span-4 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-3 text-xs erp-card h-fit"
            >
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
                {tab === 'customer_opening' ? t('customerOpeningBalance') : t('supplierOpeningBalance')}
              </h3>
              <div>
                <label className="block font-medium mb-1">
                  {tab === 'customer_opening' ? t('customer') : t('supplier')}
                </label>
                <select
                  value={obPartyId}
                  onChange={(e) => setObPartyId(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  {tab === 'customer_opening'
                    ? customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.full_name} (Bal: {formatMoney(c.outstanding_balance, 'ETB')})
                        </option>
                      ))
                    : suppliers.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.business_name} (Bal: {formatMoney(s.outstanding_balance, 'ETB')})
                        </option>
                      ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium mb-1">Entry Type</label>
                  <select
                    value={obType}
                    onChange={(e) => setObType(e.target.value as 'Opening Balance' | 'Debit' | 'Credit')}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    <option value="Opening Balance">Opening Balance</option>
                    <option value="Debit">Debit</option>
                    <option value="Credit">Credit</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium mb-1">{t('date')}</label>
                  <input
                    type="date"
                    value={obDate}
                    onChange={(e) => setObDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                  />
                </div>
              </div>
              <div>
                <label className="block font-medium mb-1">Amount (ETB)</label>
                <input
                  type="number"
                  min={0.01}
                  step="0.01"
                  required
                  value={obAmount}
                  onChange={(e) => setObAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Notes</label>
                <input
                  type="text"
                  value={obNotes}
                  onChange={(e) => setObNotes(e.target.value)}
                  placeholder="Initial balance or adjustment note..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold"
              >
                {t('save')}
              </button>
            </form>
          )}

          <div className={`${hasPermission('people.manage') ? 'lg:col-span-8' : 'lg:col-span-12'} bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card`}>
            <div className="px-4 py-3 border-b border-[#E2E8F0] dark:border-slate-800 font-semibold text-xs text-[#0B1F4D] dark:text-[#F8FAFC]">
              Opening Balance Ledger ({filteredOpeningEntries.length})
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500">
                    <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                    <th className="text-left px-4 py-3 font-medium">{tab === 'customer_opening' ? t('customer') : t('supplier')}</th>
                    <th className="text-left px-4 py-3 font-medium">Type</th>
                    <th className="text-right px-4 py-3 font-medium">Amount (ETB)</th>
                    <th className="text-left px-4 py-3 font-medium">Notes</th>
                    <th className="text-left px-4 py-3 font-medium">By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredOpeningEntries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-10 text-center text-slate-500">{t('noRecords')}</td>
                    </tr>
                  ) : (
                    filteredOpeningEntries.map((ob) => (
                      <tr key={ob.id}>
                        <td className="px-4 py-3 font-mono-num text-slate-500">{ob.entry_date}</td>
                        <td className="px-4 py-3 font-semibold">{ob.party_name || `#${ob.party_id}`}</td>
                        <td className="px-4 py-3">
                          <span className={`font-medium ${ob.entry_type === 'Credit' ? 'text-emerald-600' : 'text-[#2563EB] dark:text-[#06B6D4]'}`}>
                            {ob.entry_type}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right font-mono-num font-semibold">{formatMoney(ob.amount, 'ETB')}</td>
                        <td className="px-4 py-3 text-slate-500">{ob.notes || '-'}</td>
                        <td className="px-4 py-3 text-slate-500">{ob.created_by}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={savePerson} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-3 text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">{editingId ? 'Edit Record' : isCustomerMode ? t('addCustomer') : t('addSupplier')}</h3>
              <button type="button" onClick={() => setModalOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block font-medium mb-1">Code</label>
                <input
                  type="text"
                  value={formCode}
                  onChange={(e) => setFormCode(e.target.value)}
                  placeholder={isCustomerMode ? 'CUS-001' : 'SUP-001'}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div className="col-span-2">
                <label className="block font-medium mb-1">{isCustomerMode ? 'Full Name' : 'Business Name'}</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
            </div>
            {!isCustomerMode && (
              <div>
                <label className="block font-medium mb-1">Contact Person</label>
                <input
                  type="text"
                  value={formContact}
                  onChange={(e) => setFormContact(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
            )}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-medium mb-1">{t('phone')}</label>
                <input
                  type="text"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('email')}</label>
                <input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
            </div>
            <div>
              <label className="block font-medium mb-1">{t('address')}</label>
              <input
                type="text"
                value={formAddress}
                onChange={(e) => setFormAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
              />
            </div>
            {!editingId && (
              <div>
                <label className="block font-medium mb-1">Opening Balance (ETB)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formOpening}
                  onChange={(e) => setFormOpening(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
            )}
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Payment Modal */}
      {payModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={submitPayment} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-3 text-xs erp-card">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">{t('recordPayment')} · {payModal.name}</h3>
              <button type="button" onClick={() => setPayModal(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-slate-500">
              Current Outstanding: <span className="font-mono-num font-semibold">{formatMoney(payModal.balance, 'ETB')}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                step="0.01"
                min={0.01}
                required
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                placeholder="Amount"
                className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
              />
              <select
                value={payCurrency}
                onChange={(e) => setPayCurrency(e.target.value as CurrencyCode)}
                className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
              >
                {currencies.map((c) => (
                  <option key={c.code} value={c.code}>{c.code}</option>
                ))}
              </select>
            </div>
            <select
              value={payMethod}
              onChange={(e) => setPayMethod(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="Cash">{t('cash')}</option>
              <option value="Card">{t('cardPayment')}</option>
              <option value="Bank Transfer">{t('bankTransfer')}</option>
              <option value="Mobile Money">{t('mobileMoney')}</option>
            </select>
            <input
              type="text"
              placeholder="Notes"
              value={payNotes}
              onChange={(e) => setPayNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
            />
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setPayModal(null)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Account Statement Modal */}
      {statement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-2xl p-5 space-y-4 max-h-[85vh] overflow-y-auto text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0] dark:border-slate-800">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Account Statement · {statement.name}</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    exportReportPdf(
                      `Account Statement - ${statement.name}`,
                      statement.records,
                      settings
                    )
                  }
                  className="px-3 py-1.5 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium transition-colors"
                >
                  {t('exportPdf')}
                </button>
                <button onClick={() => setStatement(null)}>
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div>
              <div className="font-semibold mb-2">Invoices / Orders ({statement.records.length})</div>
              <table className="w-full border border-slate-200 dark:border-slate-800">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500">
                    <th className="text-left p-2">Ref</th>
                    <th className="text-left p-2">Date</th>
                    <th className="text-right p-2">Total</th>
                    <th className="text-right p-2">Paid</th>
                    <th className="text-right p-2">Balance</th>
                    <th className="text-left p-2">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {statement.records.map((r, i) => (
                    <tr key={i}>
                      <td className="p-2 font-mono-num">{String(r.invoice_number || r.purchase_number)}</td>
                      <td className="p-2 font-mono-num">{String(r.sale_date || r.purchase_date)}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.grand_total), String(r.currency))}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.paid_amount), String(r.currency))}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.balance_amount), String(r.currency))}</td>
                      <td className="p-2">{String(r.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div>
              <div className="font-semibold mb-2">Payment History ({statement.payments.length})</div>
              <table className="w-full border border-slate-200 dark:border-slate-800">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500">
                    <th className="text-left p-2">Date</th>
                    <th className="text-left p-2">Method</th>
                    <th className="text-right p-2">Amount</th>
                    <th className="text-right p-2">ETB Equivalent</th>
                    <th className="text-left p-2">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {statement.payments.map((p, i) => (
                    <tr key={i}>
                      <td className="p-2 font-mono-num">{String(p.created_at)}</td>
                      <td className="p-2">{String(p.payment_method)}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(p.amount), String(p.currency))}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(p.amount_etb), 'ETB')}</td>
                      <td className="p-2 text-slate-500">{String(p.notes || '-')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
