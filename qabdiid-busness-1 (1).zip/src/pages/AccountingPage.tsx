import React, { useEffect, useState, useCallback } from 'react';
import { Plus, Lock, Unlock, X } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { formatMoney } from '../utils/export.ts';
import { Account } from '../types/erp.ts';

interface JournalEntry {
  id: number;
  entry_number: string;
  entry_date: string;
  reference_type: string;
  reference_id: string;
  description: string;
  created_by: string;
  lines: Array<{ id: number; account_code: string; account_name: string; debit: number; credit: number }>;
}

interface StatementsData {
  trialBalance: Array<Account & { debit: number; credit: number }>;
  incomeStatement: { revAccounts: Account[]; expAccounts: Account[]; totalRevenue: number; totalExpenses: number; netIncome: number };
  balanceSheet: { assets: Account[]; liabilities: Account[]; equity: Account[]; netIncome: number; totalAssets: number; totalLiabilities: number; totalEquity: number };
  cashFlow: { cashLines: Array<{ reference_type: string; inflow: number; outflow: number }>; cashBalance: number };
}

interface Period {
  id: number;
  name: string;
  start_date: string;
  end_date: string;
  status: string;
}

export function AccountingPage() {
  const { t, hasPermission, showToast } = useApp();
  const [tab, setTab] = useState<'coa' | 'journal' | 'ledger' | 'trial' | 'income' | 'balance' | 'cashflow' | 'periods'>('coa');

  const [accounts, setAccounts] = useState<Account[]>([]);
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [statements, setStatements] = useState<StatementsData | null>(null);
  const [periods, setPeriods] = useState<Period[]>([]);

  const [selectedAcctId, setSelectedAcctId] = useState<number>(1);
  const [ledgerLines, setLedgerLines] = useState<Array<{ entry_number: string; entry_date: string; description: string; debit: number; credit: number }>>([]);

  const [acctModal, setAcctModal] = useState(false);
  const [newAcctCode, setNewAcctCode] = useState('');
  const [newAcctName, setNewAcctName] = useState('');
  const [newAcctType, setNewAcctType] = useState('Asset');

  const [jrnModal, setJrnModal] = useState(false);
  const [jrnDate, setJrnDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [jrnDesc, setJrnDesc] = useState('');
  const [jrnLines, setJrnLines] = useState<Array<{ accountCode: string; debit: number; credit: number }>>([
    { accountCode: '1000', debit: 0, credit: 0 },
    { accountCode: '3000', debit: 0, credit: 0 },
  ]);

  const [pName, setPName] = useState('');
  const [pStart, setPStart] = useState('');
  const [pEnd, setPEnd] = useState('');

  const loadAll = useCallback(async () => {
    try {
      const [aRes, jRes, sRes, pRes] = await Promise.all([
        apiFetch<{ accounts: Account[] }>('/api/accounting/accounts'),
        apiFetch<{ entries: JournalEntry[] }>('/api/accounting/journal'),
        apiFetch<StatementsData>('/api/accounting/statements'),
        apiFetch<{ periods: Period[] }>('/api/accounting/periods'),
      ]);
      setAccounts(aRes.accounts);
      setEntries(jRes.entries);
      setStatements(sRes);
      setPeriods(pRes.periods);
      if (aRes.accounts[0] && !selectedAcctId) setSelectedAcctId(aRes.accounts[0].id);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load accounting', 'error');
    }
  }, [selectedAcctId, showToast]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  useEffect(() => {
    if (tab === 'ledger' && selectedAcctId) {
      apiFetch<{ lines: Array<{ entry_number: string; entry_date: string; description: string; debit: number; credit: number }> }>(
        `/api/accounting/ledger/${selectedAcctId}`
      )
        .then((res) => setLedgerLines(res.lines))
        .catch(() => {});
    }
  }, [tab, selectedAcctId]);

  const createAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/accounting/accounts', {
        method: 'POST',
        body: JSON.stringify({ code: newAcctCode, name: newAcctName, type: newAcctType }),
      });
      setAcctModal(false);
      setNewAcctCode('');
      setNewAcctName('');
      showToast('Account added', 'success');
      await loadAll();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to add account', 'error');
    }
  };

  const createJournal = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/accounting/journal', {
        method: 'POST',
        body: JSON.stringify({ entry_date: jrnDate, description: jrnDesc, lines: jrnLines }),
      });
      setJrnModal(false);
      setJrnDesc('');
      showToast('Journal entry posted', 'success');
      await loadAll();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to post journal entry', 'error');
    }
  };

  const createPeriod = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/accounting/periods', {
        method: 'POST',
        body: JSON.stringify({ name: pName, start_date: pStart, end_date: pEnd }),
      });
      setPName('');
      setPStart('');
      setPEnd('');
      showToast('Financial period added', 'success');
      await loadAll();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to create period', 'error');
    }
  };

  const togglePeriod = async (id: number) => {
    try {
      await apiFetch(`/api/accounting/periods/${id}/toggle`, { method: 'PUT' });
      await loadAll();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to toggle period', 'error');
    }
  };

  const tabs = [
    { key: 'coa', label: t('chartOfAccounts') },
    { key: 'journal', label: t('journalEntries') },
    { key: 'ledger', label: t('generalLedger') },
    { key: 'trial', label: t('trialBalance') },
    { key: 'income', label: t('incomeStatement') },
    { key: 'balance', label: t('balanceSheet') },
    { key: 'cashflow', label: t('cashFlow') },
    { key: 'periods', label: t('financialPeriods') },
  ] as const;

  return (
    <div className="space-y-5">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2 erp-card">
        <div className="flex flex-wrap items-center gap-1.5">
          {tabs.map((item) => (
            <button
              key={item.key}
              onClick={() => setTab(item.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                tab === item.key
                  ? 'bg-[#2563EB] text-white shadow-sm'
                  : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {hasPermission('accounting.manage') && (
          <div className="flex items-center gap-2">
            {tab === 'coa' && (
              <button
                onClick={() => setAcctModal(true)}
                className="inline-flex items-center gap-1 px-3.5 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add Account
              </button>
            )}
            {tab === 'journal' && (
              <button
                onClick={() => setJrnModal(true)}
                className="inline-flex items-center gap-1 px-3.5 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Post Journal Entry
              </button>
            )}
          </div>
        )}
      </div>

      {/* Chart of Accounts */}
      {tab === 'coa' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                <th className="text-left px-4 py-3 font-medium">Code</th>
                <th className="text-left px-4 py-3 font-medium">Account Name</th>
                <th className="text-left px-4 py-3 font-medium">Type</th>
                <th className="text-right px-4 py-3 font-medium">Current Balance (ETB)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {accounts.map((a) => (
                <tr key={a.id}>
                  <td className="px-4 py-2.5 font-mono-num font-semibold">{a.code}</td>
                  <td className="px-4 py-2.5">{a.name}</td>
                  <td className="px-4 py-2.5 text-slate-500">{a.type}</td>
                  <td className="px-4 py-2.5 text-right font-mono-num font-semibold">{formatMoney(a.balance, 'ETB')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Journal Entries */}
      {tab === 'journal' && (
        <div className="space-y-3">
          {entries.length === 0 ? (
            <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-10 text-center text-xs text-slate-500 erp-card">
              {t('noRecords')}
            </div>
          ) : (
            entries.map((entry) => (
              <div key={entry.id} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 text-xs erp-card">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-2 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <span className="font-mono-num font-bold">{entry.entry_number}</span> · {entry.description}
                  </div>
                  <div className="text-slate-500 font-mono-num">
                    {entry.entry_date} · {entry.reference_type} ({entry.reference_id}) · {entry.created_by}
                  </div>
                </div>
                <table className="w-full">
                  <thead>
                    <tr className="text-slate-400">
                      <th className="text-left py-1 font-medium">Account</th>
                      <th className="text-right py-1 font-medium">Debit</th>
                      <th className="text-right py-1 font-medium">Credit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {entry.lines.map((l) => (
                      <tr key={l.id}>
                        <td className="py-1 font-mono-num">
                          {l.account_code} - {l.account_name}
                        </td>
                        <td className="py-1 text-right font-mono-num">{l.debit > 0 ? formatMoney(l.debit, 'ETB') : '-'}</td>
                        <td className="py-1 text-right font-mono-num">{l.credit > 0 ? formatMoney(l.credit, 'ETB') : '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))
          )}
        </div>
      )}

      {/* General Ledger */}
      {tab === 'ledger' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 space-y-4 erp-card">
          <select
            value={selectedAcctId}
            onChange={(e) => setSelectedAcctId(Number(e.target.value))}
            className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-xs"
          >
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.code} - {a.name}
              </option>
            ))}
          </select>

          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="text-left py-2">Entry #</th>
                <th className="text-left py-2">Date</th>
                <th className="text-left py-2">Description</th>
                <th className="text-right py-2">Debit</th>
                <th className="text-right py-2">Credit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {ledgerLines.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    {t('noRecords')}
                  </td>
                </tr>
              ) : (
                ledgerLines.map((l, i) => (
                  <tr key={i}>
                    <td className="py-2 font-mono-num">{l.entry_number}</td>
                    <td className="py-2 font-mono-num text-slate-500">{l.entry_date}</td>
                    <td className="py-2">{l.description}</td>
                    <td className="py-2 text-right font-mono-num">{l.debit > 0 ? formatMoney(l.debit, 'ETB') : '-'}</td>
                    <td className="py-2 text-right font-mono-num">{l.credit > 0 ? formatMoney(l.credit, 'ETB') : '-'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Trial Balance */}
      {tab === 'trial' && statements && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                <th className="text-left px-4 py-3 font-medium">Code</th>
                <th className="text-left px-4 py-3 font-medium">Account</th>
                <th className="text-right px-4 py-3 font-medium">Debit (ETB)</th>
                <th className="text-right px-4 py-3 font-medium">Credit (ETB)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {statements.trialBalance.map((r) => (
                <tr key={r.id}>
                  <td className="px-4 py-2.5 font-mono-num">{r.code}</td>
                  <td className="px-4 py-2.5">{r.name}</td>
                  <td className="px-4 py-2.5 text-right font-mono-num">{r.debit > 0 ? formatMoney(r.debit, 'ETB') : '-'}</td>
                  <td className="px-4 py-2.5 text-right font-mono-num">{r.credit > 0 ? formatMoney(r.credit, 'ETB') : '-'}</td>
                </tr>
              ))}
              <tr className="bg-slate-50 dark:bg-slate-800/50 font-bold">
                <td colSpan={2} className="px-4 py-3">Totals</td>
                <td className="px-4 py-3 text-right font-mono-num">
                  {formatMoney(statements.trialBalance.reduce((s, r) => s + r.debit, 0), 'ETB')}
                </td>
                <td className="px-4 py-3 text-right font-mono-num">
                  {formatMoney(statements.trialBalance.reduce((s, r) => s + r.credit, 0), 'ETB')}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* Income Statement */}
      {tab === 'income' && statements && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-6 max-w-2xl space-y-4 text-xs erp-card">
          <h3 className="font-display font-bold text-base text-[#0B1F4D] dark:text-[#F8FAFC]">{t('incomeStatement')}</h3>
          <div className="space-y-1.5">
            <div className="font-semibold text-slate-500">Revenue</div>
            {statements.incomeStatement.revAccounts.map((a) => (
              <div key={a.id} className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span>{a.code} - {a.name}</span>
                <span className="font-mono-num">{formatMoney(a.balance, 'ETB')}</span>
              </div>
            ))}
            <div className="flex justify-between font-bold pt-1">
              <span>Total Revenue</span>
              <span className="font-mono-num">{formatMoney(statements.incomeStatement.totalRevenue, 'ETB')}</span>
            </div>
          </div>

          <div className="space-y-1.5 pt-2">
            <div className="font-semibold text-slate-500">Cost & Operating Expenses</div>
            {statements.incomeStatement.expAccounts.map((a) => (
              <div key={a.id} className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span>{a.code} - {a.name}</span>
                <span className="font-mono-num">{formatMoney(a.balance, 'ETB')}</span>
              </div>
            ))}
            <div className="flex justify-between font-bold pt-1">
              <span>Total Expenses</span>
              <span className="font-mono-num">{formatMoney(statements.incomeStatement.totalExpenses, 'ETB')}</span>
            </div>
          </div>

          <div className="flex justify-between text-sm font-bold pt-3 border-t-2 border-slate-200 dark:border-slate-700">
            <span>Net Income / Profit</span>
            <span className={`font-mono-num ${statements.incomeStatement.netIncome >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-600'}`}>
              {formatMoney(statements.incomeStatement.netIncome, 'ETB')}
            </span>
          </div>
        </div>
      )}

      {/* Balance Sheet */}
      {tab === 'balance' && statements && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-2 erp-card">
            <h3 className="font-display font-bold text-sm mb-2 text-[#0B1F4D] dark:text-[#F8FAFC]">Assets</h3>
            {statements.balanceSheet.assets.map((a) => (
              <div key={a.id} className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span>{a.code} - {a.name}</span>
                <span className="font-mono-num">{formatMoney(a.balance, 'ETB')}</span>
              </div>
            ))}
            <div className="flex justify-between font-bold text-sm pt-2">
              <span>Total Assets</span>
              <span className="font-mono-num text-[#2563EB] dark:text-[#06B6D4]">{formatMoney(statements.balanceSheet.totalAssets, 'ETB')}</span>
            </div>
          </div>

          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-2 erp-card">
            <h3 className="font-display font-bold text-sm mb-2 text-[#0B1F4D] dark:text-[#F8FAFC]">Liabilities & Equity</h3>
            {statements.balanceSheet.liabilities.map((a) => (
              <div key={a.id} className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span>{a.code} - {a.name}</span>
                <span className="font-mono-num">{formatMoney(a.balance, 'ETB')}</span>
              </div>
            ))}
            {statements.balanceSheet.equity.map((a) => (
              <div key={a.id} className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span>{a.code} - {a.name}</span>
                <span className="font-mono-num">{formatMoney(a.balance, 'ETB')}</span>
              </div>
            ))}
            <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
              <span>Retained Earnings (Current Net Income)</span>
              <span className="font-mono-num">{formatMoney(statements.balanceSheet.netIncome, 'ETB')}</span>
            </div>
            <div className="flex justify-between font-bold text-sm pt-2">
              <span>Total Liabilities & Equity</span>
              <span className="font-mono-num">
                {formatMoney(statements.balanceSheet.totalLiabilities + statements.balanceSheet.totalEquity, 'ETB')}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Cash Flow */}
      {tab === 'cashflow' && statements && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 max-w-2xl space-y-4 text-xs erp-card">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">{t('cashFlow')}</h3>
            <span className="font-mono-num font-bold text-[#2563EB] dark:text-[#06B6D4]">
              Ending Cash & Bank: {formatMoney(statements.cashFlow.cashBalance, 'ETB')}
            </span>
          </div>
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="text-left py-2">Activity</th>
                <th className="text-right py-2">Inflow</th>
                <th className="text-right py-2">Outflow</th>
                <th className="text-right py-2">Net</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {statements.cashFlow.cashLines.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-500">
                    {t('noRecords')}
                  </td>
                </tr>
              ) : (
                statements.cashFlow.cashLines.map((c, idx) => (
                  <tr key={idx}>
                    <td className="py-2 font-medium capitalize">{(c.reference_type || 'general').replace(/_/g, ' ')}</td>
                    <td className="py-2 text-right font-mono-num text-emerald-700">{formatMoney(c.inflow, 'ETB')}</td>
                    <td className="py-2 text-right font-mono-num text-red-600">{formatMoney(c.outflow, 'ETB')}</td>
                    <td className="py-2 text-right font-mono-num font-semibold">{formatMoney(c.inflow - c.outflow, 'ETB')}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Financial Periods */}
      {tab === 'periods' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          {hasPermission('accounting.manage') && (
            <form onSubmit={createPeriod} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-3 h-fit erp-card">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Create Financial Period</h3>
              <input
                type="text"
                required
                placeholder="FY 2027"
                value={pName}
                onChange={(e) => setPName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent"
              />
              <input
                type="date"
                required
                value={pStart}
                onChange={(e) => setPStart(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
              />
              <input
                type="date"
                required
                value={pEnd}
                onChange={(e) => setPEnd(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
              />
              <button type="submit" className="w-full py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
                {t('save')}
              </button>
            </form>
          )}
          <div className="lg:col-span-2 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
            <table className="w-full">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Period</th>
                  <th className="text-left px-4 py-3 font-medium">Start</th>
                  <th className="text-left px-4 py-3 font-medium">End</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {periods.map((p) => (
                  <tr key={p.id}>
                    <td className="px-4 py-3 font-semibold">{p.name}</td>
                    <td className="px-4 py-3 font-mono-num">{p.start_date}</td>
                    <td className="px-4 py-3 font-mono-num">{p.end_date}</td>
                    <td className="px-4 py-3">{p.status}</td>
                    <td className="px-4 py-3 text-right">
                      {hasPermission('accounting.manage') && (
                        <button
                          onClick={() => togglePeriod(p.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700"
                        >
                          {p.status === 'Open' ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                          {p.status === 'Open' ? 'Close' : 'Reopen'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Account Modal */}
      {acctModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={createAccount} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-3 text-xs erp-card">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Add Account</h3>
              <button type="button" onClick={() => setAcctModal(false)}><X className="w-4 h-4" /></button>
            </div>
            <input type="text" required placeholder="Account Code (e.g. 6100)" value={newAcctCode} onChange={(e) => setNewAcctCode(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num" />
            <input type="text" required placeholder="Account Name" value={newAcctName} onChange={(e) => setNewAcctName(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
            <select value={newAcctType} onChange={(e) => setNewAcctType(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827]">
              <option value="Asset">Asset</option>
              <option value="Liability">Liability</option>
              <option value="Equity">Equity</option>
              <option value="Revenue">Revenue</option>
              <option value="Expense">Expense</option>
            </select>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setAcctModal(false)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700">{t('cancel')}</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">{t('save')}</button>
            </div>
          </form>
        </div>
      )}

      {/* Post Manual Journal Modal */}
      {jrnModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={createJournal} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-lg p-5 space-y-3 text-xs erp-card">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">New Manual Journal Entry</h3>
              <button type="button" onClick={() => setJrnModal(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input type="date" required value={jrnDate} onChange={(e) => setJrnDate(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num" />
              <input type="text" required placeholder="Description" value={jrnDesc} onChange={(e) => setJrnDesc(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
            </div>
            <div className="space-y-2">
              {jrnLines.map((line, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2">
                  <select
                    value={line.accountCode}
                    onChange={(e) => setJrnLines((prev) => prev.map((l, i) => (i === idx ? { ...l, accountCode: e.target.value } : l)))}
                    className="col-span-6 px-2 py-1.5 rounded-lg border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827]"
                  >
                    {accounts.map((a) => (
                      <option key={a.id} value={a.code}>{a.code} - {a.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    placeholder="Debit"
                    value={line.debit}
                    onChange={(e) => setJrnLines((prev) => prev.map((l, i) => (i === idx ? { ...l, debit: Number(e.target.value) || 0 } : l)))}
                    className="col-span-3 px-2 py-1.5 rounded-lg border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
                  />
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    placeholder="Credit"
                    value={line.credit}
                    onChange={(e) => setJrnLines((prev) => prev.map((l, i) => (i === idx ? { ...l, credit: Number(e.target.value) || 0 } : l)))}
                    className="col-span-3 px-2 py-1.5 rounded-lg border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
                  />
                </div>
              ))}
              <button
                type="button"
                onClick={() => setJrnLines((prev) => [...prev, { accountCode: '1000', debit: 0, credit: 0 }])}
                className="text-[#2563EB] dark:text-[#06B6D4] font-semibold hover:underline"
              >
                + Add Line
              </button>
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setJrnModal(false)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700">{t('cancel')}</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">{t('save')}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
