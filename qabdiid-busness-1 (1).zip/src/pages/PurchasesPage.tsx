import React, { useEffect, useState, useCallback } from 'react';
import { Plus, Download, RotateCcw, CreditCard, Trash2, X, History } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { formatMoney, generatePurchaseVoucherPdf } from '../utils/export.ts';
import { CurrencyCode, Product, Purchase, Supplier, SupplierPurchasesSummary, Warehouse } from '../types/erp.ts';

interface PurchaseItemRow {
  id: number;
  product_id: number;
  product_name: string;
  sku: string;
  unit: string;
  quantity: number;
  returned_qty: number;
  purchase_price: number;
  vat_rate: number;
  vat_amount: number;
  subtotal: number;
}

interface PurchaseReturnRow {
  id: number;
  return_number: string;
  purchase_number: string;
  supplier_name: string;
  return_date: string;
  total_refund: number;
  reason?: string;
  status?: string;
  items_summary?: string;
  total_quantity?: number;
  created_by: string;
}

type PurchasesTab = 'list' | 'returns' | 'supplier_purchases';

export function PurchasesPage() {
  const { t, settings, currencies, activeSubTab, setActiveSubTab, hasPermission, showToast, refreshNotifications } = useApp();
  const [tab, setTab] = useState<PurchasesTab>(() =>
    activeSubTab === 'returns' || activeSubTab === 'supplier_purchases' ? activeSubTab : 'list'
  );
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [returns, setReturns] = useState<PurchaseReturnRow[]>([]);
  const [supplierSummaries, setSupplierSummaries] = useState<SupplierPurchasesSummary[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);

  const [createOpen, setCreateOpen] = useState(false);
  const [supplierId, setSupplierId] = useState<number>(1);
  const [warehouseId, setWarehouseId] = useState<number>(1);
  const [currency, setCurrency] = useState<CurrencyCode>('ETB');
  const [purchaseDate, setPurchaseDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [supplierInvoiceNo, setSupplierInvoiceNo] = useState('');
  const [discount, setDiscount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [paidAmount, setPaidAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [lineItems, setLineItems] = useState<Array<{ product_id: number; quantity: number; purchase_price: number; vat_rate: number }>>([]);

  const [returnModal, setReturnModal] = useState<{ purchase: Purchase; items: PurchaseItemRow[] } | null>(null);
  const [returnQtys, setReturnQtys] = useState<Record<number, number>>({});
  const [returnReason, setReturnReason] = useState('');
  const [returnStatus, setReturnStatus] = useState('Credited');

  const [payModal, setPayModal] = useState<Purchase | null>(null);
  const [payAmt, setPayAmt] = useState('');
  const [payMethod, setPayMethod] = useState('Cash');

  const [historyModal, setHistoryModal] = useState<{
    supplierName: string;
    purchases: Array<Record<string, unknown>>;
    payments: Array<Record<string, unknown>>;
  } | null>(null);

  useEffect(() => {
    if (activeSubTab === 'list' || activeSubTab === 'returns' || activeSubTab === 'supplier_purchases') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const handleTabChange = (next: PurchasesTab) => {
    setTab(next);
    setActiveSubTab(next);
  };

  const loadData = useCallback(async () => {
    try {
      const [pRes, rRes, ssRes, sRes, prodRes, wRes] = await Promise.all([
        apiFetch<{ purchases: Purchase[] }>('/api/purchases'),
        apiFetch<{ returns: PurchaseReturnRow[] }>('/api/purchases/returns'),
        apiFetch<{ summaries: SupplierPurchasesSummary[] }>('/api/purchases/supplier-summary'),
        apiFetch<{ suppliers: Supplier[] }>('/api/suppliers'),
        apiFetch<{ products: Product[] }>('/api/products'),
        apiFetch<{ warehouses: Warehouse[] }>('/api/warehouses'),
      ]);
      setPurchases(pRes.purchases);
      setReturns(rRes.returns);
      setSupplierSummaries(ssRes.summaries);
      setSuppliers(sRes.suppliers);
      setProducts(prodRes.products);
      setWarehouses(wRes.warehouses);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load purchases', 'error');
    }
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const addLineItem = () => {
    if (products.length === 0) return;
    const p = products[0];
    setLineItems((prev) => [...prev, { product_id: p.id, quantity: 1, purchase_price: p.purchase_price, vat_rate: p.vat_rate }]);
  };

  const subtotal = lineItems.reduce((s, l) => s + l.quantity * l.purchase_price, 0);
  const totalVat = lineItems.reduce((s, l) => s + l.quantity * l.purchase_price * (l.vat_rate / 100), 0);
  const grandTotal = Math.max(0, Math.round((subtotal - discount + totalVat) * 100) / 100);

  const submitPurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (lineItems.length === 0) {
      showToast('Add at least one product', 'error');
      return;
    }
    try {
      const paid = paymentMethod === 'Credit' ? 0 : paidAmount === '' ? grandTotal : Number(paidAmount);
      const res = await apiFetch<{ purchase_number: string }>('/api/purchases', {
        method: 'POST',
        body: JSON.stringify({
          supplier_id: supplierId,
          warehouse_id: warehouseId,
          currency,
          purchase_date: purchaseDate,
          supplier_invoice_no: supplierInvoiceNo,
          discount_amount: discount,
          paid_amount: paid,
          payment_method: paymentMethod,
          notes,
          items: lineItems,
        }),
      });
      showToast(`Created Purchase ${res.purchase_number}`, 'success');
      setCreateOpen(false);
      setLineItems([]);
      setPaidAmount('');
      setSupplierInvoiceNo('');
      setNotes('');
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save purchase', 'error');
    }
  };

  const downloadVoucher = async (purchaseId: number) => {
    try {
      const detail = await apiFetch<{ purchase: Purchase; items: PurchaseItemRow[] }>(`/api/purchases/${purchaseId}`);
      generatePurchaseVoucherPdf(detail.purchase, detail.items, settings);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to generate voucher', 'error');
    }
  };

  const openReturn = async (purchaseId: number) => {
    try {
      const detail = await apiFetch<{ purchase: Purchase; items: PurchaseItemRow[] }>(`/api/purchases/${purchaseId}`);
      const q: Record<number, number> = {};
      for (const i of detail.items) q[i.id] = 0;
      setReturnQtys(q);
      setReturnReason('');
      setReturnStatus('Credited');
      setReturnModal(detail);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load purchase items', 'error');
    }
  };

  const submitReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnModal) return;
    const items = Object.entries(returnQtys)
      .filter(([, qty]) => qty > 0)
      .map(([purchase_item_id, quantity]) => ({ purchase_item_id: Number(purchase_item_id), quantity }));
    if (items.length === 0) return;
    try {
      const res = await apiFetch<{ return_number: string }>('/api/purchases/returns', {
        method: 'POST',
        body: JSON.stringify({
          purchase_id: returnModal.purchase.id,
          items,
          reason: returnReason,
          status: returnStatus,
          notes: returnReason,
        }),
      });
      showToast(`Created purchase return ${res.return_number}`, 'success');
      setReturnModal(null);
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Return failed', 'error');
    }
  };

  const submitSupplierPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModal) return;
    try {
      await apiFetch(`/api/suppliers/${payModal.supplier_id}/pay`, {
        method: 'POST',
        body: JSON.stringify({
          purchase_id: payModal.id,
          amount: Number(payAmt),
          currency: payModal.currency,
          payment_method: payMethod,
          notes: `Payment on ${payModal.purchase_number}`,
        }),
      });
      showToast('Supplier payment recorded', 'success');
      setPayModal(null);
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Payment failed', 'error');
    }
  };

  const viewSupplierHistory = async (supplierIdVal: number, supplierName: string) => {
    try {
      const res = await apiFetch<{ purchases: Array<Record<string, unknown>>; payments: Array<Record<string, unknown>> }>(
        `/api/suppliers/${supplierIdVal}/statement`
      );
      setHistoryModal({ supplierName, purchases: res.purchases, payments: res.payments });
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to load supplier purchase history', 'error');
    }
  };

  return (
    <div className="space-y-5">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 erp-card flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => handleTabChange('list')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'list' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('purchases')} ({purchases.length})
          </button>
          <button
            onClick={() => handleTabChange('returns')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'returns' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('purchaseReturns')} ({returns.length})
          </button>
          <button
            onClick={() => handleTabChange('supplier_purchases')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'supplier_purchases' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('supplierPurchases')} ({supplierSummaries.length})
          </button>
        </div>

        {hasPermission('purchases.create') && (
          <button
            onClick={() => {
              if (suppliers.length > 0) setSupplierId(suppliers[0].id);
              if (warehouses.length > 0) setWarehouseId(warehouses[0].id);
              setLineItems(products[0] ? [{ product_id: products[0].id, quantity: 1, purchase_price: products[0].purchase_price, vat_rate: products[0].vat_rate }] : []);
              setCreateOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            {t('newPurchase')}
          </button>
        )}
      </div>

      {tab === 'list' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Purchase #</th>
                  <th className="text-left px-4 py-3 font-medium">{t('supplierInvoiceNo')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('supplier')}</th>
                  <th className="text-left px-4 py-3 font-medium">Items ({t('quantity')})</th>
                  <th className="text-right px-4 py-3 font-medium">{t('discount')} / {t('vat')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('total')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('amountPaid')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('remainingBalance')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {purchases.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="py-10 text-center text-slate-500">
                      {t('noRecords')}
                    </td>
                  </tr>
                ) : (
                  purchases.map((p) => (
                    <tr key={p.id}>
                      <td className="px-4 py-3 font-mono-num font-semibold">{p.purchase_number}</td>
                      <td className="px-4 py-3 font-mono-num text-slate-500">{p.supplier_invoice_no || '-'}</td>
                      <td className="px-4 py-3 font-mono-num text-slate-500">{p.purchase_date}</td>
                      <td className="px-4 py-3">{p.supplier_name || '-'}</td>
                      <td className="px-4 py-3 max-w-[200px]">
                        <div className="truncate text-slate-700 dark:text-slate-200" title={p.items_summary || ''}>
                          {p.items_summary || '-'}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono-num">Qty: {p.total_quantity ?? 0} · {p.created_by}</div>
                      </td>
                      <td className="px-4 py-3 text-right font-mono-num text-[11px] text-slate-500">
                        -{formatMoney(p.discount_amount, p.currency)} / +{formatMoney(p.vat_amount, p.currency)}
                      </td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold">{formatMoney(p.grand_total, p.currency)}</td>
                      <td className="px-4 py-3 text-right font-mono-num">{formatMoney(p.paid_amount, p.currency)}</td>
                      <td className="px-4 py-3 text-right font-mono-num text-amber-600">{formatMoney(p.balance_amount, p.currency)}</td>
                      <td className="px-4 py-3">{p.status}</td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => downloadVoucher(p.id)}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                            title="Download Purchase Voucher PDF"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          {p.balance_amount > 0.01 && (
                            <button
                              onClick={() => {
                                setPayModal(p);
                                setPayAmt(String(p.balance_amount));
                              }}
                              className="p-1.5 rounded-lg border border-[#E2E8F0] dark:border-slate-700 text-[#2563EB] dark:text-[#06B6D4] hover:bg-[#2563EB]/10"
                              title={t('recordPayment')}
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {hasPermission('purchases.return') && p.status !== 'Returned' && (
                            <button
                              onClick={() => openReturn(p.id)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-amber-600"
                              title={t('purchaseReturn')}
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'returns' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Return #</th>
                  <th className="text-left px-4 py-3 font-medium">Purchase #</th>
                  <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('supplier')}</th>
                  <th className="text-left px-4 py-3 font-medium">Returned Items</th>
                  <th className="text-left px-4 py-3 font-medium">Reason</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  <th className="text-right px-4 py-3 font-medium">Total Refund</th>
                  <th className="text-left px-4 py-3 font-medium">Created By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {returns.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-10 text-center text-slate-500">
                      {t('noRecords')}
                    </td>
                  </tr>
                ) : (
                  returns.map((r) => (
                    <tr key={r.id}>
                      <td className="px-4 py-3 font-mono-num font-semibold">{r.return_number}</td>
                      <td className="px-4 py-3 font-mono-num">{r.purchase_number}</td>
                      <td className="px-4 py-3 font-mono-num text-slate-500">{r.return_date}</td>
                      <td className="px-4 py-3">{r.supplier_name || '-'}</td>
                      <td className="px-4 py-3 max-w-[180px] truncate" title={r.items_summary || ''}>
                        {r.items_summary || '-'} ({r.total_quantity ?? 0})
                      </td>
                      <td className="px-4 py-3 text-slate-500">{r.reason || '-'}</td>
                      <td className="px-4 py-3 font-medium text-emerald-700 dark:text-emerald-400">{r.status || 'Credited'}</td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold">{formatMoney(r.total_refund, 'ETB')}</td>
                      <td className="px-4 py-3 text-slate-500">{r.created_by}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'supplier_purchases' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Code</th>
                  <th className="text-left px-4 py-3 font-medium">{t('supplier')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('phone')}</th>
                  <th className="text-right px-4 py-3 font-medium">Orders</th>
                  <th className="text-right px-4 py-3 font-medium">{t('totalPurchases')} (ETB)</th>
                  <th className="text-right px-4 py-3 font-medium">{t('amountPaid')} (ETB)</th>
                  <th className="text-right px-4 py-3 font-medium">{t('remainingBalance')} (ETB)</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {supplierSummaries.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-slate-500">{t('noRecords')}</td>
                  </tr>
                ) : (
                  supplierSummaries.map((ss) => (
                    <tr key={ss.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3 font-mono-num text-slate-500">{ss.supplier_code || `#${ss.id}`}</td>
                      <td className="px-4 py-3">
                        <div className="font-semibold">{ss.business_name}</div>
                        <div className="text-[11px] text-slate-500">{ss.contact_person}</div>
                      </td>
                      <td className="px-4 py-3 text-slate-500">{ss.phone || '-'}</td>
                      <td className="px-4 py-3 text-right font-mono-num">{ss.purchase_count}</td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold">{formatMoney(ss.total_purchases_etb, 'ETB')}</td>
                      <td className="px-4 py-3 text-right font-mono-num text-emerald-600">{formatMoney(ss.total_paid_etb, 'ETB')}</td>
                      <td className={`px-4 py-3 text-right font-mono-num font-semibold ${ss.outstanding_balance > 0 ? 'text-amber-600' : ''}`}>
                        {formatMoney(ss.outstanding_balance, 'ETB')}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => viewSupplierHistory(ss.id, ss.business_name)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <History className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />
                          History
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* New Purchase Modal */}
      {createOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form
            onSubmit={submitPurchase}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-3xl p-5 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">{t('newPurchase')}</h3>
              <button type="button" onClick={() => setCreateOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs">
              <div>
                <label className="block font-medium mb-1">{t('supplier')}</label>
                <select
                  value={supplierId}
                  onChange={(e) => setSupplierId(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.business_name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">{t('supplierInvoiceNo')}</label>
                <input
                  type="text"
                  value={supplierInvoiceNo}
                  onChange={(e) => setSupplierInvoiceNo(e.target.value)}
                  placeholder="SUP-INV-001"
                  className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('warehouses')}</label>
                <select
                  value={warehouseId}
                  onChange={(e) => setWarehouseId(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">{t('currency')}</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  {currencies.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.code}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">{t('date')}</label>
                <input
                  type="date"
                  value={purchaseDate}
                  onChange={(e) => setPurchaseDate(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold">Purchase Items</span>
                <button
                  type="button"
                  onClick={addLineItem}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-xs font-medium"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Row
                </button>
              </div>

              <div className="space-y-2">
                {lineItems.map((li, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-2 items-center text-xs">
                    <select
                      value={li.product_id}
                      onChange={(e) => {
                        const pid = Number(e.target.value);
                        const prod = products.find((x) => x.id === pid);
                        setLineItems((prev) =>
                          prev.map((row, i) =>
                            i === idx
                              ? { ...row, product_id: pid, purchase_price: prod?.purchase_price || 0, vat_rate: prod?.vat_rate ?? 15 }
                              : row
                          )
                        );
                      }}
                      className="col-span-5 px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                    >
                      {products.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.sku})
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      min={1}
                      value={li.quantity}
                      onChange={(e) => {
                        const q = Math.max(1, Number(e.target.value) || 1);
                        setLineItems((prev) => prev.map((r, i) => (i === idx ? { ...r, quantity: q } : r)));
                      }}
                      placeholder="Qty"
                      className="col-span-2 px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                    />
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      value={li.purchase_price}
                      onChange={(e) => {
                        const p = Math.max(0, Number(e.target.value) || 0);
                        setLineItems((prev) => prev.map((r, i) => (i === idx ? { ...r, purchase_price: p } : r)));
                      }}
                      placeholder="Cost"
                      className="col-span-2 px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                    />
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      value={li.vat_rate}
                      onChange={(e) => {
                        const v = Math.max(0, Number(e.target.value) || 0);
                        setLineItems((prev) => prev.map((r, i) => (i === idx ? { ...r, vat_rate: v } : r)));
                      }}
                      placeholder="VAT %"
                      className="col-span-2 px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                    />
                    <button
                      type="button"
                      onClick={() => setLineItems((prev) => prev.filter((_, i) => i !== idx))}
                      className="col-span-1 text-red-500 flex justify-center"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-2 border-t border-slate-200 dark:border-slate-800">
              <div>
                <label className="block font-medium mb-1">{t('discount')}</label>
                <input
                  type="number"
                  min={0}
                  step="0.01"
                  value={discount}
                  onChange={(e) => setDiscount(Number(e.target.value) || 0)}
                  className="w-full px-2.5 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('paymentMethod')}</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="Cash">{t('cash')}</option>
                  <option value="Card">{t('cardPayment')}</option>
                  <option value="Bank Transfer">{t('bankTransfer')}</option>
                  <option value="Mobile Money">{t('mobileMoney')}</option>
                  <option value="Credit">{t('creditDebt')}</option>
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">{t('amountPaid')}</label>
                <input
                  type="number"
                  min={0}
                  step="0.01"
                  disabled={paymentMethod === 'Credit'}
                  placeholder={grandTotal.toFixed(2)}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-2">
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Notes..."
                className="w-64 px-2.5 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent"
              />
              <div className="text-right font-mono-num">
                <div className="text-slate-500">
                  {t('subtotal')}: {formatMoney(subtotal, currency)} · {t('vat')}: {formatMoney(totalVat, currency)}
                </div>
                <div className="text-base font-bold text-[#2563EB] dark:text-[#06B6D4]">
                  {t('grandTotal')}: {formatMoney(grandTotal, currency)}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setCreateOpen(false)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Purchase Return Modal */}
      {returnModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form
            onSubmit={submitReturn}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-lg p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">
                {t('purchaseReturn')} · {returnModal.purchase.purchase_number}
              </h3>
              <button type="button" onClick={() => setReturnModal(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs max-h-64 overflow-y-auto">
              {returnModal.items.map((item) => {
                const maxRet = item.quantity - item.returned_qty;
                return (
                  <div key={item.id} className="py-2 flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{item.product_name}</div>
                      <div className="text-slate-500 font-mono-num">Purchased: {item.quantity} · Available: {maxRet}</div>
                    </div>
                    <input
                      type="number"
                      min={0}
                      max={maxRet}
                      value={returnQtys[item.id] || 0}
                      onChange={(e) =>
                        setReturnQtys((prev) => ({
                          ...prev,
                          [item.id]: Math.min(maxRet, Math.max(0, Number(e.target.value) || 0)),
                        }))
                      }
                      className="w-20 text-right px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                    />
                  </div>
                );
              })}
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-medium mb-1">Return Reason</label>
                <input
                  type="text"
                  required
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  placeholder="Damaged / Expired / Excess..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">{t('status')}</label>
                <select
                  value={returnStatus}
                  onChange={(e) => setReturnStatus(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="Credited">Credited</option>
                  <option value="Refunded">Refunded</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setReturnModal(null)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Supplier Purchase History Modal */}
      {historyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-2xl p-5 space-y-4 max-h-[85vh] overflow-y-auto text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">{t('supplierPurchases')} · {historyModal.supplierName}</h3>
              <button onClick={() => setHistoryModal(null)}><X className="w-4 h-4" /></button>
            </div>
            <div>
              <div className="font-semibold mb-2">Purchase Orders ({historyModal.purchases.length})</div>
              <table className="w-full border border-slate-200 dark:border-slate-800">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500">
                    <th className="text-left p-2">Purchase #</th>
                    <th className="text-left p-2">Supplier Inv #</th>
                    <th className="text-left p-2">{t('date')}</th>
                    <th className="text-right p-2">{t('total')}</th>
                    <th className="text-right p-2">{t('amountPaid')}</th>
                    <th className="text-right p-2">{t('remainingBalance')}</th>
                    <th className="text-left p-2">{t('status')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {historyModal.purchases.map((r, i) => (
                    <tr key={i}>
                      <td className="p-2 font-mono-num">{String(r.purchase_number)}</td>
                      <td className="p-2 font-mono-num">{String(r.supplier_invoice_no || '-')}</td>
                      <td className="p-2 font-mono-num">{String(r.purchase_date)}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.grand_total), String(r.currency))}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.paid_amount), String(r.currency))}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.balance_amount), String(r.currency))}</td>
                      <td className="p-2">{String(r.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div>
              <div className="font-semibold mb-2">Payment History ({historyModal.payments.length})</div>
              <table className="w-full border border-slate-200 dark:border-slate-800">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500">
                    <th className="text-left p-2">{t('date')}</th>
                    <th className="text-left p-2">Method</th>
                    <th className="text-right p-2">Amount</th>
                    <th className="text-left p-2">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {historyModal.payments.map((p, i) => (
                    <tr key={i}>
                      <td className="p-2 font-mono-num">{String(p.created_at)}</td>
                      <td className="p-2">{String(p.payment_method)}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(p.amount), String(p.currency))}</td>
                      <td className="p-2 text-slate-500">{String(p.notes || '-')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Supplier Payment Modal */}
      {payModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form
            onSubmit={submitSupplierPayment}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-sm p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">{t('recordPayment')} · {payModal.purchase_number}</h3>
              <button type="button" onClick={() => setPayModal(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-slate-500">
              Balance: <span className="font-mono-num font-semibold">{formatMoney(payModal.balance_amount, payModal.currency)}</span>
            </div>
            <input
              type="number"
              step="0.01"
              min={0.01}
              max={payModal.balance_amount}
              required
              value={payAmt}
              onChange={(e) => setPayAmt(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-sm font-mono-num"
            />
            <select
              value={payMethod}
              onChange={(e) => setPayMethod(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="Cash">{t('cash')}</option>
              <option value="Card">{t('cardPayment')}</option>
              <option value="Bank Transfer">{t('bankTransfer')}</option>
              <option value="Mobile Money">{t('mobileMoney')}</option>
            </select>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setPayModal(null)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
