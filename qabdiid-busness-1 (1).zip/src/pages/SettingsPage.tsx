import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Download, Upload, Save, Image as ImageIcon, Package, RotateCcw } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { compressImageFile } from '../utils/image.ts';
import { Currency, Product } from '../types/erp.ts';

interface RateHistoryRow {
  id: number;
  currency_code: string;
  rate_to_etb: number;
  changed_by: string;
  changed_at: string;
}

export function SettingsPage() {
  const { t, settings, refreshSettings, hasPermission, showToast } = useApp();
  const [form, setForm] = useState({
    business_name: 'QABDIID BUSNESS 1',
    system_name: 'QABDIID BUSNESS 1',
    logo_url: '',
    favicon_url: '',
    phone: '',
    email: '',
    website: '',
    address: '',
    tin: '',
    vat_rate: '15',
    allow_negative_stock: false,
    default_currency: 'ETB',
    default_language: 'en',
    receipt_header: '',
    receipt_footer: '',
    sale_prefix: 'SAL-',
    purchase_prefix: 'PUR-',
    return_prefix: 'RET-',
    min_password_length: '6',
    require_2fa: false,
  });

  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [rateHistory, setRateHistory] = useState<RateHistoryRow[]>([]);
  const [usdRate, setUsdRate] = useState('125');
  const [products, setProducts] = useState<Product[]>([]);
  const [uploadingProductId, setUploadingProductId] = useState<number | null>(null);
  const restoreInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const faviconInputRef = useRef<HTMLInputElement>(null);

  const loadRates = useCallback(async () => {
    try {
      const [cRes, pRes] = await Promise.all([
        apiFetch<{ currencies: Currency[]; history: RateHistoryRow[] }>('/api/currencies'),
        apiFetch<{ products: Product[] }>('/api/products'),
      ]);
      setCurrencies(cRes.currencies);
      setRateHistory(cRes.history);
      setProducts(pRes.products);
      const usd = cRes.currencies.find((c) => c.code === 'USD');
      if (usd) setUsdRate(String(usd.exchange_rate_to_etb));
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (settings) {
      setForm({
        business_name: settings.business_name,
        system_name: settings.system_name,
        logo_url: settings.logo_url || '',
        favicon_url: settings.favicon_url || '',
        phone: settings.phone || '',
        email: settings.email || '',
        website: settings.website || '',
        address: settings.address || '',
        tin: settings.tin || '',
        vat_rate: String(settings.vat_rate),
        allow_negative_stock: settings.allow_negative_stock === 1,
        default_currency: settings.default_currency,
        default_language: settings.default_language,
        receipt_header: settings.receipt_header || '',
        receipt_footer: settings.receipt_footer || '',
        sale_prefix: settings.sale_prefix || 'SAL-',
        purchase_prefix: settings.purchase_prefix || 'PUR-',
        return_prefix: settings.return_prefix || 'RET-',
        min_password_length: String(settings.min_password_length || 6),
        require_2fa: settings.require_2fa === 1,
      });
    }
    loadRates();
  }, [settings, loadRates]);

  const handleLogoFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 480, 0.85);
      setForm((prev) => ({ ...prev, logo_url: dataUrl }));
      showToast('Logo loaded — click Save to apply across Store & Receipts', 'success');
    } catch {
      showToast('Failed to process logo image', 'error');
    }
    e.target.value = '';
  };

  const handleFaviconFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 128, 0.9);
      setForm((prev) => ({ ...prev, favicon_url: dataUrl }));
      showToast('Favicon loaded — click Save to apply', 'success');
    } catch {
      showToast('Failed to process favicon image', 'error');
    }
    e.target.value = '';
  };

  const handleProductImageUpload = async (product: Product, file: File) => {
    setUploadingProductId(product.id);
    try {
      const dataUrl = await compressImageFile(file, 640, 0.82);
      await apiFetch(`/api/products/${product.id}`, {
        method: 'PUT',
        body: JSON.stringify({ image_url: dataUrl }),
      });
      await loadRates();
      showToast(`Updated image for ${product.name}`, 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to upload product image', 'error');
    } finally {
      setUploadingProductId(null);
    }
  };

  const handleProductImageUrlSave = async (product: Product, url: string) => {
    setUploadingProductId(product.id);
    try {
      await apiFetch(`/api/products/${product.id}`, {
        method: 'PUT',
        body: JSON.stringify({ image_url: url }),
      });
      await loadRates();
      showToast(`Saved image for ${product.name}`, 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save product image', 'error');
    } finally {
      setUploadingProductId(null);
    }
  };

  const saveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/settings', {
        method: 'PUT',
        body: JSON.stringify({
          ...form,
          vat_rate: Number(form.vat_rate),
          min_password_length: Number(form.min_password_length),
        }),
      });
      await refreshSettings();
      showToast('Settings & Branding saved', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to save settings', 'error');
    }
  };

  const updateUsdRate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/currencies/USD', {
        method: 'PUT',
        body: JSON.stringify({ exchange_rate_to_etb: Number(usdRate) }),
      });
      await Promise.all([refreshSettings(), loadRates()]);
      showToast('USD exchange rate updated', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to update exchange rate', 'error');
    }
  };

  const downloadBackup = async () => {
    try {
      const data = await apiFetch('/api/backup/export');
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `qabdiid_erp_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Database backup downloaded', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Backup failed', 'error');
    }
  };

  const restoreBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const json = JSON.parse(text);
      await apiFetch('/api/backup/restore', { method: 'POST', body: JSON.stringify(json) });
      showToast('Database restored successfully! Reloading...', 'success');
      setTimeout(() => window.location.reload(), 800);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Invalid backup file', 'error');
    }
    e.target.value = '';
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Business & Receipt Branding Settings */}
      <form onSubmit={saveSettings} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-6 space-y-5 text-xs erp-card">
        <div className="flex items-center justify-between border-b border-[#E2E8F0] dark:border-slate-800 pb-3">
          <h2 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Business & Receipt Branding</h2>
          <button type="submit" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold shadow-sm transition-colors">
            <Save className="w-3.5 h-3.5" /> {t('save')}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block font-medium mb-1">Business Name</label>
            <input type="text" required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
          </div>
          <div>
            <label className="block font-medium mb-1">System Name</label>
            <input type="text" required value={form.system_name} onChange={(e) => setForm({ ...form, system_name: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
          </div>
          <div className="sm:col-span-2 lg:col-span-3 p-4 rounded-2xl border border-[#E2E8F0] dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#111827]/70">
            <label className="block font-semibold mb-2 text-[#0B1F4D] dark:text-[#F8FAFC]">{t('storeLogo')}</label>
            <div className="flex flex-wrap items-center gap-4">
              <div className="w-20 h-20 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-white dark:bg-[#161F33] overflow-hidden flex items-center justify-center shrink-0">
                {form.logo_url ? (
                  <img src={form.logo_url} alt={form.business_name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  <ImageIcon className="w-7 h-7 text-slate-400" />
                )}
              </div>
              <div className="flex-1 min-w-[220px] space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <input ref={logoInputRef} type="file" accept="image/*" onChange={handleLogoFile} className="hidden" />
                  <button
                    type="button"
                    onClick={() => logoInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" /> {t('uploadLogo')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm((prev) => ({ ...prev, logo_url: '/src/assets/images/qabdiid_brand_mark_1794940828806.jpg' }))}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Default Logo
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="Or paste store logo image URL..."
                  value={form.logo_url}
                  onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-white dark:bg-[#161F33] font-mono-num text-[11px]"
                />
              </div>
            </div>
          </div>
          <div className="sm:col-span-2 lg:col-span-3 p-4 rounded-2xl border border-[#E2E8F0] dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#111827]/70">
            <label className="block font-semibold mb-2 text-[#0B1F4D] dark:text-[#F8FAFC]">{t('favicon')}</label>
            <div className="flex flex-wrap items-center gap-4">
              <div className="w-12 h-12 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-white dark:bg-[#161F33] overflow-hidden flex items-center justify-center shrink-0">
                {form.favicon_url || form.logo_url ? (
                  <img src={form.favicon_url || form.logo_url} alt="Favicon" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  <ImageIcon className="w-5 h-5 text-slate-400" />
                )}
              </div>
              <div className="flex-1 min-w-[220px] space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <input ref={faviconInputRef} type="file" accept="image/*" onChange={handleFaviconFile} className="hidden" />
                  <button
                    type="button"
                    onClick={() => faviconInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" /> {t('uploadFavicon')}
                  </button>
                  {form.favicon_url && (
                    <button
                      type="button"
                      onClick={() => setForm((prev) => ({ ...prev, favicon_url: '' }))}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 transition-colors"
                    >
                      Clear Favicon
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="Or paste browser favicon URL..."
                  value={form.favicon_url}
                  onChange={(e) => setForm({ ...form, favicon_url: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-white dark:bg-[#161F33] font-mono-num text-[11px]"
                />
              </div>
            </div>
          </div>
          <div>
            <label className="block font-medium mb-1">Phone</label>
            <input type="text" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent" />
          </div>
          <div>
            <label className="block font-medium mb-1">Email</label>
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent" />
          </div>
          <div>
            <label className="block font-medium mb-1">Website</label>
            <input type="text" value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent" />
          </div>
          <div className="sm:col-span-2">
            <label className="block font-medium mb-1">Address</label>
            <input type="text" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent" />
          </div>
          <div>
            <label className="block font-medium mb-1">Tax ID (TIN)</label>
            <input type="text" value={form.tin} onChange={(e) => setForm({ ...form, tin: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num" />
          </div>
          <div>
            <label className="block font-medium mb-1">Default VAT (%)</label>
            <input type="number" step="0.1" value={form.vat_rate} onChange={(e) => setForm({ ...form, vat_rate: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num" />
          </div>
          <div>
            <label className="block font-medium mb-1">Sale Prefix</label>
            <input type="text" value={form.sale_prefix} onChange={(e) => setForm({ ...form, sale_prefix: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num" />
          </div>
          <div>
            <label className="block font-medium mb-1">Purchase Prefix</label>
            <input type="text" value={form.purchase_prefix} onChange={(e) => setForm({ ...form, purchase_prefix: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num" />
          </div>
          <div>
            <label className="block font-medium mb-1">Return Prefix</label>
            <input type="text" value={form.return_prefix} onChange={(e) => setForm({ ...form, return_prefix: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num" />
          </div>
          <div>
            <label className="block font-medium mb-1">Min Password Length</label>
            <input type="number" min={6} value={form.min_password_length} onChange={(e) => setForm({ ...form, min_password_length: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num" />
          </div>
          <div className="sm:col-span-2 lg:col-span-3">
            <label className="block font-medium mb-1">Receipt Thank You / Footer Message</label>
            <input type="text" value={form.receipt_footer} onChange={(e) => setForm({ ...form, receipt_footer: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent" />
          </div>
          <label className="inline-flex items-center gap-2 sm:col-span-2">
            <input type="checkbox" checked={form.allow_negative_stock} onChange={(e) => setForm({ ...form, allow_negative_stock: e.target.checked })} />
            <span>Allow Negative Stock in POS Sales</span>
          </label>
        </div>
      </form>

      {/* Product Images Manager in Settings */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-6 space-y-4 text-xs erp-card">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E2E8F0] dark:border-slate-800 pb-3">
          <div>
            <h2 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">{t('productImages')}</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-0.5">
              Upload or update photos for your POS and Catalog products directly from Settings.
            </p>
          </div>
          <span className="font-mono-num text-slate-500 dark:text-slate-400">{products.length} product(s)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((prod) => (
            <div
              key={prod.id}
              className="border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-3 flex items-center gap-3 bg-[#F8FAFC] dark:bg-[#111827]/70"
            >
              <div className="w-16 h-16 rounded-lg border border-[#E2E8F0] dark:border-slate-700 bg-white dark:bg-[#161F33] overflow-hidden flex items-center justify-center shrink-0">
                {prod.image_url ? (
                  <img src={prod.image_url} alt={prod.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  <Package className="w-6 h-6 text-slate-400" />
                )}
              </div>
              <div className="min-w-0 flex-1 space-y-1.5">
                <div className="font-semibold text-[#111827] dark:text-[#F8FAFC] truncate">{prod.name}</div>
                <div className="text-[11px] text-slate-500 font-mono-num">{prod.sku}</div>
                <div className="flex items-center gap-2">
                  <label className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium cursor-pointer transition-colors">
                    <Upload className="w-3 h-3" />
                    {uploadingProductId === prod.id ? t('loading') : t('uploadImage')}
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      disabled={uploadingProductId === prod.id}
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handleProductImageUpload(prod, f);
                        e.target.value = '';
                      }}
                    />
                  </label>
                  {prod.image_url && (
                    <button
                      type="button"
                      onClick={() => handleProductImageUrlSave(prod, '')}
                      className="text-[11px] text-red-600 hover:underline"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Currency & Exchange Rates */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
        <form onSubmit={updateUsdRate} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-4 erp-card">
          <h2 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">{t('exchangeRates')}</h2>
          <div className="space-y-2">
            {currencies.map((c) => (
              <div key={c.code} className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <span className="font-mono-num font-bold">{c.code}</span> · {c.name} ({c.symbol})
                </div>
                <span className="font-mono-num font-semibold text-[#2563EB] dark:text-[#06B6D4]">1 {c.code} = {c.exchange_rate_to_etb} ETB</span>
              </div>
            ))}
          </div>
          <div className="flex items-end gap-2">
            <div className="flex-1">
              <label className="block font-medium mb-1">1 USD = ? ETB</label>
              <input
                type="number"
                step="0.01"
                min={1}
                required
                value={usdRate}
                onChange={(e) => setUsdRate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
              />
            </div>
            <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
              Update Rate
            </button>
          </div>
        </form>

        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-3 erp-card">
          <h3 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Exchange Rate History</h3>
          <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {rateHistory.map((h) => (
              <div key={h.id} className="py-2 flex justify-between">
                <span>1 {h.currency_code} = <strong className="font-mono-num">{h.rate_to_etb} ETB</strong></span>
                <span className="text-slate-500 font-mono-num">{h.changed_by} · {h.changed_at}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Backup & Restore */}
      {hasPermission('backup.manage') && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4 text-xs erp-card">
          <div>
            <h2 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Database Backup & Restore</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-0.5">Export a complete encrypted-schema JSON snapshot of all ERP records, or restore from a saved backup file.</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={downloadBackup} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0B1F4D] hover:bg-[#132C66] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
              <Download className="w-3.5 h-3.5" /> {t('backupDatabase')}
            </button>
            <input ref={restoreInputRef} type="file" accept=".json" onChange={restoreBackup} className="hidden" />
            <button onClick={() => restoreInputRef.current?.click()} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 font-semibold hover:bg-[#F8FAFC] dark:hover:bg-slate-800 transition-colors">
              <Upload className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" /> {t('restoreDatabase')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
