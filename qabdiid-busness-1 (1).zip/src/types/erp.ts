export type Language = 'en' | 'so';
export type ThemeMode =
  | 'light-glass'
  | 'dark-glass'
  | 'aqua-glass'
  | 'emerald-glass'
  | 'crystal-glass'
  | 'golden-glass'
  | 'rose-glass'
  | 'ocean-glass';
export type CurrencyCode = string;

export interface User {
  id: number;
  first_name: string;
  last_name: string;
  username: string;
  email: string;
  phone: string;
  role: string;
  permissions: string[];
  is_active: number;
  two_factor_enabled: number;
  photo_url?: string;
  gender?: string;
  date_of_birth?: string;
  country?: string;
  address?: string;
  last_login_at?: string;
  created_at?: string;
}

export interface Settings {
  id: number;
  business_name: string;
  system_name: string;
  logo_url: string;
  favicon_url?: string;
  phone: string;
  email: string;
  website: string;
  address: string;
  tin: string;
  vat_rate: number;
  allow_negative_stock: number;
  default_currency: CurrencyCode;
  default_language: Language;
  receipt_header: string;
  receipt_footer: string;
  sale_prefix: string;
  purchase_prefix: string;
  return_prefix: string;
  min_password_length: number;
  require_2fa: number;
}

export interface Currency {
  code: CurrencyCode;
  name: string;
  symbol: string;
  decimal_places: number;
  is_default: number;
  exchange_rate_to_etb: number;
  updated_at: string;
}

export interface Category {
  id: number;
  name: string;
  description: string;
  created_at: string;
}

export interface UnitItem {
  id: number;
  unit_name: string;
  short_name: string;
  description: string;
  created_at: string;
}

export interface VatRateItem {
  id: number;
  name: string;
  percentage: number;
  vat_type: string;
  is_default: number;
  created_at: string;
}

export interface ExpenseCategoryItem {
  id: number;
  name: string;
  description: string;
  created_at: string;
}

export interface Warehouse {
  id: number;
  name: string;
  location: string;
  is_default: number;
}

export interface Product {
  id: number;
  product_code?: string;
  name: string;
  sku: string;
  barcode: string;
  category_id: number | null;
  category_name?: string;
  unit: string;
  purchase_price: number;
  selling_price: number;
  wholesale_price: number;
  vat_rate: number;
  current_stock: number;
  min_stock: number;
  warehouse_id: number;
  warehouse_name?: string;
  expiry_date: string;
  image_url: string;
  description: string;
  is_active: number;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: number;
  customer_code?: string;
  full_name: string;
  email?: string;
  phone: string;
  address: string;
  opening_balance: number;
  total_purchases: number;
  total_paid: number;
  outstanding_balance: number;
  created_at: string;
}

export interface Supplier {
  id: number;
  supplier_code?: string;
  business_name: string;
  contact_person: string;
  email?: string;
  phone: string;
  address: string;
  opening_balance: number;
  total_purchases: number;
  total_paid: number;
  outstanding_balance: number;
  created_at: string;
}

export interface OpeningBalanceEntry {
  id: number;
  party_type: 'customer' | 'supplier';
  party_id: number;
  party_name?: string;
  entry_type: 'Opening Balance' | 'Debit' | 'Credit';
  amount: number;
  entry_date: string;
  notes: string;
  created_by: string;
  created_at: string;
}

export interface Sale {
  id: number;
  invoice_number: string;
  sale_date: string;
  customer_id: number;
  customer_name?: string;
  customer_phone?: string;
  customer_address?: string;
  warehouse_id: number;
  currency: CurrencyCode;
  exchange_rate: number;
  subtotal: number;
  discount_amount: number;
  vat_amount: number;
  grand_total: number;
  paid_amount: number;
  balance_amount: number;
  payment_method: string;
  split_details_json: string;
  status: string;
  notes: string;
  items_summary?: string;
  total_quantity?: number;
  created_by: string;
  created_at: string;
}

export interface SaleItem {
  id: number;
  sale_id: number;
  product_id: number;
  product_name: string;
  sku: string;
  unit: string;
  quantity: number;
  returned_qty: number;
  unit_price: number;
  cost_price: number;
  discount_amount: number;
  vat_rate: number;
  vat_amount: number;
  subtotal: number;
}

export interface CustomerSalesSummary {
  id: number;
  customer_code: string;
  full_name: string;
  phone: string;
  email: string;
  opening_balance: number;
  total_purchases: number;
  total_paid: number;
  outstanding_balance: number;
  invoice_count: number;
  total_sales_etb: number;
  total_paid_etb: number;
  total_due_etb: number;
}

export interface Purchase {
  id: number;
  purchase_number: string;
  supplier_invoice_no?: string;
  purchase_date: string;
  supplier_id: number;
  supplier_name?: string;
  supplier_phone?: string;
  warehouse_id: number;
  currency: CurrencyCode;
  exchange_rate: number;
  subtotal: number;
  discount_amount: number;
  vat_amount: number;
  grand_total: number;
  paid_amount: number;
  balance_amount: number;
  payment_method: string;
  status: string;
  notes: string;
  items_summary?: string;
  total_quantity?: number;
  created_by: string;
  created_at: string;
}

export interface SupplierPurchasesSummary {
  id: number;
  supplier_code: string;
  business_name: string;
  contact_person: string;
  phone: string;
  email: string;
  opening_balance: number;
  total_purchases: number;
  total_paid: number;
  outstanding_balance: number;
  purchase_count: number;
  total_purchases_etb: number;
  total_paid_etb: number;
  total_due_etb: number;
}

export interface Expense {
  id: number;
  expense_code: string;
  title?: string;
  expense_date: string;
  category: string;
  description: string;
  amount: number;
  currency: CurrencyCode;
  exchange_rate: number;
  amount_etb: number;
  payment_method: string;
  receipt_ref: string;
  attachment_url?: string;
  created_by: string;
  created_at: string;
}

export interface Account {
  id: number;
  code: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  balance: number;
  is_system: number;
}

export interface NotificationItem {
  id: number;
  type: string;
  title_en: string;
  title_so: string;
  message_en: string;
  message_so: string;
  is_read: number;
  reference_type: string;
  reference_id: string;
  created_at: string;
}

export type PageKey =
  | 'dashboard'
  | 'pos'
  | 'sales'
  | 'purchases'
  | 'catalog'
  | 'inventory'
  | 'people'
  | 'debts'
  | 'expenses'
  | 'accounting'
  | 'currencies'
  | 'reports'
  | 'users'
  | 'settings'
  | 'profile';
