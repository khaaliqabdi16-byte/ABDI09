import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Currency, Language, NotificationItem, PageKey, Settings, ThemeMode, User } from '../types/erp.ts';
import { translations } from '../i18n/translations.ts';
import { apiFetch, getStoredToken, setStoredToken } from '../utils/api.ts';
import { LIQUID_THEME_MAP, normalizeTheme } from '../constants/themes.ts';

interface OfflineSalePayload {
  localId: string;
  createdAt: string;
  payload: Record<string, unknown>;
}

interface ToastMessage {
  id: number;
  type: 'success' | 'error';
  message: string;
}

interface AppContextValue {
  user: User | null;
  authLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  hasPermission: (perm: string) => boolean;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
  toggleTheme: () => void;
  activePage: PageKey;
  setActivePage: (page: PageKey) => void;
  activeSubTab: string;
  setActiveSubTab: (subTab: string) => void;
  navigateTo: (page: PageKey, subTab?: string) => void;
  settings: Settings | null;
  currencies: Currency[];
  refreshSettings: () => Promise<void>;
  notifications: NotificationItem[];
  unreadCount: number;
  refreshNotifications: () => Promise<void>;
  markNotificationRead: (id: number) => Promise<void>;
  markAllRead: () => Promise<void>;
  isOnline: boolean;
  offlineQueue: OfflineSalePayload[];
  queueOfflineSale: (payload: Record<string, unknown>) => void;
  syncOfflineSales: () => Promise<void>;
  showToast: (message: string, type?: 'success' | 'error') => void;
}

const OFFLINE_QUEUE_KEY = 'qabdiid_offline_sales';
const LANG_KEY = 'qabdiid_lang';
const THEME_KEY = 'qabdiid_theme';

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(LANG_KEY);
    return saved === 'so' ? 'so' : 'en';
  });
  const [theme, setTheme] = useState<ThemeMode>(() => {
    return normalizeTheme(localStorage.getItem(THEME_KEY));
  });
  const [activePage, setActivePageState] = useState<PageKey>('dashboard');
  const [activeSubTab, setActiveSubTab] = useState<string>('');
  const [settings, setSettings] = useState<Settings | null>(null);
  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOnline, setIsOnline] = useState(() => (typeof navigator !== 'undefined' ? navigator.onLine : true));
  const [offlineQueue, setOfflineQueue] = useState<OfflineSalePayload[]>(() => {
    try {
      const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 3800);
  }, []);

  useEffect(() => {
    const meta = LIQUID_THEME_MAP[theme] || LIQUID_THEME_MAP['light-glass'];
    document.documentElement.classList.toggle('dark', meta.isDark);
    document.documentElement.setAttribute('data-liquid-theme', meta.id);
    localStorage.setItem(THEME_KEY, meta.id);
  }, [theme]);

  useEffect(() => {
    const titleName = settings?.system_name || settings?.business_name || 'QABDIID BUSNESS 1';
    document.title = `${titleName} — POS & ERP Management System`;
    const iconHref = settings?.favicon_url || settings?.logo_url;
    if (iconHref) {
      let link = document.querySelector<HTMLLinkElement>("link[rel*='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = iconHref;
    }
  }, [settings?.system_name, settings?.business_name, settings?.favicon_url, settings?.logo_url]);

  const setActivePage = useCallback((page: PageKey) => {
    setActivePageState(page);
    setActiveSubTab('');
  }, []);

  const navigateTo = useCallback((page: PageKey, subTab: string = '') => {
    setActivePageState(page);
    setActiveSubTab(subTab);
  }, []);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(LANG_KEY, lang);
  }, []);

  const setThemeMode = useCallback((mode: ThemeMode) => {
    setTheme(normalizeTheme(mode));
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light-glass' ? 'dark-glass' : 'light-glass'));
  }, []);

  const t = useCallback(
    (key: string) => {
      return translations[language][key] ?? translations.en[key] ?? key;
    },
    [language]
  );

  const refreshSettings = useCallback(async () => {
    try {
      const [sRes, cRes] = await Promise.all([
        apiFetch<{ settings: Settings }>('/api/settings'),
        apiFetch<{ currencies: Currency[] }>('/api/currencies'),
      ]);
      setSettings(sRes.settings);
      setCurrencies(cRes.currencies);
    } catch {
      // Public bootstrap fallback
    }
  }, []);

  const refreshNotifications = useCallback(async () => {
    if (!getStoredToken()) return;
    try {
      const res = await apiFetch<{ notifications: NotificationItem[]; unread: number }>('/api/notifications');
      setNotifications(res.notifications);
      setUnreadCount(res.unread);
    } catch {
      // ignore if offline
    }
  }, []);

  const refreshUser = useCallback(async () => {
    const token = getStoredToken();
    if (!token) {
      setUser(null);
      try {
        const pub = await apiFetch<{ settings: Settings }>('/api/public/bootstrap');
        if (pub.settings) setSettings(pub.settings);
      } catch {
        // ignore if offline
      }
      setAuthLoading(false);
      return;
    }
    try {
      const res = await apiFetch<{ user: User }>('/api/auth/me');
      setUser(res.user);
      await Promise.all([refreshSettings(), refreshNotifications()]);
      if (res.user.role === 'Cashier') setActivePageState('pos');
    } catch {
      setStoredToken('');
      setUser(null);
    } finally {
      setAuthLoading(false);
    }
  }, [refreshNotifications, refreshSettings]);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  const syncOfflineSales = useCallback(async () => {
    if (!navigator.onLine || !user || offlineQueue.length === 0) return;
    const remaining: OfflineSalePayload[] = [];
    let syncedCount = 0;

    for (const item of offlineQueue) {
      try {
        await apiFetch('/api/sales', {
          method: 'POST',
          body: JSON.stringify(item.payload),
        });
        syncedCount++;
      } catch {
        remaining.push(item);
      }
    }

    setOfflineQueue(remaining);
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(remaining));
    if (syncedCount > 0) {
      showToast(`Synchronized ${syncedCount} offline sale(s) to database`, 'success');
      refreshNotifications();
    }
  }, [offlineQueue, refreshNotifications, showToast, user]);

  useEffect(() => {
    if (isOnline && user && offlineQueue.length > 0) {
      syncOfflineSales();
    }
  }, [isOnline, user, offlineQueue.length, syncOfflineSales]);

  const queueOfflineSale = useCallback((payload: Record<string, unknown>) => {
    const entry: OfflineSalePayload = {
      localId: `OFF-${Date.now()}`,
      createdAt: new Date().toISOString(),
      payload,
    };
    setOfflineQueue((prev) => {
      const updated = [...prev, entry];
      localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const login = useCallback(
    async (username: string, password: string) => {
      const res = await apiFetch<{ token: string; user: User }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
      setStoredToken(res.token);
      setUser(res.user);
      setActivePage(res.user.role === 'Cashier' ? 'pos' : 'dashboard');
      await Promise.all([refreshSettings(), refreshNotifications()]);
    },
    [refreshNotifications, refreshSettings]
  );

  const logout = useCallback(async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore network errors on sign out
    }
    setStoredToken('');
    setUser(null);
    setNotifications([]);
    setUnreadCount(0);
  }, []);

  const hasPermission = useCallback(
    (perm: string) => {
      if (!user) return false;
      if (user.role === 'Super Administrator' || user.role === 'Administrator') return true;
      return user.permissions.includes(perm);
    },
    [user]
  );

  const markNotificationRead = useCallback(
    async (id: number) => {
      await apiFetch(`/api/notifications/${id}/read`, { method: 'PUT' });
      await refreshNotifications();
    },
    [refreshNotifications]
  );

  const markAllRead = useCallback(async () => {
    await apiFetch('/api/notifications/read-all', { method: 'PUT' });
    await refreshNotifications();
  }, [refreshNotifications]);

  return (
    <AppContext.Provider
      value={{
        user,
        authLoading,
        login,
        logout,
        refreshUser,
        hasPermission,
        language,
        setLanguage,
        t,
        theme,
        setTheme: setThemeMode,
        toggleTheme,
        activePage,
        setActivePage,
        activeSubTab,
        setActiveSubTab,
        navigateTo,
        settings,
        currencies,
        refreshSettings,
        notifications,
        unreadCount,
        refreshNotifications,
        markNotificationRead,
        markAllRead,
        isOnline,
        offlineQueue,
        queueOfflineSale,
        syncOfflineSales,
        showToast,
      }}
    >
      {children}
      {toasts.length > 0 && (
        <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm no-print">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`px-4 py-3 rounded-xl border text-sm font-medium shadow-lg transition-all ${
                toast.type === 'error'
                  ? 'bg-red-50 border-red-200 text-red-800 dark:bg-red-950/95 dark:border-red-800 dark:text-red-200'
                  : 'bg-[#0B1F4D] border-[#2563EB]/40 text-[#F8FAFC] dark:bg-[#0B1F4D] dark:border-[#06B6D4]/50 dark:text-[#F8FAFC]'
              }`}
            >
              {toast.message}
            </div>
          ))}
        </div>
      )}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
