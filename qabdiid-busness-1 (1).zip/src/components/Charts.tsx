import React, { useState } from 'react';
import { formatMoney } from '../utils/export.ts';

interface BarSeriesItem {
  label: string;
  primary: number;
  secondary?: number;
}

export function DualBarChart({
  data,
  primaryLabel,
  secondaryLabel,
  emptyText,
}: {
  data: BarSeriesItem[];
  primaryLabel: string;
  secondaryLabel?: string;
  emptyText: string;
}) {
  const [hovered, setHovered] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="h-56 flex items-center justify-center text-sm text-slate-500 dark:text-slate-400">
        {emptyText}
      </div>
    );
  }

  const maxVal = Math.max(1, ...data.flatMap((d) => [Math.abs(d.primary), Math.abs(d.secondary || 0)]));

  return (
    <div className="w-full">
      <div className="flex items-center gap-4 mb-3 text-xs text-slate-600 dark:text-slate-300">
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-sm bg-[#2563EB] inline-block" />
          {primaryLabel}
        </span>
        {secondaryLabel && (
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#06B6D4] inline-block" />
            {secondaryLabel}
          </span>
        )}
      </div>

      <div className="relative h-56 flex items-end gap-1.5 pt-6 pb-6 border-b border-[#E2E8F0] dark:border-slate-800">
        {data.map((item, idx) => {
          const h1 = Math.max(4, Math.round((Math.max(0, item.primary) / maxVal) * 100));
          const h2 = item.secondary !== undefined ? Math.max(4, Math.round((Math.max(0, item.secondary) / maxVal) * 100)) : 0;
          return (
            <div
              key={item.label + idx}
              className="flex-1 h-full flex flex-col justify-end items-center group relative cursor-pointer"
              onMouseEnter={() => setHovered(idx)}
              onMouseLeave={() => setHovered(null)}
            >
              {hovered === idx && (
                <div className="absolute -top-2 z-20 px-2.5 py-1.5 rounded-lg bg-[#0B1F4D] border border-[#06B6D4]/40 text-white text-[11px] whitespace-nowrap shadow-lg pointer-events-none">
                  <div className="font-semibold mb-0.5 text-[#06B6D4]">{item.label}</div>
                  <div className="font-mono-num">
                    {primaryLabel}: {formatMoney(item.primary, 'ETB')}
                  </div>
                  {secondaryLabel && item.secondary !== undefined && (
                    <div className="font-mono-num text-slate-200">
                      {secondaryLabel}: {formatMoney(item.secondary, 'ETB')}
                    </div>
                  )}
                </div>
              )}
              <div className="w-full h-full flex items-end justify-center gap-1 px-0.5">
                <div
                  style={{ height: `${item.primary > 0 ? h1 : 2}%` }}
                  className={`w-full max-w-[18px] rounded-t transition-all ${
                    item.primary > 0 ? 'bg-[#2563EB] group-hover:bg-[#1D4ED8]' : 'bg-[#E2E8F0] dark:bg-slate-800'
                  }`}
                />
                {secondaryLabel && (
                  <div
                    style={{ height: `${item.secondary && item.secondary > 0 ? h2 : 2}%` }}
                    className={`w-full max-w-[18px] rounded-t transition-all ${
                      item.secondary && item.secondary > 0 ? 'bg-[#06B6D4] group-hover:bg-[#22D3EE]' : 'bg-[#E2E8F0] dark:bg-slate-800'
                    }`}
                  />
                )}
              </div>
              <span className="absolute -bottom-5 text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-full font-mono-num">
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function HorizontalDistributionList({
  items,
  emptyText,
}: {
  items: Array<{ label: string; value: number }>;
  emptyText: string;
}) {
  if (!items || items.length === 0) {
    return (
      <div className="py-10 text-center text-sm text-slate-500 dark:text-slate-400">{emptyText}</div>
    );
  }
  const total = items.reduce((s, i) => s + Math.max(0, i.value), 0) || 1;
  return (
    <div className="space-y-3">
      {items.map((item) => {
        const pct = Math.round((Math.max(0, item.value) / total) * 100);
        return (
          <div key={item.label} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-[#111827] dark:text-slate-200 truncate">{item.label}</span>
              <span className="font-mono-num text-slate-600 dark:text-slate-300">
                {formatMoney(item.value, 'ETB')} ({pct}%)
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-[#E2E8F0] dark:bg-slate-800 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-[#2563EB] to-[#06B6D4] rounded-full" style={{ width: `${pct}%` }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}
