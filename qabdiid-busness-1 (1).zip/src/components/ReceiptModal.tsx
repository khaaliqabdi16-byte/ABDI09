import React from 'react';
import { Printer, Download, X } from 'lucide-react';
import { Sale, SaleItem, Settings } from '../types/erp.ts';
import { formatMoney, generateSaleReceiptPdf } from '../utils/export.ts';
import { useApp } from '../context/AppContext.tsx';

export function ReceiptModal({
  sale,
  items,
  settings,
  onClose,
}: {
  sale: Sale;
  items: SaleItem[];
  settings: Settings | null;
  onClose: () => void;
}) {
  const { t } = useApp();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-xl">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#E2E8F0] dark:border-slate-800 no-print">
          <h3 className="font-semibold text-[#0B1F4D] dark:text-[#F8FAFC]">
            {sale.invoice_number}
          </h3>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-[#111827] dark:text-slate-200 hover:bg-[#F8FAFC] dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              <Printer className="w-3.5 h-3.5" />
              {t('printReceipt')}
            </button>
            <button
              onClick={() => generateSaleReceiptPdf(sale, items, settings)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-xl bg-[#2563EB] text-white hover:bg-[#1D4ED8] whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              {t('downloadPdf')}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label={t('close')}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[75vh] overflow-y-auto text-sm text-slate-800 dark:text-slate-200">
          <div className="text-center border-b border-dashed border-slate-300 dark:border-slate-700 pb-4 mb-4">
            {settings?.logo_url && (
              <img
                src={settings.logo_url}
                alt={settings.business_name}
                referrerPolicy="no-referrer"
                className="w-12 h-12 mx-auto mb-2 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
              />
            )}
            <div className="text-base font-bold text-slate-900 dark:text-white">
              {settings?.business_name || 'QABDIID BUSNESS 1'}
            </div>
            {settings?.address && <div className="text-xs text-slate-500 dark:text-slate-400">{settings.address}</div>}
            {settings?.phone && <div className="text-xs text-slate-500 dark:text-slate-400">{settings.phone}</div>}
            {settings?.tin && <div className="text-xs text-slate-500 dark:text-slate-400 font-mono-num">TIN: {settings.tin}</div>}
          </div>

          <div className="grid grid-cols-2 gap-y-1 text-xs mb-4">
            <span className="text-slate-500 dark:text-slate-400">Invoice:</span>
            <span className="text-right font-mono-num font-semibold">{sale.invoice_number}</span>
            <span className="text-slate-500 dark:text-slate-400">{t('date')}:</span>
            <span className="text-right font-mono-num">{sale.created_at}</span>
            <span className="text-slate-500 dark:text-slate-400">Cashier:</span>
            <span className="text-right">{sale.created_by}</span>
            <span className="text-slate-500 dark:text-slate-400">{t('customer')}:</span>
            <span className="text-right">{sale.customer_name || 'Walk-In Customer'}</span>
            <span className="text-slate-500 dark:text-slate-400">{t('paymentMethod')}:</span>
            <span className="text-right">{sale.payment_method} ({sale.status})</span>
          </div>

          <div className="border-t border-b border-dashed border-slate-300 dark:border-slate-700 py-3 mb-3">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <th className="text-left pb-1.5 font-medium">Item</th>
                  <th className="text-right pb-1.5 font-medium">{t('quantity')}</th>
                  <th className="text-right pb-1.5 font-medium">{t('price')}</th>
                  <th className="text-right pb-1.5 font-medium">{t('total')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {items.map((item) => (
                  <tr key={item.id}>
                    <td className="py-1.5 pr-2">
                      <div className="font-medium text-slate-900 dark:text-slate-100">{item.product_name}</div>
                      <div className="text-[11px] text-slate-500 font-mono-num">{item.sku}</div>
                    </td>
                    <td className="py-1.5 text-right font-mono-num">
                      {item.quantity} {item.unit}
                    </td>
                    <td className="py-1.5 text-right font-mono-num">{item.unit_price.toFixed(2)}</td>
                    <td className="py-1.5 text-right font-mono-num font-medium">{item.subtotal.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">{t('subtotal')}</span>
              <span className="font-mono-num">{formatMoney(sale.subtotal, sale.currency)}</span>
            </div>
            {sale.discount_amount > 0 && (
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">{t('discount')}</span>
                <span className="font-mono-num">-{formatMoney(sale.discount_amount, sale.currency)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">{t('vat')}</span>
              <span className="font-mono-num">{formatMoney(sale.vat_amount, sale.currency)}</span>
            </div>
            <div className="flex justify-between text-sm font-bold pt-2 border-t border-slate-200 dark:border-slate-800">
              <span>{t('grandTotal')}</span>
              <span className="font-mono-num text-[#2563EB] dark:text-[#06B6D4]">
                {formatMoney(sale.grand_total, sale.currency)}
              </span>
            </div>
            <div className="flex justify-between pt-1">
              <span className="text-slate-500 dark:text-slate-400">{t('amountPaid')}</span>
              <span className="font-mono-num">{formatMoney(sale.paid_amount, sale.currency)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">{t('remainingBalance')}</span>
              <span className="font-mono-num">{formatMoney(sale.balance_amount, sale.currency)}</span>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-500 dark:text-slate-400">
            {settings?.receipt_footer || 'Thank you for your business!'}
          </div>
        </div>
      </div>
    </div>
  );
}
