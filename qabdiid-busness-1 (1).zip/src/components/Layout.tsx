import React, { useState, useRef, useEffect } from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Receipt,
  Truck,
  Package,
  Boxes,
  Users,
  HandCoins,
  Wallet,
  BookOpen,
  FileBarChart2,
  ShieldCheck,
  Settings as SettingsIcon,
  UserCircle,
  Bell,
  LogOut,
  Menu,
  X,
  WifiOff,
  RefreshCw,
  Globe,
  Copy,
  Download,
  Check,
  ChevronDown,
  Tags,
  Ruler,
  Percent,
  AlertTriangle,
  RotateCcw,
  UserCheck,
  Building2,
  Scale,
  FolderTree,
  Coins,
  Palette,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { PageKey } from '../types/erp.ts';
import { apiFetch } from '../utils/api.ts';
import { LiquidThemeSelector } from './LiquidThemeSelector.tsx';

interface SubMenuItem {
  key: string;
  page: PageKey;
  subTab?: string;
  isDefaultSubTab?: boolean;
  labelKey: string;
  icon: React.ComponentType<{ className?: string }>;
  permission?: string;
}

interface NavGroup {
  key: string;
  labelKey: string;
  icon: React.ComponentType<{ className?: string }>;
  page?: PageKey;
  permission?: string;
  children?: SubMenuItem[];
}

const NAV_GROUPS: NavGroup[] = [
  { key: 'dashboard', page: 'dashboard', labelKey: 'dashboard', icon: LayoutDashboard, permission: 'dashboard.view' },
  {
    key: 'catalog',
    labelKey: 'catalog',
    icon: Package,
    children: [
      { key: 'catalog-products', page: 'catalog', subTab: 'products', isDefaultSubTab: true, labelKey: 'products', icon: Package, permission: 'catalog.view' },
      { key: 'catalog-categories', page: 'catalog', subTab: 'categories', labelKey: 'categories', icon: Tags, permission: 'catalog.view' },
      { key: 'catalog-units', page: 'catalog', subTab: 'units', labelKey: 'units', icon: Ruler, permission: 'catalog.view' },
      { key: 'catalog-vat', page: 'catalog', subTab: 'vat', labelKey: 'vatRates', icon: Percent, permission: 'catalog.view' },
    ],
  },
  {
    key: 'administration',
    labelKey: 'administration',
    icon: ShieldCheck,
    children: [
      { key: 'admin-users', page: 'users', labelKey: 'users', icon: ShieldCheck, permission: 'users.manage' },
      { key: 'admin-branding', page: 'settings', labelKey: 'branding', icon: Palette, permission: 'settings.manage' },
    ],
  },
  {
    key: 'inventory',
    labelKey: 'inventory',
    icon: Boxes,
    children: [
      { key: 'inventory-stock', page: 'inventory', subTab: 'stock', isDefaultSubTab: true, labelKey: 'inventory', icon: Boxes, permission: 'inventory.view' },
      { key: 'inventory-low', page: 'inventory', subTab: 'low_stock', labelKey: 'lowStock', icon: AlertTriangle, permission: 'inventory.view' },
    ],
  },
  {
    key: 'sales',
    labelKey: 'salesMain',
    icon: Receipt,
    children: [
      { key: 'sales-pos', page: 'pos', labelKey: 'pos', icon: ShoppingCart, permission: 'pos.use' },
      { key: 'sales-list', page: 'sales', subTab: 'sales', isDefaultSubTab: true, labelKey: 'salesMain', icon: Receipt, permission: 'sales.view' },
      { key: 'sales-returns', page: 'sales', subTab: 'returns', labelKey: 'salesReturns', icon: RotateCcw, permission: 'sales.view' },
      { key: 'sales-customers', page: 'sales', subTab: 'customer_sales', labelKey: 'customerSales', icon: UserCheck, permission: 'sales.view' },
    ],
  },
  {
    key: 'purchases',
    labelKey: 'purchases',
    icon: Truck,
    children: [
      { key: 'purchases-list', page: 'purchases', subTab: 'list', isDefaultSubTab: true, labelKey: 'purchases', icon: Truck, permission: 'purchases.view' },
      { key: 'purchases-returns', page: 'purchases', subTab: 'returns', labelKey: 'purchaseReturns', icon: RotateCcw, permission: 'purchases.view' },
      { key: 'purchases-suppliers', page: 'purchases', subTab: 'supplier_purchases', labelKey: 'supplierPurchases', icon: Building2, permission: 'purchases.view' },
    ],
  },
  {
    key: 'people',
    labelKey: 'people',
    icon: Users,
    children: [
      { key: 'people-customers', page: 'people', subTab: 'customers', isDefaultSubTab: true, labelKey: 'customers', icon: Users, permission: 'people.view' },
      { key: 'people-cust-ob', page: 'people', subTab: 'customer_opening', labelKey: 'customerOpeningBalance', icon: Scale, permission: 'people.view' },
      { key: 'people-suppliers', page: 'people', subTab: 'suppliers', labelKey: 'suppliers', icon: Building2, permission: 'people.view' },
      { key: 'people-sup-ob', page: 'people', subTab: 'supplier_opening', labelKey: 'supplierOpeningBalance', icon: Scale, permission: 'people.view' },
    ],
  },
  { key: 'debts', page: 'debts', labelKey: 'debts', icon: HandCoins, permission: 'people.view' },
  {
    key: 'expenses',
    labelKey: 'expenses',
    icon: Wallet,
    children: [
      { key: 'expenses-list', page: 'expenses', subTab: 'list', isDefaultSubTab: true, labelKey: 'expenses', icon: Wallet, permission: 'expenses.view' },
      { key: 'expenses-categories', page: 'expenses', subTab: 'categories', labelKey: 'expenseCategories', icon: FolderTree, permission: 'expenses.view' },
    ],
  },
  { key: 'accounting', page: 'accounting', labelKey: 'accounting', icon: BookOpen, permission: 'accounting.view' },
  { key: 'currencies', page: 'currencies', labelKey: 'currencies', icon: Coins, permission: 'settings.manage' },
  { key: 'reports', page: 'reports', labelKey: 'reports', icon: FileBarChart2, permission: 'reports.view' },
  { key: 'profile', page: 'profile', labelKey: 'profile', icon: UserCircle },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const {
    user,
    logout,
    hasPermission,
    language,
    setLanguage,
    t,
    activePage,
    setActivePage,
    activeSubTab,
    navigateTo,
    settings,
    notifications,
    unreadCount,
    markNotificationRead,
    markAllRead,
    isOnline,
    offlineQueue,
    syncOfflineSales,
    showToast,
  } = useApp();

  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

  const notifRef = useRef<HTMLDivElement>(null);
  const publishRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
      if (publishRef.current && !publishRef.current.contains(e.target as Node)) {
        setPublishOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  // Ensure the group owning activePage opens automatically when navigating via header/shortcuts
  useEffect(() => {
    const matchingGroup = NAV_GROUPS.find((g) => g.children?.some((c) => c.page === activePage));
    if (matchingGroup) {
      setExpandedGroups((prev) => (prev[matchingGroup.key] ? prev : { ...prev, [matchingGroup.key]: true }));
    }
  }, [activePage]);

  const toggleGroup = (key: string) => {
    setExpandedGroups((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const isSubActive = (child: SubMenuItem) => {
    if (activePage !== child.page) return false;
    if (!child.subTab) return true;
    return activeSubTab === child.subTab || (Boolean(child.isDefaultSubTab) && !activeSubTab);
  };

  const visibleGroups = NAV_GROUPS.map((group) => {
    if (!group.children) {
      return !group.permission || hasPermission(group.permission) ? group : null;
    }
    const visibleChildren = group.children.filter((c) => !c.permission || hasPermission(c.permission));
    return visibleChildren.length > 0 ? { ...group, children: visibleChildren } : null;
  }).filter((g): g is NavGroup => Boolean(g));

  const findActiveLabel = (): string => {
    for (const g of NAV_GROUPS) {
      if (g.page === activePage) return t(g.labelKey);
      if (g.children) {
        const sub = g.children.find((c) => isSubActive(c));
        if (sub) return t(sub.labelKey);
      }
    }
    return t('dashboard');
  };

  const activeNavLabel = findActiveLabel();
  const initials = `${user?.first_name?.[0] || 'A'}${user?.last_name?.[0] || ''}`.toUpperCase();

  const handleCopyLiveUrl = async () => {
    try {
      await navigator.clipboard.writeText(window.location.origin);
      setCopied(true);
      showToast(t('linkCopied'), 'success');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast(window.location.origin, 'success');
    }
  };

  const handleQuickBackup = async () => {
    try {
      const data = await apiFetch('/api/backup/export');
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `qabdiid_erp_snapshot_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setPublishOpen(false);
      showToast('Snapshot exported successfully', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Export failed', 'error');
    }
  };

  return (
    <div className="min-h-screen flex bg-transparent text-[#111827] dark:text-[#F8FAFC]">
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-[#0B1F4D]/60 backdrop-blur-xs lg:hidden no-print"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Executive Navy Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-40 w-64 shrink-0 bg-[#0B1F4D] border-r border-[#17306B] text-[#F8FAFC] flex flex-col transition-transform duration-200 erp-glass-sidebar no-print ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="h-16 px-4 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src={settings?.logo_url || '/src/assets/images/qabdiid_brand_mark_1794940828806.jpg'}
              alt="QABDIID BUSNESS 1"
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-xl object-cover border border-[#06B6D4]/40 shadow-sm shrink-0 bg-white"
            />
            <span className="font-display font-bold text-sm tracking-tight text-[#F8FAFC] truncate">
              {settings?.system_name || 'QABDIID BUSNESS 1'}
            </span>
          </div>
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-slate-300 hover:bg-white/10 hover:text-white"
            aria-label="Close navigation"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {visibleGroups.map((group) => {
            const Icon = group.icon;

            if (!group.children) {
              const active = activePage === group.page;
              return (
                <button
                  key={group.key}
                  onClick={() => {
                    if (group.page) setActivePage(group.page);
                    setMobileOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                    active
                      ? 'bg-[#2563EB] text-white shadow-[0_4px_14px_rgba(37,99,235,0.4)]'
                      : 'text-slate-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      active ? 'text-[#06B6D4] drop-shadow-[0_0_6px_rgba(6,182,212,0.7)]' : 'text-slate-300/90'
                    }`}
                  />
                  <span className="truncate">{t(group.labelKey)}</span>
                </button>
              );
            }

            const isExpanded = Boolean(expandedGroups[group.key]);
            const hasActiveChild = group.children.some((c) => isSubActive(c));

            return (
              <div key={group.key} className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => toggleGroup(group.key)}
                  aria-expanded={isExpanded}
                  className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                    hasActiveChild && !isExpanded
                      ? 'bg-[#2563EB]/30 text-white border border-[#2563EB]/40'
                      : hasActiveChild
                      ? 'bg-white/10 text-white'
                      : 'text-slate-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-3 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        hasActiveChild ? 'text-[#06B6D4]' : 'text-slate-300/90'
                      }`}
                    />
                    <span className="truncate">{t(group.labelKey)}</span>
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 shrink-0 text-slate-300 transition-transform duration-200 ${
                      isExpanded ? 'rotate-180 text-[#06B6D4]' : ''
                    }`}
                  />
                </button>

                <div
                  className={`grid transition-all duration-200 ease-in-out ${
                    isExpanded ? 'grid-rows-[1fr] opacity-100 mt-1' : 'grid-rows-[0fr] opacity-0 pointer-events-none'
                  }`}
                >
                  <div className="overflow-hidden">
                    <div className="ml-3.5 pl-2.5 border-l border-white/15 space-y-1 py-0.5">
                      {group.children.map((child) => {
                        const ChildIcon = child.icon;
                        const active = isSubActive(child);
                        return (
                          <button
                            key={child.key}
                            type="button"
                            onClick={() => {
                              navigateTo(child.page, child.subTab || '');
                              setMobileOpen(false);
                            }}
                            className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-xs font-medium transition-all whitespace-nowrap ${
                              active
                                ? 'bg-[#2563EB] text-white shadow-[0_4px_14px_rgba(37,99,235,0.4)]'
                                : 'text-slate-300 hover:bg-white/10 hover:text-white'
                            }`}
                          >
                            <ChildIcon
                              className={`w-3.5 h-3.5 shrink-0 ${
                                active ? 'text-[#06B6D4] drop-shadow-[0_0_6px_rgba(6,182,212,0.7)]' : 'text-slate-300/80'
                              }`}
                            />
                            <span className="truncate">{t(child.labelKey)}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/10">
          <button
            onClick={() => {
              setActivePage('profile');
              setMobileOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 mb-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors flex items-center gap-2.5"
          >
            {user?.photo_url ? (
              <img
                src={user.photo_url}
                alt={`${user.first_name} ${user.last_name}`}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full object-cover border border-[#06B6D4]/50 shrink-0"
              />
            ) : (
              <span className="w-8 h-8 rounded-full bg-[#2563EB] text-white text-xs font-bold flex items-center justify-center shrink-0">
                {initials}
              </span>
            )}
            <div className="min-w-0 flex-1">
              <div className="text-xs font-semibold text-white truncate">
                {user?.first_name} {user?.last_name}
              </div>
              <div className="text-[11px] text-[#06B6D4] truncate">
                {user?.role} · @{user?.username}
              </div>
            </div>
          </button>
          <button
            onClick={logout}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm font-medium text-red-300 hover:bg-red-500/15 hover:text-red-200 transition-colors"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>{t('signOut')}</span>
          </button>
        </div>
      </aside>

      {/* Main Workspace */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 bg-white/95 dark:bg-[#0B1F4D]/95 backdrop-blur-md border-b border-[#E2E8F0] dark:border-[#1E3A8A]/60 px-4 lg:px-6 flex items-center justify-between gap-3 sticky top-0 z-20 shadow-[0_1px_3px_rgba(11,31,77,0.04)] erp-glass-header no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded-xl border border-[#E2E8F0] dark:border-[#1E3A8A]/70 text-[#0B1F4D] dark:text-[#F8FAFC] hover:bg-[#F8FAFC] dark:hover:bg-white/10"
              aria-label="Open navigation"
            >
              <Menu className="w-4 h-4" />
            </button>
            <h1 className="font-display text-base lg:text-lg font-bold text-[#0B1F4D] dark:text-[#F8FAFC] truncate">
              {activeNavLabel}
            </h1>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {!isOnline && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-xs font-medium whitespace-nowrap">
                <WifiOff className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t('offlineMode')}</span>
              </span>
            )}

            {offlineQueue.length > 0 && (
              <button
                onClick={syncOfflineSales}
                disabled={!isOnline}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#06B6D4] hover:bg-[#0891B2] text-white text-xs font-semibold disabled:opacity-50 whitespace-nowrap shadow-xs"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{t('syncNow')} ({offlineQueue.length})</span>
              </button>
            )}

            {/* 1. Publish Button */}
            <div className="relative" ref={publishRef}>
              <button
                onClick={() => setPublishOpen((prev) => !prev)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-[0_2px_8px_rgba(37,99,235,0.3)] hover:shadow-[0_4px_12px_rgba(37,99,235,0.4)] active:scale-[0.98] whitespace-nowrap shrink-0"
              >
                <Globe className="w-3.5 h-3.5 text-[#06B6D4] brightness-125" />
                <span>{t('publish')}</span>
              </button>

              {publishOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-[#0B1F4D] border border-[#E2E8F0] dark:border-[#1E3A8A] rounded-2xl shadow-xl z-50 p-3 space-y-2 erp-glass-dropdown">
                  <div className="px-2 py-1 border-b border-[#E2E8F0] dark:border-white/10">
                    <div className="text-xs font-bold text-[#0B1F4D] dark:text-[#F8FAFC]">
                      {t('publishShare')}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-300 truncate">
                      {settings?.system_name || 'QABDIID BUSNESS 1'}
                    </div>
                  </div>
                  <button
                    onClick={handleCopyLiveUrl}
                    className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-xs font-medium text-[#111827] dark:text-[#F8FAFC] hover:bg-[#F8FAFC] dark:hover:bg-white/10"
                  >
                    <span className="inline-flex items-center gap-2">
                      {copied ? <Check className="w-3.5 h-3.5 text-[#06B6D4]" /> : <Copy className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />}
                      {t('copyLink')}
                    </span>
                  </button>
                  {hasPermission('backup.manage') && (
                    <button
                      onClick={handleQuickBackup}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-[#111827] dark:text-[#F8FAFC] hover:bg-[#F8FAFC] dark:hover:bg-white/10"
                    >
                      <Download className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />
                      <span>{t('backupDatabase')}</span>
                    </button>
                  )}
                  {hasPermission('reports.view') && (
                    <button
                      onClick={() => {
                        setActivePage('reports');
                        setPublishOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-[#111827] dark:text-[#F8FAFC] hover:bg-[#F8FAFC] dark:hover:bg-white/10"
                    >
                      <FileBarChart2 className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />
                      <span>{t('reports')}</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* 2. Notification Bell with Red Badge */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setNotifOpen((prev) => !prev)}
                className="relative p-2 rounded-xl border border-[#E2E8F0] dark:border-[#1E3A8A]/70 bg-[#F8FAFC] dark:bg-[#111827]/70 text-[#0B1F4D] dark:text-[#F8FAFC] hover:border-[#2563EB]/50 hover:bg-white dark:hover:bg-white/10"
                aria-label={t('notifications')}
              >
                <Bell className="w-4 h-4 text-[#0B1F4D] dark:text-[#06B6D4]" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-600 text-white text-[10px] font-mono-num font-bold flex items-center justify-center shadow-xs">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-[#0B1F4D] border border-[#E2E8F0] dark:border-[#1E3A8A] rounded-2xl shadow-xl z-50 overflow-hidden erp-glass-dropdown">
                  <div className="px-4 py-3 border-b border-[#E2E8F0] dark:border-white/10 flex items-center justify-between">
                    <span className="text-sm font-bold text-[#0B1F4D] dark:text-white">{t('notifications')}</span>
                    <div className="flex items-center gap-2">
                      {unreadCount > 0 && (
                        <button
                          onClick={markAllRead}
                          className="text-xs font-medium text-[#2563EB] dark:text-[#06B6D4] hover:underline"
                        >
                          {t('markAllRead')}
                        </button>
                      )}
                      <button
                        onClick={() => setNotifOpen(false)}
                        className="p-1 text-slate-400 hover:text-[#0B1F4D] dark:hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="max-h-96 overflow-y-auto divide-y divide-[#E2E8F0] dark:divide-white/10">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-300">
                        {t('noNotifications')}
                      </div>
                    ) : (
                      notifications.map((n) => (
                        <button
                          key={n.id}
                          onClick={() => markNotificationRead(n.id)}
                          className={`w-full text-left px-4 py-3 hover:bg-[#F8FAFC] dark:hover:bg-white/5 transition-colors ${
                            n.is_read === 0 ? 'bg-[#2563EB]/5 dark:bg-[#06B6D4]/10' : ''
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-0.5">
                            <span className="text-xs font-semibold text-[#111827] dark:text-white">
                              {language === 'so' ? n.title_so : n.title_en}
                            </span>
                            {n.is_read === 0 && (
                              <span className="text-[10px] font-semibold text-[#2563EB] dark:text-[#06B6D4] shrink-0">
                                New
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-300">
                            {language === 'so' ? n.message_so : n.message_en}
                          </p>
                          <div className="text-[10px] text-slate-400 dark:text-slate-400 font-mono-num mt-1">
                            {n.created_at}
                          </div>
                        </button>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* 3. Sun (Light) & Moon (8 Liquid Glass Themes Selector) */}
            <LiquidThemeSelector />

            {/* 4. Language Selector (Somali / English) */}
            <div className="flex items-center p-0.5 rounded-xl bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-[#1E3A8A]/70">
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  language === 'en'
                    ? 'bg-[#2563EB] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-[#0B1F4D] dark:hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('so')}
                className={`px-2 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  language === 'so'
                    ? 'bg-[#2563EB] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-[#0B1F4D] dark:hover:text-white'
                }`}
              >
                SO
              </button>
            </div>

            {/* 5. Quick Settings & Admin Profile */}
            {hasPermission('settings.manage') && (
              <button
                onClick={() => setActivePage('settings')}
                title={t('settings')}
                aria-label={t('settings')}
                className={`p-2 rounded-xl border transition-all shrink-0 ${
                  activePage === 'settings'
                    ? 'bg-[#2563EB] border-[#2563EB] text-white shadow-xs'
                    : 'border-[#E2E8F0] dark:border-[#1E3A8A]/70 bg-[#F8FAFC] dark:bg-[#111827]/70 text-[#0B1F4D] dark:text-[#F8FAFC] hover:border-[#2563EB]/50'
                }`}
              >
                <SettingsIcon className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={() => setActivePage('profile')}
              title={t('profile')}
              className={`inline-flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-xl border transition-all shrink-0 ${
                activePage === 'profile'
                  ? 'bg-[#2563EB] border-[#2563EB] text-white shadow-xs'
                  : 'border-[#E2E8F0] dark:border-[#1E3A8A]/70 bg-[#F8FAFC] dark:bg-[#111827]/70 text-[#0B1F4D] dark:text-[#F8FAFC] hover:border-[#2563EB]/50'
              }`}
            >
              {user?.photo_url ? (
                <img
                  src={user.photo_url}
                  alt={user.first_name || user.username}
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-full object-cover shrink-0 border border-white/30"
                />
              ) : (
                <span
                  className={`w-6 h-6 rounded-lg text-[11px] font-bold flex items-center justify-center shrink-0 ${
                    activePage === 'profile'
                      ? 'bg-white/20 text-white'
                      : 'bg-[#0B1F4D] text-[#06B6D4] dark:bg-[#2563EB] dark:text-white'
                  }`}
                >
                  {initials}
                </span>
              )}
              <span className="hidden md:inline text-xs font-semibold max-w-[110px] truncate">
                {user?.first_name || user?.username}
              </span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">{children}</main>
      </div>
    </div>
  );
}
