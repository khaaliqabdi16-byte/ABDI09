import React, { useState, useRef, useEffect } from 'react';
import { Sun, Moon, Check, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { LIQUID_THEMES, LIQUID_THEME_MAP } from '../constants/themes.ts';

export function LiquidThemeSelector() {
  const { theme, setTheme, t } = useApp();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleKey);
    };
  }, [open]);

  const activeMeta = LIQUID_THEME_MAP[theme] || LIQUID_THEME_MAP['light-glass'];
  const isLightGlass = theme === 'light-glass';

  return (
    <div className="relative" ref={containerRef}>
      <div
        className="flex items-center p-0.5 rounded-xl bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-[#1E3A8A]/70 erp-theme-pill"
        role="group"
        aria-label={t('liquidThemes')}
      >
        <button
          type="button"
          onClick={() => {
            setTheme('light-glass');
            setOpen(false);
          }}
          title={t('lightMode')}
          aria-label={t('lightMode')}
          className={`p-1.5 rounded-lg transition-all ${
            isLightGlass
              ? 'bg-[#2563EB] text-white shadow-xs'
              : 'text-slate-400 hover:text-amber-400'
          }`}
        >
          <Sun className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={() => setOpen((prev) => !prev)}
          title={t('liquidThemes')}
          aria-label={t('liquidThemes')}
          aria-expanded={open}
          aria-haspopup="menu"
          className={`p-1.5 rounded-lg transition-all flex items-center gap-1 ${
            !isLightGlass || open
              ? 'bg-[#2563EB] text-[#06B6D4] shadow-xs'
              : 'text-[#0B1F4D]/70 dark:text-slate-300 hover:text-[#2563EB]'
          }`}
        >
          <Moon className="w-3.5 h-3.5" />
        </button>
      </div>

      {open && (
        <div
          role="menu"
          aria-label={t('liquidThemes')}
          className="absolute right-0 mt-2.5 w-[312px] sm:w-[336px] rounded-2xl p-3.5 z-50 erp-glass-dropdown erp-theme-popover-enter"
        >
          <div className="flex items-center justify-between gap-2 pb-2.5 mb-3 border-b border-slate-200/70 dark:border-white/10">
            <div className="flex items-center gap-2 min-w-0">
              <span
                className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0 shadow-xs"
                style={{
                  background: `linear-gradient(135deg, ${activeMeta.previewAccent}, ${activeMeta.previewSidebar})`,
                }}
              >
                <Sparkles className="w-3.5 h-3.5 text-white" />
              </span>
              <div className="min-w-0">
                <div className="text-xs font-bold text-[#0B1F4D] dark:text-white truncate">
                  {t('liquidThemes')}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-300 truncate">
                  {activeMeta.name}
                </div>
              </div>
            </div>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-900/5 dark:bg-white/10 text-slate-600 dark:text-slate-200 shrink-0">
              8 Themes
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {LIQUID_THEMES.map((item) => {
              const selected = theme === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="menuitemradio"
                  aria-checked={selected}
                  onClick={() => {
                    setTheme(item.id);
                    setOpen(false);
                  }}
                  className={`group relative text-left rounded-xl p-2 transition-all duration-200 border overflow-hidden ${
                    selected
                      ? 'ring-2 ring-offset-1 ring-offset-transparent shadow-md scale-[1.01]'
                      : 'border-slate-200/60 dark:border-white/15 hover:scale-[1.02] hover:shadow-md'
                  }`}
                  style={{
                    background: item.previewBg,
                    borderColor: selected ? item.previewAccent : undefined,
                    boxShadow: selected
                      ? `0 8px 20px -6px ${item.previewAccent}66, inset 0 1px 0 rgba(255,255,255,0.65)`
                      : 'inset 0 1px 0 rgba(255,255,255,0.45)',
                  }}
                >
                  {/* Mini liquid-glass card & sidebar preview */}
                  <div className="flex items-center gap-1.5 mb-2">
                    <div
                      className="w-3.5 h-7 rounded-md shrink-0 shadow-xs"
                      style={{
                        background: item.previewSidebar,
                        border: `1px solid ${item.previewBorder}`,
                      }}
                    />
                    <div
                      className="flex-1 h-7 rounded-md p-1 flex flex-col justify-between backdrop-blur-md"
                      style={{
                        background: item.previewGlass,
                        border: `1px solid ${item.previewBorder}`,
                        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.55)',
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className="w-5 h-1.5 rounded-full"
                          style={{ background: item.previewAccent }}
                        />
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ background: item.previewAccent }}
                        />
                      </div>
                      <div className="flex gap-1">
                        <span
                          className="h-1 flex-1 rounded-full opacity-35"
                          style={{ background: item.previewText }}
                        />
                        <span
                          className="h-1 w-3 rounded-full opacity-25"
                          style={{ background: item.previewText }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-1">
                    <span
                      className="text-[11px] font-bold tracking-tight truncate"
                      style={{ color: item.previewText }}
                    >
                      {item.name}
                    </span>
                    {selected ? (
                      <span
                        className="w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-white shadow-xs"
                        style={{ backgroundColor: item.previewAccent }}
                      >
                        <Check className="w-2.5 h-2.5" />
                      </span>
                    ) : (
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0 opacity-85 group-hover:scale-110 transition-transform"
                        style={{ backgroundColor: item.previewAccent }}
                      />
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
